from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Sequence

from .canonical import sha256_obj, sorted_unique
from .signing import Ed25519IdentityOmega54, verify_ed25519


@dataclass(frozen=True)
class ValidatorIdentity54:
    validator_id: str
    role: str
    organization_id: str
    funding_domain: str
    software_lineage: str
    data_lineage: str
    jurisdiction: str
    public_key: str
    key_fingerprint: str
    evidence_grade: str
    identity_hash: str


@dataclass(frozen=True)
class AdmissionPolicy54:
    policy_id: str
    framework_version: str
    epoch: int
    required_roles: list[str]
    required_independent_approvals: int
    deny_veto: bool
    max_attestation_age: int
    allow_idempotent_replay: bool
    fail_closed_on_store_error: bool
    issued_at: int
    expires_at: int
    evidence_grade: str
    policy_hash: str


@dataclass(frozen=True)
class DurableLease54:
    lease_id: str
    upstream_lease_id: str
    upstream_lease_hash: str
    subject_envelope_hash: str
    channel_id: str
    allowed_chart_ids: list[str]
    allowed_relation_ids: list[str]
    max_residual_budget: float
    max_uses: int
    issued_at: int
    expires_at: int
    policy_epoch: int
    status: str
    lease_hash: str


@dataclass(frozen=True)
class AdmissionClaim54:
    claim_id: str
    envelope_id: str
    envelope_hash: str
    mesh54_envelope_hash: str
    nonce: str
    lease_id: str
    channel_id: str
    chart_id: str
    relation_ids: list[str]
    intent_covenant_hash: str
    atlas_hash: str
    closure_hash: str
    gossip_checkpoint_hash: str
    residual_used: float
    logical_time: int
    policy_epoch: int
    upstream_evidence_hashes: list[str]
    claim_hash: str


@dataclass(frozen=True)
class PreflightAttestation54:
    attestation_id: str
    validator_id: str
    role: str
    claim_hash: str
    verdict: str
    reasons: list[str]
    evidence_hashes: list[str]
    policy_epoch: int
    checked_at: int
    expires_at: int
    signature_algorithm: str
    signature: str
    attestation_hash: str


@dataclass(frozen=True)
class IndependenceAssessment54:
    assessment_id: str
    claim_hash: str
    approving_validator_ids: list[str]
    denying_validator_ids: list[str]
    conflict_edges: list[list[str]]
    independent_components: list[list[str]]
    roles_present: list[str]
    effective_independent_count: int
    required_independent_count: int
    status: str
    reasons: list[str]
    evidence_hashes: list[str]
    assessment_hash: str


@dataclass(frozen=True)
class CommitReceipt54:
    receipt_id: str
    decision: str
    code: str
    reasons: list[str]
    claim_hash: str
    envelope_id: str
    nonce: str
    lease_id: str
    policy_hash: str
    policy_epoch: int
    attestation_ids: list[str]
    independence_hash: str
    independent_components: list[list[str]]
    event_sequence: int
    event_hash: str
    state_root: str
    node_id: str
    committed_at: int
    signer_fingerprint: str
    signature_algorithm: str
    signature: str
    receipt_hash: str


@dataclass(frozen=True)
class AdmissionResult54:
    receipt: CommitReceipt54
    idempotent: bool
    assessment: IndependenceAssessment54


@dataclass(frozen=True)
class TransparencyCheckpointOmega54:
    checkpoint_id: str
    node_id: str
    log_id: str
    tree_size: int
    merkle_root: str
    head_hash: str
    previous_checkpoint_hash: str
    issued_at: int
    signer_fingerprint: str
    signature_algorithm: str
    signature: str
    checkpoint_hash: str


@dataclass(frozen=True)
class CheckpointComparison54:
    comparison_id: str
    left_checkpoint_hash: str
    right_checkpoint_hash: str
    relation: str
    common_prefix_size: int
    split_view_detected: bool
    reasons: list[str]
    comparison_hash: str


@dataclass(frozen=True)
class StoreVerificationReport54:
    status: str
    database_integrity: str
    event_count: int
    receipt_count: int
    committed_nonce_count: int
    active_policy_hash: str
    head_hash: str
    merkle_root: str
    invariant_failures: list[str]
    checked_at: int
    report_hash: str


def validator_identity_body(item: ValidatorIdentity54) -> dict[str, Any]:
    return {
        "validator_id": item.validator_id,
        "role": item.role,
        "organization_id": item.organization_id,
        "funding_domain": item.funding_domain,
        "software_lineage": item.software_lineage,
        "data_lineage": item.data_lineage,
        "jurisdiction": item.jurisdiction,
        "public_key": item.public_key,
        "key_fingerprint": item.key_fingerprint,
        "evidence_grade": item.evidence_grade,
    }


def build_validator_identity54(
    signer: Ed25519IdentityOmega54,
    *,
    role: str,
    organization_id: str,
    funding_domain: str,
    software_lineage: str,
    data_lineage: str,
    jurisdiction: str,
    evidence_grade: str = "E2 simulated reference identity",
) -> ValidatorIdentity54:
    provisional = ValidatorIdentity54(
        validator_id=signer.identity_id,
        role=str(role),
        organization_id=str(organization_id),
        funding_domain=str(funding_domain),
        software_lineage=str(software_lineage),
        data_lineage=str(data_lineage),
        jurisdiction=str(jurisdiction),
        public_key=signer.public_key_hex,
        key_fingerprint=signer.key_fingerprint,
        evidence_grade=str(evidence_grade),
        identity_hash="",
    )
    return replace(provisional, identity_hash=sha256_obj(validator_identity_body(provisional)))


def verify_validator_identity54(item: ValidatorIdentity54) -> bool:
    return (
        bool(item.validator_id)
        and bool(item.role)
        and len(item.public_key) == 64
        and item.identity_hash == sha256_obj(validator_identity_body(item))
    )


def admission_policy_body(item: AdmissionPolicy54) -> dict[str, Any]:
    return {
        "framework_version": item.framework_version,
        "epoch": item.epoch,
        "required_roles": item.required_roles,
        "required_independent_approvals": item.required_independent_approvals,
        "deny_veto": item.deny_veto,
        "max_attestation_age": item.max_attestation_age,
        "allow_idempotent_replay": item.allow_idempotent_replay,
        "fail_closed_on_store_error": item.fail_closed_on_store_error,
        "issued_at": item.issued_at,
        "expires_at": item.expires_at,
        "evidence_grade": item.evidence_grade,
    }


def build_admission_policy54(
    *,
    epoch: int,
    required_roles: Sequence[str] = ("replicator", "red-team", "governance", "affected-party"),
    required_independent_approvals: int = 3,
    deny_veto: bool = True,
    max_attestation_age: int = 60,
    allow_idempotent_replay: bool = True,
    fail_closed_on_store_error: bool = True,
    issued_at: int = 0,
    expires_at: int = 2**31 - 1,
    evidence_grade: str = "E2 author-side deterministic reference",
) -> AdmissionPolicy54:
    if epoch < 1:
        raise ValueError("policy epoch must be positive")
    roles = sorted_unique(required_roles)
    if not roles:
        raise ValueError("at least one required role is necessary")
    if required_independent_approvals < 1:
        raise ValueError("required_independent_approvals must be positive")
    if max_attestation_age < 1:
        raise ValueError("max_attestation_age must be positive")
    if expires_at <= issued_at:
        raise ValueError("policy expiry must follow issuance")
    provisional = AdmissionPolicy54(
        policy_id="",
        framework_version="DIKWP-MESH 5.4 Ω",
        epoch=int(epoch),
        required_roles=roles,
        required_independent_approvals=int(required_independent_approvals),
        deny_veto=bool(deny_veto),
        max_attestation_age=int(max_attestation_age),
        allow_idempotent_replay=bool(allow_idempotent_replay),
        fail_closed_on_store_error=bool(fail_closed_on_store_error),
        issued_at=int(issued_at),
        expires_at=int(expires_at),
        evidence_grade=str(evidence_grade),
        policy_hash="",
    )
    digest = sha256_obj(admission_policy_body(provisional))
    return replace(provisional, policy_id=f"AP54O-{digest[:14]}", policy_hash=digest)


def verify_admission_policy54(item: AdmissionPolicy54) -> bool:
    digest = sha256_obj(admission_policy_body(item))
    return (
        item.policy_hash == digest
        and item.policy_id == f"AP54O-{digest[:14]}"
        and item.epoch >= 1
        and item.required_independent_approvals >= 1
        and bool(item.required_roles)
        and item.max_attestation_age >= 1
        and item.expires_at > item.issued_at
    )


def durable_lease_body(item: DurableLease54) -> dict[str, Any]:
    return {
        "upstream_lease_id": item.upstream_lease_id,
        "upstream_lease_hash": item.upstream_lease_hash,
        "subject_envelope_hash": item.subject_envelope_hash,
        "channel_id": item.channel_id,
        "allowed_chart_ids": item.allowed_chart_ids,
        "allowed_relation_ids": item.allowed_relation_ids,
        "max_residual_budget": item.max_residual_budget,
        "max_uses": item.max_uses,
        "issued_at": item.issued_at,
        "expires_at": item.expires_at,
        "policy_epoch": item.policy_epoch,
        "status": item.status,
    }


def build_durable_lease54(
    *,
    upstream_lease_id: str,
    upstream_lease_hash: str,
    subject_envelope_hash: str,
    channel_id: str,
    allowed_chart_ids: Sequence[str],
    allowed_relation_ids: Sequence[str],
    max_residual_budget: float,
    max_uses: int,
    issued_at: int,
    expires_at: int,
    policy_epoch: int,
    status: str = "ACTIVE",
) -> DurableLease54:
    charts = sorted_unique(allowed_chart_ids)
    relations = sorted_unique(allowed_relation_ids)
    if not charts or not relations:
        raise ValueError("lease requires non-empty chart and relation scopes")
    if not 0.0 <= max_residual_budget <= 1.0:
        raise ValueError("max_residual_budget must be inside [0, 1]")
    if max_uses < 1:
        raise ValueError("max_uses must be positive")
    if expires_at <= issued_at:
        raise ValueError("lease expiry must follow issuance")
    provisional = DurableLease54(
        lease_id="",
        upstream_lease_id=str(upstream_lease_id),
        upstream_lease_hash=str(upstream_lease_hash),
        subject_envelope_hash=str(subject_envelope_hash),
        channel_id=str(channel_id),
        allowed_chart_ids=charts,
        allowed_relation_ids=relations,
        max_residual_budget=float(max_residual_budget),
        max_uses=int(max_uses),
        issued_at=int(issued_at),
        expires_at=int(expires_at),
        policy_epoch=int(policy_epoch),
        status=str(status),
        lease_hash="",
    )
    digest = sha256_obj(durable_lease_body(provisional))
    return replace(provisional, lease_id=f"DL54O-{digest[:14]}", lease_hash=digest)


def verify_durable_lease54(item: DurableLease54) -> bool:
    digest = sha256_obj(durable_lease_body(item))
    return (
        item.lease_hash == digest
        and item.lease_id == f"DL54O-{digest[:14]}"
        and bool(item.allowed_chart_ids)
        and bool(item.allowed_relation_ids)
        and item.max_uses >= 1
        and 0.0 <= item.max_residual_budget <= 1.0
        and item.expires_at > item.issued_at
    )


def admission_claim_body(item: AdmissionClaim54) -> dict[str, Any]:
    return {
        "envelope_id": item.envelope_id,
        "envelope_hash": item.envelope_hash,
        "mesh54_envelope_hash": item.mesh54_envelope_hash,
        "nonce": item.nonce,
        "lease_id": item.lease_id,
        "channel_id": item.channel_id,
        "chart_id": item.chart_id,
        "relation_ids": item.relation_ids,
        "intent_covenant_hash": item.intent_covenant_hash,
        "atlas_hash": item.atlas_hash,
        "closure_hash": item.closure_hash,
        "gossip_checkpoint_hash": item.gossip_checkpoint_hash,
        "residual_used": item.residual_used,
        "logical_time": item.logical_time,
        "policy_epoch": item.policy_epoch,
        "upstream_evidence_hashes": item.upstream_evidence_hashes,
    }


def build_admission_claim54(
    *,
    envelope_id: str,
    envelope_hash: str,
    mesh54_envelope_hash: str,
    nonce: str,
    lease_id: str,
    channel_id: str,
    chart_id: str,
    relation_ids: Sequence[str],
    intent_covenant_hash: str,
    atlas_hash: str,
    closure_hash: str,
    gossip_checkpoint_hash: str,
    residual_used: float,
    logical_time: int,
    policy_epoch: int,
    upstream_evidence_hashes: Sequence[str] = (),
) -> AdmissionClaim54:
    relations = sorted_unique(relation_ids)
    if not relations:
        raise ValueError("claim requires at least one relation")
    if residual_used < 0.0:
        raise ValueError("residual_used must be non-negative")
    provisional = AdmissionClaim54(
        claim_id="",
        envelope_id=str(envelope_id),
        envelope_hash=str(envelope_hash),
        mesh54_envelope_hash=str(mesh54_envelope_hash),
        nonce=str(nonce),
        lease_id=str(lease_id),
        channel_id=str(channel_id),
        chart_id=str(chart_id),
        relation_ids=relations,
        intent_covenant_hash=str(intent_covenant_hash),
        atlas_hash=str(atlas_hash),
        closure_hash=str(closure_hash),
        gossip_checkpoint_hash=str(gossip_checkpoint_hash),
        residual_used=float(residual_used),
        logical_time=int(logical_time),
        policy_epoch=int(policy_epoch),
        upstream_evidence_hashes=sorted_unique(upstream_evidence_hashes),
        claim_hash="",
    )
    digest = sha256_obj(admission_claim_body(provisional))
    return replace(provisional, claim_id=f"AC54O-{digest[:14]}", claim_hash=digest)


def verify_admission_claim54(item: AdmissionClaim54) -> bool:
    digest = sha256_obj(admission_claim_body(item))
    return (
        item.claim_hash == digest
        and item.claim_id == f"AC54O-{digest[:14]}"
        and bool(item.nonce)
        and bool(item.envelope_id)
        and bool(item.relation_ids)
        and item.residual_used >= 0.0
        and item.policy_epoch >= 1
    )


def preflight_attestation_body(item: PreflightAttestation54) -> dict[str, Any]:
    return {
        "validator_id": item.validator_id,
        "role": item.role,
        "claim_hash": item.claim_hash,
        "verdict": item.verdict,
        "reasons": item.reasons,
        "evidence_hashes": item.evidence_hashes,
        "policy_epoch": item.policy_epoch,
        "checked_at": item.checked_at,
        "expires_at": item.expires_at,
        "signature_algorithm": item.signature_algorithm,
    }


def attest_claim54(
    signer: Ed25519IdentityOmega54,
    identity: ValidatorIdentity54,
    claim: AdmissionClaim54,
    verdict: str,
    *,
    reasons: Sequence[str] = (),
    evidence_hashes: Sequence[str] = (),
    checked_at: int,
    expires_at: int,
) -> PreflightAttestation54:
    if signer.identity_id != identity.validator_id or signer.key_fingerprint != identity.key_fingerprint:
        raise ValueError("signer does not match validator identity")
    if not verify_validator_identity54(identity):
        raise ValueError("validator identity is invalid")
    if not verify_admission_claim54(claim):
        raise ValueError("admission claim is invalid")
    verdict = str(verdict).upper()
    if verdict not in {"APPROVE", "DENY"}:
        raise ValueError("verdict must be APPROVE or DENY")
    if expires_at <= checked_at:
        raise ValueError("attestation expiry must follow checked_at")
    provisional = PreflightAttestation54(
        attestation_id="",
        validator_id=identity.validator_id,
        role=identity.role,
        claim_hash=claim.claim_hash,
        verdict=verdict,
        reasons=sorted_unique(reasons),
        evidence_hashes=sorted_unique(evidence_hashes),
        policy_epoch=claim.policy_epoch,
        checked_at=int(checked_at),
        expires_at=int(expires_at),
        signature_algorithm="Ed25519/mesh54-omega-preflight-v1",
        signature="",
        attestation_hash="",
    )
    signature = signer.sign(preflight_attestation_body(provisional))
    signed = replace(provisional, signature=signature)
    digest = sha256_obj({**preflight_attestation_body(signed), "signature": signature})
    return replace(signed, attestation_id=f"PA54O-{digest[:14]}", attestation_hash=digest)


def verify_preflight_attestation54(item: PreflightAttestation54, identity: ValidatorIdentity54) -> bool:
    digest = sha256_obj({**preflight_attestation_body(item), "signature": item.signature})
    return (
        verify_validator_identity54(identity)
        and item.validator_id == identity.validator_id
        and item.role == identity.role
        and item.verdict in {"APPROVE", "DENY"}
        and item.expires_at > item.checked_at
        and item.attestation_hash == digest
        and item.attestation_id == f"PA54O-{digest[:14]}"
        and verify_ed25519(identity.public_key, preflight_attestation_body(item), item.signature)
    )


def independence_assessment_body(item: IndependenceAssessment54) -> dict[str, Any]:
    return {
        "claim_hash": item.claim_hash,
        "approving_validator_ids": item.approving_validator_ids,
        "denying_validator_ids": item.denying_validator_ids,
        "conflict_edges": item.conflict_edges,
        "independent_components": item.independent_components,
        "roles_present": item.roles_present,
        "effective_independent_count": item.effective_independent_count,
        "required_independent_count": item.required_independent_count,
        "status": item.status,
        "reasons": item.reasons,
        "evidence_hashes": item.evidence_hashes,
    }


def commit_receipt_body(item: CommitReceipt54) -> dict[str, Any]:
    return {
        "decision": item.decision,
        "code": item.code,
        "reasons": item.reasons,
        "claim_hash": item.claim_hash,
        "envelope_id": item.envelope_id,
        "nonce": item.nonce,
        "lease_id": item.lease_id,
        "policy_hash": item.policy_hash,
        "policy_epoch": item.policy_epoch,
        "attestation_ids": item.attestation_ids,
        "independence_hash": item.independence_hash,
        "independent_components": item.independent_components,
        "event_sequence": item.event_sequence,
        "event_hash": item.event_hash,
        "state_root": item.state_root,
        "node_id": item.node_id,
        "committed_at": item.committed_at,
        "signer_fingerprint": item.signer_fingerprint,
        "signature_algorithm": item.signature_algorithm,
    }


def sign_commit_receipt54(
    signer: Ed25519IdentityOmega54,
    *,
    decision: str,
    code: str,
    reasons: Sequence[str],
    claim: AdmissionClaim54,
    policy: AdmissionPolicy54,
    attestation_ids: Sequence[str],
    assessment: IndependenceAssessment54,
    event_sequence: int,
    event_hash: str,
    state_root: str,
    node_id: str,
    committed_at: int,
) -> CommitReceipt54:
    provisional = CommitReceipt54(
        receipt_id="",
        decision=str(decision),
        code=str(code),
        reasons=sorted_unique(reasons),
        claim_hash=claim.claim_hash,
        envelope_id=claim.envelope_id,
        nonce=claim.nonce,
        lease_id=claim.lease_id,
        policy_hash=policy.policy_hash,
        policy_epoch=policy.epoch,
        attestation_ids=sorted_unique(attestation_ids),
        independence_hash=assessment.assessment_hash,
        independent_components=assessment.independent_components,
        event_sequence=int(event_sequence),
        event_hash=str(event_hash),
        state_root=str(state_root),
        node_id=str(node_id),
        committed_at=int(committed_at),
        signer_fingerprint=signer.key_fingerprint,
        signature_algorithm="Ed25519/mesh54-omega-commit-receipt-v1",
        signature="",
        receipt_hash="",
    )
    signature = signer.sign(commit_receipt_body(provisional))
    signed = replace(provisional, signature=signature)
    digest = sha256_obj({**commit_receipt_body(signed), "signature": signature})
    return replace(signed, receipt_id=f"CR54O-{digest[:14]}", receipt_hash=digest)


def verify_commit_receipt54(item: CommitReceipt54, public_key_hex: str) -> bool:
    digest = sha256_obj({**commit_receipt_body(item), "signature": item.signature})
    return (
        item.decision in {"ACCEPTED", "REJECTED"}
        and item.receipt_hash == digest
        and item.receipt_id == f"CR54O-{digest[:14]}"
        and verify_ed25519(public_key_hex, commit_receipt_body(item), item.signature)
    )


def checkpoint_body(item: TransparencyCheckpointOmega54) -> dict[str, Any]:
    return {
        "node_id": item.node_id,
        "log_id": item.log_id,
        "tree_size": item.tree_size,
        "merkle_root": item.merkle_root,
        "head_hash": item.head_hash,
        "previous_checkpoint_hash": item.previous_checkpoint_hash,
        "issued_at": item.issued_at,
        "signer_fingerprint": item.signer_fingerprint,
        "signature_algorithm": item.signature_algorithm,
    }


def sign_checkpoint54(
    signer: Ed25519IdentityOmega54,
    *,
    node_id: str,
    log_id: str,
    tree_size: int,
    merkle_root: str,
    head_hash: str,
    previous_checkpoint_hash: str,
    issued_at: int,
) -> TransparencyCheckpointOmega54:
    provisional = TransparencyCheckpointOmega54(
        checkpoint_id="",
        node_id=str(node_id),
        log_id=str(log_id),
        tree_size=int(tree_size),
        merkle_root=str(merkle_root),
        head_hash=str(head_hash),
        previous_checkpoint_hash=str(previous_checkpoint_hash),
        issued_at=int(issued_at),
        signer_fingerprint=signer.key_fingerprint,
        signature_algorithm="Ed25519/mesh54-omega-checkpoint-v1",
        signature="",
        checkpoint_hash="",
    )
    signature = signer.sign(checkpoint_body(provisional))
    signed = replace(provisional, signature=signature)
    digest = sha256_obj({**checkpoint_body(signed), "signature": signature})
    return replace(signed, checkpoint_id=f"CP54O-{digest[:14]}", checkpoint_hash=digest)


def verify_checkpoint54(item: TransparencyCheckpointOmega54, public_key_hex: str) -> bool:
    digest = sha256_obj({**checkpoint_body(item), "signature": item.signature})
    return (
        item.tree_size >= 0
        and item.checkpoint_hash == digest
        and item.checkpoint_id == f"CP54O-{digest[:14]}"
        and verify_ed25519(public_key_hex, checkpoint_body(item), item.signature)
    )
