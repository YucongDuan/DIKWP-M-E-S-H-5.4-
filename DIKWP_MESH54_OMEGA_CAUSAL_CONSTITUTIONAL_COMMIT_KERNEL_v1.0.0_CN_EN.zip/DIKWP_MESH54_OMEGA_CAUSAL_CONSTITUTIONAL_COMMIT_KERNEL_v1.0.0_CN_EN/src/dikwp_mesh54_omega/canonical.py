from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import tempfile
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

ZERO_HASH = "0" * 64


def _set_sort_key(value: Any) -> str:
    return json.dumps(to_builtin(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def to_builtin(value: Any) -> Any:
    if is_dataclass(value):
        return {key: to_builtin(item) for key, item in asdict(value).items()}
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): to_builtin(item) for key, item in value.items()}
    if isinstance(value, set):
        return [to_builtin(item) for item in sorted(value, key=_set_sort_key)]
    if isinstance(value, (list, tuple)):
        return [to_builtin(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("non-finite floats are not allowed")
    return value


def canonical_json(value: Any) -> str:
    return json.dumps(to_builtin(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def canonical_json_bytes(value: Any) -> bytes:
    return canonical_json(value).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_obj(value: Any) -> str:
    return sha256_bytes(canonical_json_bytes(value))



def hmac_sha256_hex(secret: bytes, value: Any) -> str:
    if not secret:
        raise ValueError("integrity secret must not be empty")
    return hmac.new(secret, canonical_json_bytes(value), hashlib.sha256).hexdigest()


def constant_time_equal(left: str, right: str) -> bool:
    return hmac.compare_digest(str(left).encode("ascii", "ignore"), str(right).encode("ascii", "ignore"))

def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def merkle_root(hashes: Sequence[str]) -> str:
    if not hashes:
        return ZERO_HASH
    level = [str(item) for item in hashes]
    if any(len(item) != 64 for item in level):
        raise ValueError("Merkle leaves must be SHA-256 hex digests")
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [sha256_bytes(bytes.fromhex(level[i]) + bytes.fromhex(level[i + 1])) for i in range(0, len(level), 2)]
    return level[0]


def write_json(path: str | Path, value: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(to_builtin(value), ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, target)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sorted_unique(values: Iterable[str]) -> list[str]:
    return sorted({str(item) for item in values})
