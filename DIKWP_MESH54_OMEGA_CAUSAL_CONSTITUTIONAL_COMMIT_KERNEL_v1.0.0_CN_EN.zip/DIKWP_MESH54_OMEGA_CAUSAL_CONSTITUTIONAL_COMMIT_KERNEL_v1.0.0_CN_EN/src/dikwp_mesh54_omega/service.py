from __future__ import annotations

import hmac
import json
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from .canonical import to_builtin
from .kernel import ConstitutionalCommitKernel54
from .models import AdmissionClaim54, PreflightAttestation54

_MAX_BODY = 2 * 1024 * 1024


class OmegaHandler54(BaseHTTPRequestHandler):
    server_version = "DIKWP-MESH54-Omega/1.0"

    def __init__(self, *args, kernel: ConstitutionalCommitKernel54, bearer_token: str, **kwargs) -> None:
        self.kernel = kernel
        self.bearer_token = bearer_token
        super().__init__(*args, **kwargs)

    def _send(self, status: int, payload: object, *, include_body: bool = True) -> None:
        body = json.dumps(to_builtin(payload), ensure_ascii=False, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        if include_body:
            self.wfile.write(body)

    def _authorized(self) -> bool:
        supplied = self.headers.get("Authorization", "")
        expected = f"Bearer {self.bearer_token}"
        return bool(self.bearer_token) and hmac.compare_digest(supplied, expected)

    def _json_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("invalid Content-Length") from exc
        if length <= 0 or length > _MAX_BODY:
            raise ValueError("request body length is outside the allowed range")
        payload = self.rfile.read(length)
        return json.loads(payload.decode("utf-8"))

    def do_GET(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path == "/health":
            self._send(200, {"status": "ok", "framework": "DIKWP-MESH 5.4 Ω", "mode": "constitutional-commit"})
            return
        if not self._authorized():
            self._send(401, {"status": "unauthorized"})
            return
        if path == "/v1/status":
            self._send(200, self.kernel.status())
            return
        if path == "/v1/verify":
            self._send(200, self.kernel.verify_store())
            return
        if path.startswith("/v1/receipts/"):
            receipt_id = path.rsplit("/", 1)[-1]
            try:
                self._send(200, self.kernel.store.receipt(receipt_id))
            except KeyError:
                self._send(404, {"status": "not-found", "receipt_id": receipt_id})
            return
        self._send(404, {"status": "not-found", "path": path})

    def do_HEAD(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path == "/health":
            self._send(200, {"status": "ok"}, include_body=False)
        else:
            self._send(404, {"status": "not-found"}, include_body=False)

    def do_POST(self) -> None:  # noqa: N802
        if not self._authorized():
            self._send(401, {"status": "unauthorized"})
            return
        path = urlsplit(self.path).path
        try:
            payload = self._json_body()
            if path == "/v1/admit":
                claim = AdmissionClaim54(**payload["claim"])
                attestations = [PreflightAttestation54(**item) for item in payload["attestations"]]
                result = self.kernel.admit(claim, attestations, logical_time=int(payload["logical_time"]))
                self._send(200, result)
                return
            if path == "/v1/checkpoints":
                checkpoint = self.kernel.checkpoint(logical_time=int(payload["logical_time"]))
                self._send(201, checkpoint)
                return
            self._send(404, {"status": "not-found", "path": path})
        except PermissionError as exc:
            self._send(403, {"status": "rejected", "error": str(exc)})
        except (KeyError, TypeError, ValueError) as exc:
            self._send(400, {"status": "invalid-request", "error": str(exc)})
        except Exception as exc:  # fail closed without leaking stack or secrets
            self._send(500, {"status": "internal-error", "error": type(exc).__name__})

    def do_PUT(self) -> None:  # noqa: N802
        self._send(405, {"status": "method-not-allowed"})

    def do_PATCH(self) -> None:  # noqa: N802
        self.do_PUT()

    def do_DELETE(self) -> None:  # noqa: N802
        self.do_PUT()

    def log_message(self, fmt: str, *args: object) -> None:
        return


def make_handler(kernel: ConstitutionalCommitKernel54, bearer_token: str):
    return partial(OmegaHandler54, kernel=kernel, bearer_token=bearer_token)


def serve(
    kernel: ConstitutionalCommitKernel54,
    *,
    host: str,
    port: int,
    bearer_token: str,
) -> None:
    if not bearer_token or len(bearer_token) < 24:
        raise ValueError("bearer token must contain at least 24 characters")
    if not 0 <= int(port) <= 65535:
        raise ValueError("port must be inside [0, 65535]")
    server = ThreadingHTTPServer((host, int(port)), make_handler(kernel, bearer_token))
    print(f"MESH5.4 Omega constitutional commit service: http://{host}:{server.server_port}")
    if host not in {"127.0.0.1", "localhost", "::1"}:
        print("WARNING: terminate TLS and enforce network policy with a hardened reverse proxy.")
    try:
        server.serve_forever()
    finally:
        server.server_close()
