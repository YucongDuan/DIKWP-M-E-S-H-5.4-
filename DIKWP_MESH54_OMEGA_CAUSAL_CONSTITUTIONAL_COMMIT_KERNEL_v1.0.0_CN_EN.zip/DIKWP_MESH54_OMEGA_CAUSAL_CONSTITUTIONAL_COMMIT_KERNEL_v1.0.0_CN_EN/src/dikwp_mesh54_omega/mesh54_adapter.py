from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Sequence

from .canonical import constant_time_equal, hmac_sha256_hex, sha256_obj, sorted_unique, to_builtin
from .models import (
    AdmissionClaim54,
    DurableLease54,
    PreflightAttestation54,
    ValidatorIdentity54,
    attest_claim54,
    build_admission_claim54,
    build_durable_lease54,
)
from .signing import Ed25519IdentityOmega54


def _raw(value: Any) -> dict[str, Any]:
    if is_dataclass(value):
        return to_builtin(value)
    if isinstance(value, dict):
        return to_builtin(value)
    raise TypeError("expected a dataclass or mapping")


def _proof_body(packet: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "source_channel_id",
        "certificate_id",
        "certificate_hash",
        "protocol_hash",
        "equivalence_class_id",
        "operator_genome_id",
        "payload_vector",
        "rollback_vector",
        "residual_budget",
        "issued_at",
        "expires_at",
        "nonce",
        "lineage_hashes",
        "integrity_algorithm",
    )
    return {key: packet[key] for key in keys}


def _mesh53_body(envelope: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "proof_packet",
        "lease_id",
        "lease_hash",
        "mesh53_envelope_hash",
        "purpose_contract_hash",
        "environment_id",
        "closure_hash",
        "witness_quorum_hash",
        "transparency_checkpoint_hash",
        "issued_at",
        "integrity_algorithm",
    )
    return {key: envelope[key] for key in keys}


def _mesh54_body(envelope: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "base_envelope",
        "lease54_id",
        "lease54_hash",
        "mesh54_envelope_hash",
        "intent_covenant_hash",
        "chart_id",
        "relation_ids",
        "atlas_hash",
        "closure_hash",
        "gossip_checkpoint_hash",
        "issued_at",
        "integrity_algorithm",
    )
    return {key: envelope[key] for key in keys}


def _lease54_body(lease: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "subject_envelope_hash",
        "base_lease_id",
        "base_lease_hash",
        "allowed_chart_ids",
        "allowed_relation_ids",
        "max_holonomy_error",
        "max_uax_exposure",
        "max_uses",
        "issued_at",
        "expires_at",
    )
    return {key: lease[key] for key in keys}


def claim_from_governed_packet54(
    envelope: Any,
    *,
    durable_lease_id: str,
    policy_epoch: int,
    logical_time: int | None = None,
    residual_used: float = 0.0,
    upstream_evidence_hashes: Sequence[str] = (),
) -> AdmissionClaim54:
    raw = _raw(envelope)
    base = raw["base_envelope"]
    proof = base["proof_packet"]
    return build_admission_claim54(
        envelope_id=raw["envelope_id"],
        envelope_hash=raw["body_hash"],
        mesh54_envelope_hash=raw["mesh54_envelope_hash"],
        nonce=proof["nonce"],
        lease_id=durable_lease_id,
        channel_id=proof["source_channel_id"],
        chart_id=raw["chart_id"],
        relation_ids=raw["relation_ids"],
        intent_covenant_hash=raw["intent_covenant_hash"],
        atlas_hash=raw["atlas_hash"],
        closure_hash=raw["closure_hash"],
        gossip_checkpoint_hash=raw["gossip_checkpoint_hash"],
        residual_used=float(residual_used),
        logical_time=int(raw["issued_at"] if logical_time is None else logical_time),
        policy_epoch=int(policy_epoch),
        upstream_evidence_hashes=sorted_unique(
            list(upstream_evidence_hashes)
            + [
                raw["body_hash"],
                base["body_hash"],
                proof["body_hash"],
                raw["mesh54_envelope_hash"],
                raw["atlas_hash"],
                raw["closure_hash"],
                raw["gossip_checkpoint_hash"],
            ]
        ),
    )


def durable_lease_from_mesh54(
    lease54: Any,
    governed_envelope54: Any,
    *,
    policy_epoch: int,
    max_residual_budget: float,
    max_uses: int | None = None,
) -> DurableLease54:
    lease = _raw(lease54)
    envelope = _raw(governed_envelope54)
    proof = envelope["base_envelope"]["proof_packet"]
    return build_durable_lease54(
        upstream_lease_id=lease["lease_id"],
        upstream_lease_hash=lease["lease_hash"],
        subject_envelope_hash=lease["subject_envelope_hash"],
        channel_id=proof["source_channel_id"],
        allowed_chart_ids=lease["allowed_chart_ids"],
        allowed_relation_ids=lease["allowed_relation_ids"],
        max_residual_budget=float(max_residual_budget),
        max_uses=int(lease["max_uses"] if max_uses is None else max_uses),
        issued_at=int(lease["issued_at"]),
        expires_at=int(lease["expires_at"]),
        policy_epoch=int(policy_epoch),
    )


def structural_preflight54(
    envelope54: Any,
    lease54: Any,
    *,
    integrity_secret: bytes,
    logical_time: int,
    residual_used: float = 0.0,
) -> dict[str, Any]:
    """Verify the three nested hashes/HMACs and declared Mesh54 scopes.

    This deliberately does not replace causal matrix, rollback-vector, witness,
    transparency-log or atlas verification. A live runtime validator or an
    independent artifact verifier should add those evidence hashes before
    attesting in a production deployment.
    """

    envelope = _raw(envelope54)
    lease = _raw(lease54)
    base = envelope.get("base_envelope", {})
    proof = base.get("proof_packet", {})
    reasons: list[str] = []

    try:
        proof_body = _proof_body(proof)
        proof_hash = sha256_obj(proof_body)
        proof_tag = hmac_sha256_hex(integrity_secret, {"body": proof_body, "body_hash": proof_hash})
        if proof.get("body_hash") != proof_hash or proof.get("packet_id") != f"PCP-{proof_hash[:14]}":
            reasons.append("proof packet body hash or identifier is invalid")
        if not constant_time_equal(proof.get("integrity_tag", ""), proof_tag):
            reasons.append("proof packet HMAC is invalid")
        if proof.get("integrity_algorithm") != "HMAC-SHA256/local-integrity-v1":
            reasons.append("proof packet integrity algorithm is unsupported")
    except Exception as exc:
        reasons.append(f"proof packet parse failed: {type(exc).__name__}")
        proof_hash = ""

    try:
        base_body = _mesh53_body(base)
        base_hash = sha256_obj(base_body)
        base_tag = hmac_sha256_hex(integrity_secret, {"body": base_body, "body_hash": base_hash})
        if base.get("body_hash") != base_hash or base.get("envelope_id") != f"GPE-{base_hash[:14]}":
            reasons.append("Mesh53 governed envelope body hash or identifier is invalid")
        if not constant_time_equal(base.get("integrity_tag", ""), base_tag):
            reasons.append("Mesh53 governed envelope HMAC is invalid")
        if base.get("integrity_algorithm") != "HMAC-SHA256/mesh53-governed-envelope-v1":
            reasons.append("Mesh53 governed envelope integrity algorithm is unsupported")
    except Exception as exc:
        reasons.append(f"Mesh53 envelope parse failed: {type(exc).__name__}")
        base_hash = ""

    try:
        outer_body = _mesh54_body(envelope)
        outer_hash = sha256_obj(outer_body)
        outer_tag = hmac_sha256_hex(integrity_secret, {"body": outer_body, "body_hash": outer_hash})
        if envelope.get("body_hash") != outer_hash or envelope.get("envelope_id") != f"GPE54-{outer_hash[:14]}":
            reasons.append("Mesh54 governed envelope body hash or identifier is invalid")
        if not constant_time_equal(envelope.get("integrity_tag", ""), outer_tag):
            reasons.append("Mesh54 governed envelope HMAC is invalid")
        if envelope.get("integrity_algorithm") != "HMAC-SHA256/mesh54-governed-envelope-v1":
            reasons.append("Mesh54 governed envelope integrity algorithm is unsupported")
    except Exception as exc:
        reasons.append(f"Mesh54 envelope parse failed: {type(exc).__name__}")
        outer_hash = ""

    try:
        lease_body = _lease54_body(lease)
        lease_hash = sha256_obj(lease_body)
        if lease.get("lease_hash") != lease_hash or lease.get("lease_id") != f"CL54-{lease_hash[:14]}":
            reasons.append("Mesh54 upstream lease hash or identifier is invalid")
        if envelope.get("lease54_id") != lease.get("lease_id") or envelope.get("lease54_hash") != lease.get("lease_hash"):
            reasons.append("governed envelope is bound to another upstream lease")
        if envelope.get("mesh54_envelope_hash") != lease.get("subject_envelope_hash"):
            reasons.append("governed envelope is bound to another constitutional envelope")
        if envelope.get("chart_id") not in set(lease.get("allowed_chart_ids", [])):
            reasons.append("chart is outside upstream Mesh54 lease scope")
        if not set(envelope.get("relation_ids", [])).issubset(set(lease.get("allowed_relation_ids", []))):
            reasons.append("relations are outside upstream Mesh54 lease scope")
        if not int(lease.get("issued_at", 0)) <= int(logical_time) < int(lease.get("expires_at", 0)):
            reasons.append("upstream Mesh54 lease is outside its validity window")
    except Exception as exc:
        reasons.append(f"Mesh54 lease parse failed: {type(exc).__name__}")
        lease_hash = ""

    try:
        if not int(proof.get("issued_at", 0)) <= int(logical_time) < int(proof.get("expires_at", 0)):
            reasons.append("proof packet is outside its validity window")
        if float(residual_used) < 0 or float(residual_used) > float(proof.get("residual_budget", -1)) + 1e-12:
            reasons.append("proof packet residual budget is exceeded")
    except Exception as exc:
        reasons.append(f"time or residual validation failed: {type(exc).__name__}")

    body = {
        "accepted": not reasons,
        "reasons": sorted(set(reasons)),
        "logical_time": int(logical_time),
        "residual_used": float(residual_used),
        "evidence_hashes": sorted_unique([item for item in [proof_hash, base_hash, outer_hash, lease_hash] if item]),
        "scope": "nested hash/HMAC, time, residual and declared lease scope only",
    }
    return {**body, "result_hash": sha256_obj(body)}


def attest_structural_preflight54(
    signer: Ed25519IdentityOmega54,
    identity: ValidatorIdentity54,
    claim: AdmissionClaim54,
    envelope54: Any,
    lease54: Any,
    *,
    integrity_secret: bytes,
    checked_at: int,
    expires_at: int,
) -> PreflightAttestation54:
    result = structural_preflight54(
        envelope54,
        lease54,
        integrity_secret=integrity_secret,
        logical_time=checked_at,
        residual_used=claim.residual_used,
    )
    generated = claim_from_governed_packet54(
        envelope54,
        durable_lease_id=claim.lease_id,
        policy_epoch=claim.policy_epoch,
        logical_time=claim.logical_time,
        residual_used=claim.residual_used,
        upstream_evidence_hashes=claim.upstream_evidence_hashes,
    )
    reasons = list(result["reasons"])
    if generated.claim_hash != claim.claim_hash:
        reasons.append("claim does not canonically match the governed packet")
    return attest_claim54(
        signer,
        identity,
        claim,
        "APPROVE" if not reasons else "DENY",
        reasons=reasons,
        evidence_hashes=list(result["evidence_hashes"]) + [result["result_hash"]],
        checked_at=checked_at,
        expires_at=expires_at,
    )


def attest_live_runtime_preflight54(
    runtime: Any,
    envelope54: Any,
    *,
    durable_lease_id: str,
    policy_epoch: int,
    signer: Ed25519IdentityOmega54,
    identity: ValidatorIdentity54,
    logical_time: int,
    residual_used: float = 0.0,
    expires_at: int,
) -> tuple[AdmissionClaim54, PreflightAttestation54]:
    """Use a live DIKWP-MESH 5.4 runtime without consuming its inner nonce."""

    claim = claim_from_governed_packet54(
        envelope54,
        durable_lease_id=durable_lease_id,
        policy_epoch=policy_epoch,
        logical_time=logical_time,
        residual_used=residual_used,
    )
    reasons, _, _ = runtime._outer_reasons(envelope54, logical_time=logical_time)  # noqa: SLF001
    preview = runtime.mesh53.verify(
        envelope54.base_envelope,
        logical_time=logical_time,
        residual_used=residual_used,
        consume_nonce=False,
    )
    if not preview.accepted:
        reasons.extend(f"base53-preview: {item}" for item in preview.reasons)
    attestation = attest_claim54(
        signer,
        identity,
        claim,
        "APPROVE" if not reasons else "DENY",
        reasons=reasons,
        evidence_hashes=[claim.envelope_hash, preview.verdict_hash],
        checked_at=logical_time,
        expires_at=expires_at,
    )
    return claim, attestation
