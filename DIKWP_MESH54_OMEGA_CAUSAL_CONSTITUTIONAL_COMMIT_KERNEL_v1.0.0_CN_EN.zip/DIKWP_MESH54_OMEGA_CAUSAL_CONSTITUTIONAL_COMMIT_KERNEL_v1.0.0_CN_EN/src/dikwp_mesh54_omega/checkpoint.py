from __future__ import annotations

from dataclasses import replace
from typing import Sequence

from .canonical import merkle_root, sha256_obj
from .models import (
    CheckpointComparison54,
    TransparencyCheckpointOmega54,
    verify_checkpoint54,
)


def compare_checkpoints54(
    left: TransparencyCheckpointOmega54,
    right: TransparencyCheckpointOmega54,
    *,
    left_public_key: str,
    right_public_key: str,
    left_event_hashes: Sequence[str] = (),
    right_event_hashes: Sequence[str] = (),
) -> CheckpointComparison54:
    reasons: list[str] = []
    if not verify_checkpoint54(left, left_public_key):
        reasons.append("left checkpoint signature or hash is invalid")
    if not verify_checkpoint54(right, right_public_key):
        reasons.append("right checkpoint signature or hash is invalid")
    if left.log_id != right.log_id:
        reasons.append("checkpoints refer to different log identifiers")

    relation = "UNRELATED"
    common_prefix_size = 0
    split_view = False
    if not reasons and left.checkpoint_hash == right.checkpoint_hash:
        relation = "EQUAL"
        common_prefix_size = left.tree_size
    elif not reasons and left.tree_size == right.tree_size:
        common_prefix_size = left.tree_size if left.merkle_root == right.merkle_root else 0
        relation = "EQUAL_SIZE_CONFLICT" if left.merkle_root != right.merkle_root else "EQUIVALENT"
        split_view = left.merkle_root != right.merkle_root or left.head_hash != right.head_hash
        if split_view:
            reasons.append("equal-size checkpoints expose different roots or heads")
    elif not reasons:
        smaller, larger = (left, right) if left.tree_size < right.tree_size else (right, left)
        larger_hashes = list(right_event_hashes if larger is right else left_event_hashes)
        smaller_hashes = list(left_event_hashes if smaller is left else right_event_hashes)
        if len(smaller_hashes) >= smaller.tree_size and len(larger_hashes) >= larger.tree_size:
            prefix = larger_hashes[: smaller.tree_size]
            if (
                merkle_root(prefix) == smaller.merkle_root
                and (prefix[-1] if prefix else "0" * 64) == smaller.head_hash
                and smaller_hashes[: smaller.tree_size] == prefix
            ):
                relation = "PREFIX"
                common_prefix_size = smaller.tree_size
            else:
                relation = "SPLIT_VIEW"
                split_view = True
                reasons.append("smaller checkpoint is not a valid prefix of the larger view")
        else:
            relation = "INSUFFICIENT_PREFIX_EVIDENCE"
            reasons.append("event hashes are insufficient to prove checkpoint consistency")

    body = {
        "left_checkpoint_hash": left.checkpoint_hash,
        "right_checkpoint_hash": right.checkpoint_hash,
        "relation": relation,
        "common_prefix_size": common_prefix_size,
        "split_view_detected": split_view,
        "reasons": reasons,
    }
    digest = sha256_obj(body)
    return CheckpointComparison54(
        comparison_id=f"CC54O-{digest[:14]}",
        comparison_hash=digest,
        **body,
    )
