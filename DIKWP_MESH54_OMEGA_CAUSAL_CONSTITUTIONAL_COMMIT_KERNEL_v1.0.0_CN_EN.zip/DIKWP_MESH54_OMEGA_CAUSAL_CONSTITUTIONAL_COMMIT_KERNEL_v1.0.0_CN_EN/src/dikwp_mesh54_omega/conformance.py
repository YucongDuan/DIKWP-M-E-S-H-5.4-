from __future__ import annotations

import json
import sqlite3
import tempfile
from pathlib import Path
from typing import Any, Callable

from .canonical import merkle_root, sha256_obj, write_json
from .demo import NODE_SEED, run_demo
from .models import CommitReceipt54, TransparencyCheckpointOmega54, verify_checkpoint54, verify_commit_receipt54
from .signing import Ed25519IdentityOmega54


def _check(name: str, predicate: Callable[[], bool], detail: str) -> dict[str, Any]:
    try:
        passed = bool(predicate())
        error = "" if passed else detail
    except Exception as exc:  # conformance must report, not abort on the first defect
        passed = False
        error = f"{type(exc).__name__}: {exc}"
    return {"name": name, "passed": passed, "detail": detail, "error": error}


def run_conformance(
    *,
    output_dir: str | Path | None = None,
    report_path: str | Path | None = None,
) -> dict[str, Any]:
    """Run the deterministic, self-contained Ω reference conformance lifecycle.

    This is an author-side executable reference (E2), not external replication.
    It intentionally exercises tamper rejection, crash rollback, process races,
    restart idempotency, checkpoint verification and split-view detection.
    """

    temporary: tempfile.TemporaryDirectory[str] | None = None
    if output_dir is None:
        temporary = tempfile.TemporaryDirectory(prefix="mesh54-omega-conformance-")
        out = Path(temporary.name)
    else:
        out = Path(output_dir)

    try:
        lifecycle = run_demo(out)
        summary = lifecycle["summary"]
        receipt_raw = json.loads((out / "accepted_receipt54omega.json").read_text(encoding="utf-8"))
        checkpoint_raw = json.loads((out / "checkpoint54omega.json").read_text(encoding="utf-8"))
        receipt = CommitReceipt54(**receipt_raw)
        checkpoint = TransparencyCheckpointOmega54(**checkpoint_raw)
        node_signer = Ed25519IdentityOmega54.from_seed("OMEGA-NODE", NODE_SEED)
        with sqlite3.connect(out / "mesh54_omega.sqlite") as connection:
            prefix_hashes = [
                str(row[0])
                for row in connection.execute(
                    "SELECT event_hash FROM events ORDER BY sequence LIMIT ?",
                    (checkpoint.tree_size,),
                ).fetchall()
            ]
        checkpoint_binds_prefix = (
            len(prefix_hashes) == checkpoint.tree_size
            and checkpoint.head_hash == (prefix_hashes[-1] if prefix_hashes else "0" * 64)
            and checkpoint.merkle_root == merkle_root(prefix_hashes)
            and checkpoint.tree_size + 1 == summary["event_count"]
        )

        body_without_hash = dict(summary)
        summary_hash = body_without_hash.pop("summary_hash")

        checks = [
            _check("framework-is-mesh54", lambda: summary["framework"] == "DIKWP-MESH 5.4", "framework marker must remain 5.4"),
            _check("system-is-omega-kernel", lambda: "Atomic Commit Kernel" in summary["system"], "system identity must be Ω atomic commit kernel"),
            _check("evidence-grade-is-e2", lambda: summary["evidence_grade"].startswith("E2"), "reference execution must not inflate evidence grade"),
            _check("tampered-outer-rejected", lambda: summary["tampered_outer_rejected"] is True, "tampered outer envelope must be rejected"),
            _check("tamper-does-not-burn-nonce", lambda: summary["tampered_outer_nonce_burn_prevented"] is True, "failed preflight must not consume nonce"),
            _check("valid-after-tamper-accepted", lambda: summary["valid_packet_accepted_after_tamper"] is True, "valid packet must remain admissible after tamper attempt"),
            _check("exact-replay-idempotent", lambda: summary["exact_replay_idempotent"] is True, "byte-equivalent claim replay must return the original receipt"),
            _check("restart-replay-idempotent", lambda: summary["restart_replay_idempotent"] is True, "idempotency must survive process restart"),
            _check("crash-transaction-rolled-back", lambda: summary["crash_rollback_verified"] is True, "injected crash must roll back nonce, lease and event"),
            _check("crash-retry-accepted", lambda: summary["crash_retry_accepted"] is True, "claim must be retryable after rollback"),
            _check("race-has-one-winner", lambda: summary["cross_process_race"]["accepted_count"] == 1, "same nonce across processes must have exactly one accepted claim"),
            _check("race-has-one-conflict", lambda: summary["cross_process_race"]["nonce_conflict_count"] == 1, "losing process must receive nonce conflict"),
            _check("split-view-detected", lambda: summary["split_view_detected"] is True, "divergent transparency histories must be detected"),
            _check("store-verification-pass", lambda: summary["store_verification"] == "PASS", "relational, cryptographic and event-chain invariants must pass"),
            _check("store-tamper-detected", lambda: summary["tampered_store_detected"] is True, "forensic verification must reject modified persistent state"),
            _check("expected-nonce-count", lambda: summary["committed_nonces"] == 3, "reference lifecycle must commit exactly three unique nonces"),
            _check("expected-lease-use-count", lambda: summary["lease_uses"] == 3, "lease accounting must match committed nonces"),
            _check("expected-event-count", lambda: summary["event_count"] == 12, "reference lifecycle event count must be deterministic"),
            _check("head-hash-shape", lambda: len(summary["head_hash"]) == 64, "event head must be SHA-256"),
            _check("merkle-root-shape", lambda: len(summary["merkle_root"]) == 64, "Merkle root must be SHA-256"),
            _check("summary-hash-valid", lambda: summary_hash == sha256_obj(body_without_hash), "summary hash must bind all reported results"),
            _check("receipt-decision-accepted", lambda: receipt.decision == "ACCEPTED", "reference receipt must record accepted decision"),
            _check("receipt-signature-valid", lambda: verify_commit_receipt54(receipt, node_signer.public_key_hex), "receipt signature and content hash must verify"),
            _check("checkpoint-signature-valid", lambda: verify_checkpoint54(checkpoint, node_signer.public_key_hex), "checkpoint signature and content hash must verify"),
            _check("checkpoint-binds-pre-issuance-prefix", lambda: checkpoint_binds_prefix, "checkpoint must bind the exact event prefix before its own issuance event"),
            _check("run-proof-present", lambda: (out / "RUN_PROOF54omega.json").is_file(), "run proof must be emitted"),
            _check("forensic-snapshot-present", lambda: (out / "forensic_snapshot" / "snapshot_summary.json").is_file(), "forensic snapshot must be emitted"),
            _check("open-obligations-declared", lambda: len(summary["open_obligations"]) >= 4, "reference must preserve explicit non-claims and deployment obligations"),
        ]
        failures = [item for item in checks if not item["passed"]]
        body = {
            "status": "PASS" if not failures else "FAIL",
            "framework": "DIKWP-MESH 5.4",
            "system": "DIKWP-MESH 5.4 Ω / Causal Constitutional Atomic Commit Kernel",
            "version": "1.0.0",
            "evidence_grade": "E2 author-side deterministic reference",
            "checks_total": len(checks),
            "checks_passed": len(checks) - len(failures),
            "checks_failed": len(failures),
            "checks": checks,
            "failures": [item["name"] for item in failures],
            "reference_summary_hash": summary_hash,
        }
        report = {**body, "report_hash": sha256_obj(body)}
        if report_path is not None:
            write_json(report_path, report)
        return report
    finally:
        if temporary is not None:
            temporary.cleanup()
