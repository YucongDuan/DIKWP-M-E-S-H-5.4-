from __future__ import annotations

import copy
import json
import multiprocessing as mp
import shutil
import sqlite3
from dataclasses import asdict
from importlib.resources import files
from pathlib import Path
from typing import Any

from .canonical import sha256_file, sha256_obj, write_json
from .checkpoint import compare_checkpoints54
from .kernel import ConstitutionalCommitKernel54
from .mesh54_adapter import (
    attest_structural_preflight54,
    claim_from_governed_packet54,
    durable_lease_from_mesh54,
    structural_preflight54,
)
from .models import (
    AdmissionClaim54,
    PreflightAttestation54,
    attest_claim54,
    build_admission_claim54,
    build_admission_policy54,
    build_validator_identity54,
)
from .signing import Ed25519IdentityOmega54
from .store import ConstitutionalStore54, InjectedCrash

REFERENCE_SECRET = b"mesh54-reference-packet-integrity-key"
NODE_ID = "mesh54-omega-reference-node"
NODE_SEED = "mesh54-omega-reference-node-seed"


def _resource_json(name: str) -> dict[str, Any]:
    resource = files("dikwp_mesh54_omega").joinpath("resources", "upstream_mesh54", name)
    return json.loads(resource.read_text(encoding="utf-8"))


def _validators():
    specs = [
        ("O54-REPLICATOR", "replicator", "ORG-A", "FUND-A", "SW-A", "DATA-A", "JUR-A"),
        ("O54-REDTEAM", "red-team", "ORG-B", "FUND-B", "SW-B", "DATA-B", "JUR-B"),
        ("O54-GOV", "governance", "ORG-C", "FUND-C", "SW-C", "DATA-C", "JUR-C"),
        ("O54-AFFECTED", "affected-party", "ORG-D", "FUND-D", "SW-D", "DATA-D", "JUR-D"),
    ]
    signers = []
    identities = []
    for validator_id, role, org, fund, software, data, jurisdiction in specs:
        signer = Ed25519IdentityOmega54.from_seed(validator_id, f"mesh54-omega-reference:{validator_id}")
        identity = build_validator_identity54(
            signer,
            role=role,
            organization_id=org,
            funding_domain=fund,
            software_lineage=software,
            data_lineage=data,
            jurisdiction=jurisdiction,
        )
        signers.append(signer)
        identities.append(identity)
    return signers, identities


def _approve_all(signers, identities, claim: AdmissionClaim54, *, checked_at: int, expires_at: int):
    return [
        attest_claim54(
            signer,
            identity,
            claim,
            "APPROVE",
            evidence_hashes=[claim.envelope_hash, *claim.upstream_evidence_hashes],
            checked_at=checked_at,
            expires_at=expires_at,
        )
        for signer, identity in zip(signers, identities)
    ]


def _synthetic_claim(original: AdmissionClaim54, *, envelope_id: str, envelope_hash: str, nonce: str, logical_time: int):
    return build_admission_claim54(
        envelope_id=envelope_id,
        envelope_hash=envelope_hash,
        mesh54_envelope_hash=original.mesh54_envelope_hash,
        nonce=nonce,
        lease_id=original.lease_id,
        channel_id=original.channel_id,
        chart_id=original.chart_id,
        relation_ids=original.relation_ids,
        intent_covenant_hash=original.intent_covenant_hash,
        atlas_hash=original.atlas_hash,
        closure_hash=original.closure_hash,
        gossip_checkpoint_hash=original.gossip_checkpoint_hash,
        residual_used=0.0,
        logical_time=logical_time,
        policy_epoch=original.policy_epoch,
        upstream_evidence_hashes=original.upstream_evidence_hashes,
    )


def _race_worker(database: str, claim_raw: dict, attestations_raw: list[dict], queue) -> None:
    signer = Ed25519IdentityOmega54.from_seed("OMEGA-NODE", NODE_SEED)
    kernel = ConstitutionalCommitKernel54(database, node_id=NODE_ID, node_signer=signer)
    claim = AdmissionClaim54(**claim_raw)
    attestations = [PreflightAttestation54(**item) for item in attestations_raw]
    result = kernel.admit(claim, attestations, logical_time=130)
    queue.put(
        {
            "decision": result.receipt.decision,
            "code": result.receipt.code,
            "receipt_id": result.receipt.receipt_id,
            "idempotent": result.idempotent,
        }
    )


def _run_race(database: Path, signers, identities, original: AdmissionClaim54) -> dict[str, Any]:
    left = _synthetic_claim(
        original,
        envelope_id="GPE54O-RACE-LEFT",
        envelope_hash="a" * 64,
        nonce="omega-cross-process-shared-nonce",
        logical_time=130,
    )
    right = _synthetic_claim(
        original,
        envelope_id="GPE54O-RACE-RIGHT",
        envelope_hash="b" * 64,
        nonce="omega-cross-process-shared-nonce",
        logical_time=130,
    )
    context = mp.get_context("spawn")
    queue = context.Queue()
    processes = []
    for claim in (left, right):
        attestations = _approve_all(signers, identities, claim, checked_at=130, expires_at=180)
        process = context.Process(
            target=_race_worker,
            args=(str(database), asdict(claim), [asdict(item) for item in attestations], queue),
        )
        processes.append(process)
        process.start()
    for process in processes:
        process.join(30)
        if process.exitcode != 0:
            raise RuntimeError(f"race worker exited with code {process.exitcode}")
    results = [queue.get(timeout=5) for _ in processes]
    return {
        "claims": [left, right],
        "results": sorted(results, key=lambda item: (item["decision"], item["receipt_id"])),
        "accepted_count": sum(item["decision"] == "ACCEPTED" for item in results),
        "nonce_conflict_count": sum(item["code"] == "REJECT_NONCE_CONFLICT" for item in results),
    }


def _copy_database(source: Path, destination: Path) -> None:
    with sqlite3.connect(source) as source_connection, sqlite3.connect(destination) as destination_connection:
        source_connection.backup(destination_connection)


def run_demo(outdir: str | Path) -> dict[str, Any]:
    out = Path(outdir)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    packet = _resource_json("governed_packet54.json")
    upstream_lease = _resource_json("capability_lease54.json")
    node_signer = Ed25519IdentityOmega54.from_seed("OMEGA-NODE", NODE_SEED)
    database = out / "mesh54_omega.sqlite"
    kernel = ConstitutionalCommitKernel54(database, node_id=NODE_ID, node_signer=node_signer)
    policy = build_admission_policy54(epoch=1, issued_at=0, expires_at=10_000)
    kernel.activate_policy(policy, logical_time=0)

    signers, identities = _validators()
    for index, identity in enumerate(identities, start=1):
        kernel.register_validator(identity, logical_time=index)

    durable_lease = durable_lease_from_mesh54(
        upstream_lease,
        packet,
        policy_epoch=1,
        max_residual_budget=0.03,
        max_uses=5,
    )
    kernel.register_lease(durable_lease, logical_time=10)

    valid_claim = claim_from_governed_packet54(
        packet,
        durable_lease_id=durable_lease.lease_id,
        policy_epoch=1,
        logical_time=104,
        residual_used=0.0,
    )

    tampered_packet = copy.deepcopy(packet)
    tampered_packet["relation_ids"] = ["REL-RESIDUAL-HONESTY"]
    tampered_claim = claim_from_governed_packet54(
        tampered_packet,
        durable_lease_id=durable_lease.lease_id,
        policy_epoch=1,
        logical_time=103,
        residual_used=0.0,
    )
    tampered_preflight = structural_preflight54(
        tampered_packet,
        upstream_lease,
        integrity_secret=REFERENCE_SECRET,
        logical_time=103,
    )
    tampered_attestations = [
        attest_structural_preflight54(
            signer,
            identity,
            tampered_claim,
            tampered_packet,
            upstream_lease,
            integrity_secret=REFERENCE_SECRET,
            checked_at=103,
            expires_at=120,
        )
        for signer, identity in zip(signers, identities)
    ]
    tampered_result = kernel.admit(tampered_claim, tampered_attestations, logical_time=103)
    nonce_count_after_tamper = kernel.status()["committed_nonce_count"]

    valid_preflight = structural_preflight54(
        packet,
        upstream_lease,
        integrity_secret=REFERENCE_SECRET,
        logical_time=104,
    )
    valid_attestations = [
        attest_structural_preflight54(
            signer,
            identity,
            valid_claim,
            packet,
            upstream_lease,
            integrity_secret=REFERENCE_SECRET,
            checked_at=104,
            expires_at=120,
        )
        for signer, identity in zip(signers, identities)
    ]
    accepted_result = kernel.admit(valid_claim, valid_attestations, logical_time=104)
    replay_result = kernel.admit(valid_claim, valid_attestations, logical_time=105)

    crash_claim = _synthetic_claim(
        valid_claim,
        envelope_id="GPE54O-CRASH-RECOVERY",
        envelope_hash="c" * 64,
        nonce="omega-crash-recovery-nonce",
        logical_time=110,
    )
    crash_attestations = _approve_all(signers, identities, crash_claim, checked_at=110, expires_at=160)
    status_before_crash = kernel.status()
    crash_error = ""
    try:
        kernel.admit(crash_claim, crash_attestations, logical_time=110, fault_stage="after_nonce")
    except InjectedCrash as exc:
        crash_error = str(exc)
    status_after_crash = kernel.status()
    crash_retry = kernel.admit(crash_claim, crash_attestations, logical_time=110)

    restarted = ConstitutionalCommitKernel54(database, node_id=NODE_ID, node_signer=node_signer)
    restart_replay = restarted.admit(crash_claim, crash_attestations, logical_time=111)

    race = _run_race(database, signers, identities, valid_claim)
    checkpoint = restarted.checkpoint(logical_time=140)
    verification = restarted.verify_store(checked_at=141)
    snapshot_summary = restarted.store.export_snapshot(out / "forensic_snapshot", checked_at=142)

    # Produce two equal-size divergent views and prove the split.
    left_db = out / "split_left.sqlite"
    right_db = out / "split_right.sqlite"
    _copy_database(database, left_db)
    _copy_database(database, right_db)
    left = ConstitutionalCommitKernel54(left_db, node_id=NODE_ID, node_signer=node_signer)
    right = ConstitutionalCommitKernel54(right_db, node_id=NODE_ID, node_signer=node_signer)
    left.revoke("ENVELOPE", "LEFT-BRANCH", reason="left branch fixture", policy_epoch=1, effective_at=150)
    right.revoke("ENVELOPE", "RIGHT-BRANCH", reason="right branch fixture", policy_epoch=1, effective_at=150)
    left_checkpoint = left.checkpoint(logical_time=151)
    right_checkpoint = right.checkpoint(logical_time=151)
    split_comparison = compare_checkpoints54(
        left_checkpoint,
        right_checkpoint,
        left_public_key=node_signer.public_key_hex,
        right_public_key=node_signer.public_key_hex,
        left_event_hashes=left.store.event_hashes(prefix_size=left_checkpoint.tree_size),
        right_event_hashes=right.store.event_hashes(prefix_size=right_checkpoint.tree_size),
    )

    # Forensic corruption fixture: counter tamper must fail verification.
    tamper_db = out / "tampered_store.sqlite"
    _copy_database(database, tamper_db)
    with sqlite3.connect(tamper_db) as connection:
        connection.execute("UPDATE leases SET uses=uses+9 WHERE lease_id=?", (durable_lease.lease_id,))
        connection.commit()
    tampered_store = ConstitutionalStore54(
        tamper_db,
        node_id=NODE_ID,
        node_signer=node_signer,
    )
    tamper_report = tampered_store.verify(checked_at=160)

    final_status = restarted.status()
    summary = {
        "system": "DIKWP-MESH 5.4 Ω / Causal Constitutional Atomic Commit Kernel",
        "version": "1.0.0",
        "framework": "DIKWP-MESH 5.4",
        "evidence_grade": "E2 author-side deterministic reference",
        "key_result": "nonce, lease use, admission receipt and evidence event commit atomically in one SQLite transaction",
        "tampered_outer_rejected": tampered_result.receipt.decision == "REJECTED",
        "tampered_outer_nonce_burn_prevented": nonce_count_after_tamper == 0,
        "valid_packet_accepted_after_tamper": accepted_result.receipt.decision == "ACCEPTED",
        "exact_replay_idempotent": replay_result.idempotent and replay_result.receipt.receipt_id == accepted_result.receipt.receipt_id,
        "crash_rollback_verified": (
            bool(crash_error)
            and status_before_crash["event_count"] == status_after_crash["event_count"]
            and status_before_crash["committed_nonce_count"] == status_after_crash["committed_nonce_count"]
        ),
        "crash_retry_accepted": crash_retry.receipt.decision == "ACCEPTED",
        "restart_replay_idempotent": restart_replay.idempotent,
        "cross_process_race": {
            "accepted_count": race["accepted_count"],
            "nonce_conflict_count": race["nonce_conflict_count"],
        },
        "split_view_detected": split_comparison.split_view_detected,
        "tampered_store_detected": tamper_report.status == "FAIL",
        "store_verification": verification.status,
        "committed_nonces": final_status["committed_nonce_count"],
        "lease_uses": next(item["uses"] for item in final_status["leases"] if item["lease_id"] == durable_lease.lease_id),
        "event_count": final_status["event_count"],
        "head_hash": final_status["head_hash"],
        "merkle_root": final_status["merkle_root"],
        "open_obligations": [
            "SQLite supplies single-database serializability, not multi-node consensus",
            "reference validators are simulated identities and do not constitute external replication",
            "structural preflight does not replace full causal matrix and rollback validation",
            "production key custody, authenticated networking and external security review remain required",
        ],
    }
    summary["summary_hash"] = sha256_obj(summary)

    artifacts = {
        "admission_policy54omega.json": policy,
        "validator_identities54omega.json": identities,
        "durable_lease54omega.json": durable_lease,
        "tampered_claim54omega.json": tampered_claim,
        "tampered_preflight54omega.json": tampered_preflight,
        "tampered_receipt54omega.json": tampered_result.receipt,
        "valid_claim54omega.json": valid_claim,
        "valid_preflight54omega.json": valid_preflight,
        "valid_attestations54omega.json": valid_attestations,
        "accepted_receipt54omega.json": accepted_result.receipt,
        "idempotent_replay54omega.json": replay_result,
        "crash_recovery54omega.json": {
            "fault": crash_error,
            "status_before": status_before_crash,
            "status_after_rollback": status_after_crash,
            "retry_receipt": crash_retry.receipt,
            "restart_replay": restart_replay,
        },
        "cross_process_race54omega.json": race,
        "checkpoint54omega.json": checkpoint,
        "split_view54omega.json": {
            "left_checkpoint": left_checkpoint,
            "right_checkpoint": right_checkpoint,
            "comparison": split_comparison,
        },
        "tamper_detection54omega.json": tamper_report,
        "store_verification54omega.json": verification,
        "store_status54omega.json": final_status,
        "snapshot_summary54omega.json": snapshot_summary,
        "summary54omega.json": summary,
    }
    for name, value in artifacts.items():
        write_json(out / name, value)

    proof = {
        "summary_hash": summary["summary_hash"],
        "database_sha256": sha256_file(database),
        "checkpoint_hash": checkpoint.checkpoint_hash,
        "accepted_receipt_hash": accepted_result.receipt.receipt_hash,
        "crash_retry_receipt_hash": crash_retry.receipt.receipt_hash,
        "store_report_hash": verification.report_hash,
        "snapshot_hash": snapshot_summary["snapshot_hash"],
    }
    proof["run_proof_hash"] = sha256_obj(proof)
    write_json(out / "RUN_PROOF54omega.json", proof)
    return {"summary": summary, "proof": proof, "artifacts": sorted(artifacts)}
