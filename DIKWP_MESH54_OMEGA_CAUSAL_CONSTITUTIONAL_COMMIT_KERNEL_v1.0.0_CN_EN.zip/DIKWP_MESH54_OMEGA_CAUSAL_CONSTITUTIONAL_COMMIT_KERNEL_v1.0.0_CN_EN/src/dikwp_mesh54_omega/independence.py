from __future__ import annotations

from collections import deque
from dataclasses import replace
from typing import Mapping, Sequence

from .canonical import sha256_obj, sorted_unique
from .models import (
    AdmissionClaim54,
    AdmissionPolicy54,
    IndependenceAssessment54,
    PreflightAttestation54,
    ValidatorIdentity54,
    independence_assessment_body,
    verify_admission_claim54,
    verify_admission_policy54,
    verify_preflight_attestation54,
)

_SHARED_DOMAINS = (
    "organization_id",
    "funding_domain",
    "software_lineage",
    "data_lineage",
    "jurisdiction",
)


def _shared_domains(left: ValidatorIdentity54, right: ValidatorIdentity54) -> list[str]:
    return [field for field in _SHARED_DOMAINS if getattr(left, field) and getattr(left, field) == getattr(right, field)]


def evaluate_independence54(
    claim: AdmissionClaim54,
    policy: AdmissionPolicy54,
    attestations: Sequence[PreflightAttestation54],
    identities: Mapping[str, ValidatorIdentity54],
    *,
    logical_time: int,
    revoked_validator_ids: Sequence[str] = (),
) -> IndependenceAssessment54:
    if not verify_admission_claim54(claim):
        raise ValueError("claim is invalid")
    if not verify_admission_policy54(policy):
        raise ValueError("policy is invalid")

    revoked = set(str(item) for item in revoked_validator_ids)
    valid: list[PreflightAttestation54] = []
    seen_attestation_ids: set[str] = set()
    for item in attestations:
        identity = identities.get(item.validator_id)
        if item.attestation_id in seen_attestation_ids or identity is None:
            continue
        seen_attestation_ids.add(item.attestation_id)
        if item.validator_id in revoked:
            continue
        if not verify_preflight_attestation54(item, identity):
            continue
        if item.claim_hash != claim.claim_hash or item.policy_epoch != policy.epoch:
            continue
        if not item.checked_at <= logical_time < item.expires_at:
            continue
        if logical_time - item.checked_at > policy.max_attestation_age:
            continue
        valid.append(item)

    by_validator: dict[str, list[PreflightAttestation54]] = {}
    for item in valid:
        by_validator.setdefault(item.validator_id, []).append(item)

    denying_ids = sorted(
        validator_id
        for validator_id, items in by_validator.items()
        if any(item.verdict == "DENY" for item in items)
    )
    approving_ids = sorted(
        validator_id
        for validator_id, items in by_validator.items()
        if any(item.verdict == "APPROVE" for item in items) and validator_id not in denying_ids
    )

    graph: dict[str, set[str]] = {validator_id: set() for validator_id in approving_ids}
    conflict_edges: list[list[str]] = []
    for index, left_id in enumerate(approving_ids):
        for right_id in approving_ids[index + 1 :]:
            shared = _shared_domains(identities[left_id], identities[right_id])
            if shared:
                graph[left_id].add(right_id)
                graph[right_id].add(left_id)
                conflict_edges.append([left_id, right_id, *sorted(shared)])

    components: list[list[str]] = []
    unseen = set(approving_ids)
    while unseen:
        start = min(unseen)
        queue = deque([start])
        component: set[str] = set()
        while queue:
            current = queue.popleft()
            if current in component:
                continue
            component.add(current)
            queue.extend(sorted(graph[current] - component))
        unseen -= component
        components.append(sorted(component))
    components.sort(key=lambda group: group[0] if group else "")

    roles_present = sorted_unique(identities[item].role for item in approving_ids)
    reasons: list[str] = []
    if policy.deny_veto and denying_ids:
        reasons.append("valid DENY attestation triggered the constitutional veto")
    missing_roles = sorted(set(policy.required_roles) - set(roles_present))
    if missing_roles:
        reasons.append("required validator roles are missing: " + ",".join(missing_roles))
    if len(components) < policy.required_independent_approvals:
        reasons.append("effective independent validator components are below policy threshold")

    status = "MET" if not reasons else "NOT_MET"
    evidence_hashes = sorted_unique(
        [identities[validator_id].identity_hash for validator_id in sorted(set(approving_ids + denying_ids))]
        + [item.attestation_hash for item in valid]
    )
    provisional = IndependenceAssessment54(
        assessment_id="",
        claim_hash=claim.claim_hash,
        approving_validator_ids=approving_ids,
        denying_validator_ids=denying_ids,
        conflict_edges=conflict_edges,
        independent_components=components,
        roles_present=roles_present,
        effective_independent_count=len(components),
        required_independent_count=policy.required_independent_approvals,
        status=status,
        reasons=reasons,
        evidence_hashes=evidence_hashes,
        assessment_hash="",
    )
    digest = sha256_obj(independence_assessment_body(provisional))
    return replace(provisional, assessment_id=f"IA54O-{digest[:14]}", assessment_hash=digest)
