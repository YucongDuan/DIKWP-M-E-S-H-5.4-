from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .canonical import canonical_json_bytes, sha256_bytes


@dataclass(frozen=True)
class Ed25519IdentityOmega54:
    identity_id: str
    private_key: Ed25519PrivateKey
    public_key_hex: str
    key_fingerprint: str

    @classmethod
    def from_seed(cls, identity_id: str, seed: str | bytes) -> "Ed25519IdentityOmega54":
        raw = seed.encode("utf-8") if isinstance(seed, str) else bytes(seed)
        private_bytes = hashlib.sha256(b"mesh54-omega-ed25519:" + raw).digest()
        private = Ed25519PrivateKey.from_private_bytes(private_bytes)
        public_bytes = private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return cls(
            identity_id=str(identity_id),
            private_key=private,
            public_key_hex=public_bytes.hex(),
            key_fingerprint=sha256_bytes(public_bytes),
        )

    @classmethod
    def from_private_key_hex(cls, identity_id: str, private_key_hex: str) -> "Ed25519IdentityOmega54":
        private = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(private_key_hex))
        public_bytes = private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return cls(
            identity_id=str(identity_id),
            private_key=private,
            public_key_hex=public_bytes.hex(),
            key_fingerprint=sha256_bytes(public_bytes),
        )

    def private_key_hex(self) -> str:
        return self.private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        ).hex()

    def sign(self, payload: object) -> str:
        return base64.b64encode(self.private_key.sign(canonical_json_bytes(payload))).decode("ascii")


def verify_ed25519(public_key_hex: str, payload: object, signature_b64: str) -> bool:
    try:
        public = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key_hex))
        public.verify(base64.b64decode(signature_b64.encode("ascii"), validate=True), canonical_json_bytes(payload))
        return True
    except Exception:
        return False
