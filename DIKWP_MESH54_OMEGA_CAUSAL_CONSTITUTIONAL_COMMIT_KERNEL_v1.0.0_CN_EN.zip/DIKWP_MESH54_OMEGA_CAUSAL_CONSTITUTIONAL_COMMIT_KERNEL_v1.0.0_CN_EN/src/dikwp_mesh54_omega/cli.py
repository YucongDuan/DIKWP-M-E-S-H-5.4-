from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from . import __version__
from .canonical import read_json, to_builtin, write_json
from .conformance import run_conformance
from .demo import run_demo
from .kernel import ConstitutionalCommitKernel54
from .models import AdmissionClaim54, PreflightAttestation54
from .service import serve
from .signing import Ed25519IdentityOmega54


def _kernel(args) -> ConstitutionalCommitKernel54:
    seed = args.node_seed or os.environ.get("MESH54_OMEGA_NODE_SEED", "")
    if not seed:
        raise ValueError("node seed is required through --node-seed or MESH54_OMEGA_NODE_SEED")
    signer = Ed25519IdentityOmega54.from_seed(args.node_id, seed)
    return ConstitutionalCommitKernel54(args.database, node_id=args.node_id, node_signer=signer)


def _print(value) -> None:
    print(json.dumps(to_builtin(value), ensure_ascii=False, indent=2, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mesh54-omega", description="DIKWP-MESH 5.4 Omega constitutional commit kernel")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    demo = sub.add_parser("demo", help="run the deterministic end-to-end reference lifecycle")
    demo.add_argument("--out", default="outputs/demo", help="output directory")

    conformance = sub.add_parser("conformance", help="run the self-contained 28-check Ω conformance lifecycle")
    conformance.add_argument("--out", default="", help="optional retained lifecycle output directory")
    conformance.add_argument("--report", default="", help="optional JSON report path")

    artifacts = sub.add_parser("artifacts-validate", help="validate all published JSON Schemas and examples")
    artifacts.add_argument("--root", default=".", help="release root containing schemas/ and examples/")
    artifacts.add_argument("--output", default="", help="optional JSON report path")

    for name, help_text in [
        ("status", "show durable node status"),
        ("verify", "verify SQLite integrity, event chain, signatures and relational invariants"),
        ("checkpoint", "issue a signed transparency checkpoint"),
        ("export", "export a forensic snapshot"),
        ("admit", "atomically admit a claim and its validator attestations"),
        ("serve", "serve the authenticated local JSON API"),
    ]:
        item = sub.add_parser(name, help=help_text)
        item.add_argument("--database", required=True)
        item.add_argument("--node-id", required=True)
        item.add_argument("--node-seed", default="")
        if name in {"checkpoint"}:
            item.add_argument("--logical-time", type=int, required=True)
        if name == "export":
            item.add_argument("--out", required=True)
            item.add_argument("--checked-at", type=int, default=0)
        if name == "admit":
            item.add_argument("--claim", required=True)
            item.add_argument("--attestations", required=True)
            item.add_argument("--logical-time", type=int, required=True)
            item.add_argument("--output", default="")
        if name == "serve":
            item.add_argument("--host", default="127.0.0.1")
            item.add_argument("--port", type=int, default=8754)
            item.add_argument("--token", default="")
            item.add_argument("--token-env", default="MESH54_OMEGA_API_TOKEN")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "demo":
        result = run_demo(args.out)
        _print(result)
        return 0
    if args.command == "conformance":
        result = run_conformance(
            output_dir=args.out or None,
            report_path=args.report or None,
        )
        _print(result)
        return 0 if result["status"] == "PASS" else 2
    if args.command == "artifacts-validate":
        from .validation import validate_artifacts

        result = validate_artifacts(args.root, output=args.output or None)
        _print(result)
        return 0 if result["status"] == "PASS" else 2
    kernel = _kernel(args)
    if args.command == "status":
        _print(kernel.status())
    elif args.command == "verify":
        report = kernel.verify_store()
        _print(report)
        return 0 if report.status == "PASS" else 2
    elif args.command == "checkpoint":
        _print(kernel.checkpoint(logical_time=args.logical_time))
    elif args.command == "export":
        _print(kernel.store.export_snapshot(args.out, checked_at=args.checked_at))
    elif args.command == "admit":
        claim = AdmissionClaim54(**read_json(args.claim))
        raw_attestations = read_json(args.attestations)
        attestations = [PreflightAttestation54(**item) for item in raw_attestations]
        result = kernel.admit(claim, attestations, logical_time=args.logical_time)
        if args.output:
            write_json(args.output, result)
        _print(result)
        return 0 if result.receipt.decision == "ACCEPTED" else 3
    elif args.command == "serve":
        token = args.token or os.environ.get(args.token_env, "")
        serve(kernel, host=args.host, port=args.port, bearer_token=token)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
