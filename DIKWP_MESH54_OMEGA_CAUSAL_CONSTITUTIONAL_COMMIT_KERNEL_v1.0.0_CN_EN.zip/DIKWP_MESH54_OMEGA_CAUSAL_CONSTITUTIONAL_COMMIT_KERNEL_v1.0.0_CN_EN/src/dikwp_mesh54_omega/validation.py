from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .canonical import sha256_obj, write_json


DEFAULT_PAIRS = {
    "validator_identity54omega.schema.json": "validator_identity54omega_example.json",
    "admission_policy54omega.schema.json": "admission_policy54omega_example.json",
    "durable_lease54omega.schema.json": "durable_lease54omega_example.json",
    "admission_claim54omega.schema.json": "admission_claim54omega_example.json",
    "preflight_attestation54omega.schema.json": "preflight_attestation54omega_example.json",
    "independence_assessment54omega.schema.json": "independence_assessment54omega_example.json",
    "commit_receipt54omega.schema.json": "commit_receipt54omega_example.json",
    "checkpoint54omega.schema.json": "checkpoint54omega_example.json",
    "checkpoint_comparison54omega.schema.json": "checkpoint_comparison54omega_example.json",
    "store_verification54omega.schema.json": "store_verification54omega_example.json",
}


def validate_artifacts(root: str | Path, *, output: str | Path | None = None) -> dict[str, Any]:
    base = Path(root)
    failures: list[str] = []
    results: list[dict[str, Any]] = []
    for schema_name, example_name in DEFAULT_PAIRS.items():
        schema_path = base / "schemas" / schema_name
        example_path = base / "examples" / example_name
        entry = {"schema": schema_name, "example": example_name, "passed": False, "errors": []}
        if not schema_path.is_file() or not example_path.is_file():
            entry["errors"].append("schema or example file is missing")
        else:
            try:
                schema = json.loads(schema_path.read_text(encoding="utf-8"))
                example = json.loads(example_path.read_text(encoding="utf-8"))
                Draft202012Validator.check_schema(schema)
                errors = sorted(Draft202012Validator(schema).iter_errors(example), key=lambda item: list(item.path))
                entry["errors"] = [error.message for error in errors]
            except Exception as exc:
                entry["errors"].append(f"{type(exc).__name__}: {exc}")
        entry["passed"] = not entry["errors"]
        if not entry["passed"]:
            failures.append(f"{schema_name}: " + "; ".join(entry["errors"]))
        results.append(entry)
    body = {
        "status": "PASS" if not failures else "FAIL",
        "schemas_checked": len(results),
        "passed": sum(item["passed"] for item in results),
        "failed": sum(not item["passed"] for item in results),
        "results": results,
        "failures": failures,
    }
    report = {**body, "report_hash": sha256_obj(body)}
    if output is not None:
        write_json(output, report)
    return report
