from __future__ import annotations

import json
import shutil
import sqlite3
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable, Sequence

from .canonical import ZERO_HASH, canonical_json, merkle_root, sha256_obj, to_builtin, write_json
from .independence import evaluate_independence54
from .models import (
    AdmissionClaim54,
    AdmissionPolicy54,
    AdmissionResult54,
    CommitReceipt54,
    DurableLease54,
    IndependenceAssessment54,
    PreflightAttestation54,
    StoreVerificationReport54,
    TransparencyCheckpointOmega54,
    ValidatorIdentity54,
    build_admission_policy54,
    sign_checkpoint54,
    sign_commit_receipt54,
    verify_admission_claim54,
    verify_admission_policy54,
    verify_checkpoint54,
    verify_commit_receipt54,
    verify_durable_lease54,
    verify_preflight_attestation54,
    verify_validator_identity54,
    independence_assessment_body,
)
from .signing import Ed25519IdentityOmega54


class StoreCorruptionError(RuntimeError):
    pass


class InjectedCrash(RuntimeError):
    pass


_SCHEMA_VERSION = "1"
_ALLOWED_REVOCATION_TYPES = {"VALIDATOR", "LEASE", "CHANNEL", "ENVELOPE", "POLICY"}


class ConstitutionalStore54:
    """Crash-consistent, multi-process-safe MESH 5.4 Omega state store.

    SQLite is operated in WAL mode with FULL synchronous writes. Every mutation
    is coupled to a hash-chained event in the same transaction. This is a
    single-database coordination primitive, not a distributed consensus claim.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        node_id: str,
        node_signer: Ed25519IdentityOmega54,
        log_id: str = "DIKWP-MESH54-OMEGA-COMMIT-LOG",
        timeout: float = 30.0,
    ) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.node_id = str(node_id)
        self.node_signer = node_signer
        self.log_id = str(log_id)
        self.timeout = float(timeout)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            str(self.path),
            timeout=self.timeout,
            isolation_level=None,
            check_same_thread=False,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA busy_timeout=30000")
        connection.execute("PRAGMA trusted_schema=OFF")
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS policies (
                    policy_hash TEXT PRIMARY KEY,
                    epoch INTEGER NOT NULL UNIQUE,
                    policy_json TEXT NOT NULL,
                    active INTEGER NOT NULL CHECK(active IN (0, 1)),
                    activated_at INTEGER NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS one_active_policy
                    ON policies(active) WHERE active = 1;
                CREATE TABLE IF NOT EXISTS validators (
                    validator_id TEXT PRIMARY KEY,
                    identity_hash TEXT NOT NULL,
                    identity_json TEXT NOT NULL,
                    active INTEGER NOT NULL CHECK(active IN (0, 1)),
                    registered_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS leases (
                    lease_id TEXT PRIMARY KEY,
                    lease_hash TEXT NOT NULL,
                    lease_json TEXT NOT NULL,
                    uses INTEGER NOT NULL DEFAULT 0 CHECK(uses >= 0),
                    max_uses INTEGER NOT NULL CHECK(max_uses >= 1),
                    status TEXT NOT NULL,
                    policy_epoch INTEGER NOT NULL,
                    issued_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    registered_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS revocations (
                    revocation_id TEXT PRIMARY KEY,
                    object_type TEXT NOT NULL,
                    object_id TEXT NOT NULL,
                    policy_epoch INTEGER NOT NULL,
                    effective_at INTEGER NOT NULL,
                    reason TEXT NOT NULL,
                    event_sequence INTEGER
                );
                CREATE INDEX IF NOT EXISTS revocation_lookup
                    ON revocations(object_type, object_id, effective_at);
                CREATE TABLE IF NOT EXISTS attestations (
                    attestation_id TEXT PRIMARY KEY,
                    claim_hash TEXT NOT NULL,
                    validator_id TEXT NOT NULL,
                    attestation_json TEXT NOT NULL,
                    received_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS claims (
                    claim_hash TEXT PRIMARY KEY,
                    envelope_id TEXT NOT NULL UNIQUE,
                    nonce TEXT NOT NULL UNIQUE,
                    lease_id TEXT NOT NULL,
                    claim_json TEXT NOT NULL,
                    accepted_receipt_id TEXT,
                    committed_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS nonces (
                    nonce TEXT PRIMARY KEY,
                    claim_hash TEXT NOT NULL UNIQUE,
                    envelope_id TEXT NOT NULL,
                    lease_id TEXT NOT NULL,
                    committed_at INTEGER NOT NULL,
                    receipt_id TEXT
                );
                CREATE TABLE IF NOT EXISTS events (
                    sequence INTEGER PRIMARY KEY,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    payload_hash TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    event_hash TEXT NOT NULL UNIQUE,
                    logical_time INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS receipts (
                    receipt_id TEXT PRIMARY KEY,
                    claim_hash TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    receipt_json TEXT NOT NULL,
                    assessment_json TEXT NOT NULL,
                    event_sequence INTEGER NOT NULL,
                    created_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS receipts_by_claim ON receipts(claim_hash, decision);
                CREATE TABLE IF NOT EXISTS checkpoints (
                    checkpoint_id TEXT PRIMARY KEY,
                    tree_size INTEGER NOT NULL,
                    checkpoint_json TEXT NOT NULL,
                    covered_head_hash TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );
                """
            )
            expected_meta = {
                "schema_version": _SCHEMA_VERSION,
                "framework_version": "DIKWP-MESH 5.4 Ω",
                "node_id": self.node_id,
                "node_public_key": self.node_signer.public_key_hex,
                "node_key_fingerprint": self.node_signer.key_fingerprint,
                "log_id": self.log_id,
            }
            for key, value in expected_meta.items():
                row = connection.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
                if row is None:
                    connection.execute("INSERT INTO meta(key, value) VALUES (?, ?)", (key, str(value)))
                elif row["value"] != str(value):
                    connection.rollback()
                    raise StoreCorruptionError(f"store metadata mismatch for {key}")
            connection.commit()

    @staticmethod
    def _row_to_policy(row: sqlite3.Row) -> AdmissionPolicy54:
        return AdmissionPolicy54(**json.loads(row["policy_json"]))

    @staticmethod
    def _row_to_lease(row: sqlite3.Row) -> DurableLease54:
        return DurableLease54(**json.loads(row["lease_json"]))

    @staticmethod
    def _row_to_identity(row: sqlite3.Row) -> ValidatorIdentity54:
        return ValidatorIdentity54(**json.loads(row["identity_json"]))

    @staticmethod
    def _row_to_receipt(row: sqlite3.Row) -> CommitReceipt54:
        return CommitReceipt54(**json.loads(row["receipt_json"]))

    @staticmethod
    def _row_to_assessment(row: sqlite3.Row) -> IndependenceAssessment54:
        return IndependenceAssessment54(**json.loads(row["assessment_json"]))

    def _append_event(
        self,
        connection: sqlite3.Connection,
        event_type: str,
        payload: Any,
        *,
        logical_time: int,
    ) -> tuple[int, str]:
        last = connection.execute(
            "SELECT sequence, event_hash FROM events ORDER BY sequence DESC LIMIT 1"
        ).fetchone()
        sequence = 1 if last is None else int(last["sequence"]) + 1
        previous_hash = ZERO_HASH if last is None else str(last["event_hash"])
        payload_json = canonical_json(payload)
        payload_hash = sha256_obj(json.loads(payload_json))
        event_hash = sha256_obj(
            {
                "sequence": sequence,
                "event_type": str(event_type),
                "payload_hash": payload_hash,
                "previous_hash": previous_hash,
                "logical_time": int(logical_time),
            }
        )
        connection.execute(
            "INSERT INTO events(sequence,event_type,payload_json,payload_hash,previous_hash,event_hash,logical_time) "
            "VALUES (?,?,?,?,?,?,?)",
            (sequence, str(event_type), payload_json, payload_hash, previous_hash, event_hash, int(logical_time)),
        )
        return sequence, event_hash

    def _active_policy(self, connection: sqlite3.Connection) -> AdmissionPolicy54:
        row = connection.execute("SELECT * FROM policies WHERE active=1").fetchone()
        if row is None:
            raise PermissionError("no active constitutional admission policy")
        policy = self._row_to_policy(row)
        if not verify_admission_policy54(policy):
            raise StoreCorruptionError("active policy hash is invalid")
        return policy

    def register_validator(self, identity: ValidatorIdentity54, *, logical_time: int = 0) -> None:
        if not verify_validator_identity54(identity):
            raise ValueError("validator identity is invalid")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT identity_hash FROM validators WHERE validator_id=?", (identity.validator_id,)
            ).fetchone()
            if existing is not None:
                if existing["identity_hash"] != identity.identity_hash:
                    connection.rollback()
                    raise ValueError("validator id is already bound to another identity")
                connection.commit()
                return
            connection.execute(
                "INSERT INTO validators(validator_id,identity_hash,identity_json,active,registered_at) VALUES (?,?,?,?,?)",
                (identity.validator_id, identity.identity_hash, canonical_json(identity), 1, int(logical_time)),
            )
            self._append_event(connection, "VALIDATOR_REGISTERED", identity, logical_time=logical_time)
            connection.commit()

    def activate_policy(self, policy: AdmissionPolicy54, *, logical_time: int = 0) -> None:
        if not verify_admission_policy54(policy):
            raise ValueError("admission policy is invalid")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT * FROM policies WHERE epoch=?", (policy.epoch,)).fetchone()
            if existing is not None:
                current = self._row_to_policy(existing)
                if current.policy_hash != policy.policy_hash:
                    connection.rollback()
                    raise ValueError("policy epoch is already bound to a different policy")
                if int(existing["active"]) != 1:
                    connection.rollback()
                    raise ValueError("a retired policy epoch cannot be reactivated; issue a new epoch")
                connection.commit()
                return
            max_epoch_row = connection.execute("SELECT MAX(epoch) AS max_epoch FROM policies").fetchone()
            max_epoch = int(max_epoch_row["max_epoch"] or 0)
            if policy.epoch <= max_epoch:
                connection.rollback()
                raise ValueError("new policy epoch must be greater than every previously stored epoch")
            connection.execute("UPDATE policies SET active=0")
            connection.execute(
                "INSERT INTO policies(policy_hash,epoch,policy_json,active,activated_at) VALUES (?,?,?,?,?)",
                (policy.policy_hash, policy.epoch, canonical_json(policy), 1, int(logical_time)),
            )
            self._append_event(connection, "POLICY_ACTIVATED", policy, logical_time=logical_time)
            connection.commit()

    def register_lease(self, lease: DurableLease54, *, logical_time: int = 0) -> None:
        if not verify_durable_lease54(lease):
            raise ValueError("durable lease is invalid")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            policy = connection.execute("SELECT policy_hash FROM policies WHERE epoch=?", (lease.policy_epoch,)).fetchone()
            if policy is None:
                connection.rollback()
                raise ValueError("lease references an unknown policy epoch")
            existing = connection.execute("SELECT lease_hash FROM leases WHERE lease_id=?", (lease.lease_id,)).fetchone()
            if existing is not None:
                if existing["lease_hash"] != lease.lease_hash:
                    connection.rollback()
                    raise ValueError("lease id is already bound to another lease")
                connection.commit()
                return
            connection.execute(
                "INSERT INTO leases(lease_id,lease_hash,lease_json,uses,max_uses,status,policy_epoch,issued_at,expires_at,registered_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (
                    lease.lease_id,
                    lease.lease_hash,
                    canonical_json(lease),
                    0,
                    lease.max_uses,
                    lease.status,
                    lease.policy_epoch,
                    lease.issued_at,
                    lease.expires_at,
                    int(logical_time),
                ),
            )
            self._append_event(connection, "LEASE_REGISTERED", lease, logical_time=logical_time)
            connection.commit()

    def revoke(
        self,
        object_type: str,
        object_id: str,
        *,
        reason: str,
        policy_epoch: int,
        effective_at: int,
    ) -> str:
        object_type = str(object_type).upper()
        if object_type not in _ALLOWED_REVOCATION_TYPES:
            raise ValueError(f"unsupported revocation type: {object_type}")
        body = {
            "object_type": object_type,
            "object_id": str(object_id),
            "policy_epoch": int(policy_epoch),
            "effective_at": int(effective_at),
            "reason": str(reason),
        }
        revocation_id = f"RV54O-{sha256_obj(body)[:14]}"
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT revocation_id FROM revocations WHERE revocation_id=?", (revocation_id,)
            ).fetchone()
            if existing is not None:
                connection.commit()
                return revocation_id
            sequence, _ = self._append_event(
                connection,
                "OBJECT_REVOKED",
                {"revocation_id": revocation_id, **body},
                logical_time=effective_at,
            )
            connection.execute(
                "INSERT INTO revocations(revocation_id,object_type,object_id,policy_epoch,effective_at,reason,event_sequence) "
                "VALUES (?,?,?,?,?,?,?)",
                (revocation_id, object_type, str(object_id), int(policy_epoch), int(effective_at), str(reason), sequence),
            )
            if object_type == "VALIDATOR":
                connection.execute("UPDATE validators SET active=0 WHERE validator_id=?", (str(object_id),))
            elif object_type == "LEASE":
                connection.execute("UPDATE leases SET status='REVOKED' WHERE lease_id=?", (str(object_id),))
            connection.commit()
        return revocation_id

    @staticmethod
    def _revocation_reasons(
        connection: sqlite3.Connection,
        claim: AdmissionClaim54,
        policy: AdmissionPolicy54,
        *,
        logical_time: int,
    ) -> list[str]:
        targets = [
            ("POLICY", policy.policy_hash),
            ("LEASE", claim.lease_id),
            ("CHANNEL", claim.channel_id),
            ("ENVELOPE", claim.envelope_id),
        ]
        reasons: list[str] = []
        for object_type, object_id in targets:
            row = connection.execute(
                "SELECT reason FROM revocations WHERE object_type=? AND object_id=? AND effective_at<=? "
                "ORDER BY effective_at DESC LIMIT 1",
                (object_type, object_id, int(logical_time)),
            ).fetchone()
            if row is not None:
                reasons.append(f"{object_type.lower()} is revoked: {row['reason']}")
        return reasons

    @staticmethod
    def _insert_attestations(
        connection: sqlite3.Connection,
        attestations: Sequence[PreflightAttestation54],
        *,
        received_at: int,
    ) -> None:
        for item in attestations:
            raw = canonical_json(item)
            existing = connection.execute(
                "SELECT attestation_json FROM attestations WHERE attestation_id=?", (item.attestation_id,)
            ).fetchone()
            if existing is None:
                connection.execute(
                    "INSERT INTO attestations(attestation_id,claim_hash,validator_id,attestation_json,received_at) "
                    "VALUES (?,?,?,?,?)",
                    (item.attestation_id, item.claim_hash, item.validator_id, raw, int(received_at)),
                )
            elif existing["attestation_json"] != raw:
                raise StoreCorruptionError("attestation id collision with different content")

    @staticmethod
    def _state_root(
        *,
        event_hash: str,
        policy_hash: str,
        decision: str,
        lease_id: str,
        lease_uses_after: int,
        committed_nonce_count_after: int,
    ) -> str:
        return sha256_obj(
            {
                "event_hash": event_hash,
                "policy_hash": policy_hash,
                "decision": decision,
                "lease_id": lease_id,
                "lease_uses_after": int(lease_uses_after),
                "committed_nonce_count_after": int(committed_nonce_count_after),
            }
        )

    def _persist_receipt(
        self,
        connection: sqlite3.Connection,
        receipt: CommitReceipt54,
        assessment: IndependenceAssessment54,
        *,
        created_at: int,
    ) -> None:
        connection.execute(
            "INSERT INTO receipts(receipt_id,claim_hash,decision,receipt_json,assessment_json,event_sequence,created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (
                receipt.receipt_id,
                receipt.claim_hash,
                receipt.decision,
                canonical_json(receipt),
                canonical_json(assessment),
                receipt.event_sequence,
                int(created_at),
            ),
        )

    def admit(
        self,
        claim: AdmissionClaim54,
        attestations: Sequence[PreflightAttestation54],
        *,
        logical_time: int,
        fault_stage: str | None = None,
    ) -> AdmissionResult54:
        if not verify_admission_claim54(claim):
            raise ValueError("admission claim is invalid")
        supplied_attestations = list(attestations)
        with self._connect() as connection:
            try:
                connection.execute("BEGIN IMMEDIATE")

                existing_claim = connection.execute(
                    "SELECT accepted_receipt_id FROM claims WHERE claim_hash=?", (claim.claim_hash,)
                ).fetchone()
                if existing_claim is not None and existing_claim["accepted_receipt_id"]:
                    row = connection.execute(
                        "SELECT * FROM receipts WHERE receipt_id=?", (existing_claim["accepted_receipt_id"],)
                    ).fetchone()
                    if row is None:
                        raise StoreCorruptionError("accepted claim has no receipt")
                    receipt = self._row_to_receipt(row)
                    assessment = self._row_to_assessment(row)
                    if not verify_commit_receipt54(receipt, self.node_signer.public_key_hex):
                        raise StoreCorruptionError("accepted claim receipt signature or hash is invalid")
                    if assessment.assessment_hash != sha256_obj(independence_assessment_body(assessment)):
                        raise StoreCorruptionError("accepted claim independence assessment hash is invalid")
                    connection.commit()
                    return AdmissionResult54(receipt=receipt, idempotent=True, assessment=assessment)

                policy = self._active_policy(connection)
                identity_rows = connection.execute("SELECT * FROM validators WHERE active=1").fetchall()
                identities = {row["validator_id"]: self._row_to_identity(row) for row in identity_rows}
                revoked_validator_ids = [
                    row["object_id"]
                    for row in connection.execute(
                        "SELECT object_id FROM revocations WHERE object_type='VALIDATOR' AND effective_at<=?",
                        (int(logical_time),),
                    ).fetchall()
                ]
                assessment = evaluate_independence54(
                    claim,
                    policy,
                    supplied_attestations,
                    identities,
                    logical_time=logical_time,
                    revoked_validator_ids=revoked_validator_ids,
                )
                reasons = list(assessment.reasons)
                if claim.policy_epoch != policy.epoch:
                    reasons.append("claim policy epoch does not match the active fencing epoch")
                if not policy.issued_at <= logical_time < policy.expires_at:
                    reasons.append("active admission policy is outside its validity window")
                if logical_time < claim.logical_time:
                    reasons.append("admission time precedes the claim logical time")
                reasons.extend(self._revocation_reasons(connection, claim, policy, logical_time=logical_time))

                lease_row = connection.execute("SELECT * FROM leases WHERE lease_id=?", (claim.lease_id,)).fetchone()
                lease: DurableLease54 | None = None
                lease_uses_before = 0
                if lease_row is None:
                    reasons.append("durable lease is unknown")
                else:
                    lease = self._row_to_lease(lease_row)
                    lease_uses_before = int(lease_row["uses"])
                    if not verify_durable_lease54(lease):
                        reasons.append("durable lease hash is invalid")
                    if lease.status != "ACTIVE" or lease_row["status"] != "ACTIVE":
                        reasons.append("durable lease is not ACTIVE")
                    if lease.policy_epoch != policy.epoch:
                        reasons.append("durable lease belongs to a stale policy epoch")
                    if lease.channel_id != claim.channel_id:
                        reasons.append("claim channel is outside the durable lease")
                    if lease.subject_envelope_hash != claim.mesh54_envelope_hash:
                        reasons.append("claim is bound to another Mesh54 constitutional envelope")
                    if claim.chart_id not in set(lease.allowed_chart_ids):
                        reasons.append("claim chart is outside the durable lease scope")
                    if not set(claim.relation_ids).issubset(set(lease.allowed_relation_ids)):
                        reasons.append("claim relation set is outside the durable lease scope")
                    if claim.residual_used > lease.max_residual_budget + 1e-12:
                        reasons.append("claim residual use exceeds the durable lease budget")
                    if not lease.issued_at <= logical_time < lease.expires_at:
                        reasons.append("durable lease is outside its validity window")
                    if lease_uses_before >= lease.max_uses:
                        reasons.append("durable lease commit quota is exhausted")

                envelope_conflict = connection.execute(
                    "SELECT claim_hash FROM claims WHERE envelope_id=?", (claim.envelope_id,)
                ).fetchone()
                if envelope_conflict is not None and envelope_conflict["claim_hash"] != claim.claim_hash:
                    reasons.append("envelope id is already committed to another claim")
                nonce_conflict = connection.execute(
                    "SELECT claim_hash FROM nonces WHERE nonce=?", (claim.nonce,)
                ).fetchone()
                if nonce_conflict is not None and nonce_conflict["claim_hash"] != claim.claim_hash:
                    reasons.append("nonce is already committed to another claim")

                self._insert_attestations(connection, supplied_attestations, received_at=logical_time)
                accepted = not reasons and assessment.status == "MET" and lease is not None
                nonce_count_before = int(connection.execute("SELECT COUNT(*) AS n FROM nonces").fetchone()["n"])
                lease_uses_after = lease_uses_before + (1 if accepted else 0)
                nonce_count_after = nonce_count_before + (1 if accepted else 0)
                event_payload = {
                    "decision": "ACCEPTED" if accepted else "REJECTED",
                    "claim": claim,
                    "policy_hash": policy.policy_hash,
                    "assessment_hash": assessment.assessment_hash,
                    "attestation_ids": sorted({item.attestation_id for item in supplied_attestations}),
                    "reasons": sorted(set(reasons)),
                    "lease_uses_before": lease_uses_before,
                    "lease_uses_after": lease_uses_after,
                    "committed_nonce_count_before": nonce_count_before,
                    "committed_nonce_count_after": nonce_count_after,
                }
                sequence, event_hash = self._append_event(
                    connection,
                    "ADMISSION_COMMITTED" if accepted else "ADMISSION_REJECTED",
                    event_payload,
                    logical_time=logical_time,
                )
                if fault_stage == "after_event":
                    raise InjectedCrash("injected crash after event append")

                if accepted:
                    connection.execute(
                        "INSERT INTO claims(claim_hash,envelope_id,nonce,lease_id,claim_json,accepted_receipt_id,committed_at) "
                        "VALUES (?,?,?,?,?,?,?)",
                        (
                            claim.claim_hash,
                            claim.envelope_id,
                            claim.nonce,
                            claim.lease_id,
                            canonical_json(claim),
                            None,
                            int(logical_time),
                        ),
                    )
                    connection.execute(
                        "INSERT INTO nonces(nonce,claim_hash,envelope_id,lease_id,committed_at,receipt_id) VALUES (?,?,?,?,?,?)",
                        (claim.nonce, claim.claim_hash, claim.envelope_id, claim.lease_id, int(logical_time), None),
                    )
                    connection.execute("UPDATE leases SET uses=uses+1 WHERE lease_id=?", (claim.lease_id,))
                    if fault_stage == "after_nonce":
                        raise InjectedCrash("injected crash after nonce and lease mutation")

                state_root = self._state_root(
                    event_hash=event_hash,
                    policy_hash=policy.policy_hash,
                    decision="ACCEPTED" if accepted else "REJECTED",
                    lease_id=claim.lease_id,
                    lease_uses_after=lease_uses_after,
                    committed_nonce_count_after=nonce_count_after,
                )
                receipt = sign_commit_receipt54(
                    self.node_signer,
                    decision="ACCEPTED" if accepted else "REJECTED",
                    code="ACCEPTED" if accepted else self._rejection_code(reasons),
                    reasons=reasons,
                    claim=claim,
                    policy=policy,
                    attestation_ids=[item.attestation_id for item in supplied_attestations],
                    assessment=assessment,
                    event_sequence=sequence,
                    event_hash=event_hash,
                    state_root=state_root,
                    node_id=self.node_id,
                    committed_at=logical_time,
                )
                self._persist_receipt(connection, receipt, assessment, created_at=logical_time)
                if accepted:
                    connection.execute(
                        "UPDATE claims SET accepted_receipt_id=? WHERE claim_hash=?",
                        (receipt.receipt_id, claim.claim_hash),
                    )
                    connection.execute(
                        "UPDATE nonces SET receipt_id=? WHERE nonce=?",
                        (receipt.receipt_id, claim.nonce),
                    )
                if fault_stage == "before_commit":
                    raise InjectedCrash("injected crash immediately before commit")
                connection.commit()
                return AdmissionResult54(receipt=receipt, idempotent=False, assessment=assessment)
            except Exception:
                connection.rollback()
                raise

    @staticmethod
    def _rejection_code(reasons: Sequence[str]) -> str:
        text = " | ".join(reasons).lower()
        if "nonce" in text:
            return "REJECT_NONCE_CONFLICT"
        if "quota" in text:
            return "REJECT_LEASE_QUOTA"
        if "revoked" in text:
            return "REJECT_REVOKED"
        if "residual" in text:
            return "REJECT_RESIDUAL"
        if "epoch" in text:
            return "REJECT_STALE_EPOCH"
        if "veto" in text:
            return "REJECT_CONSTITUTIONAL_VETO"
        if "roles" in text or "independent" in text:
            return "REJECT_QUORUM"
        return "REJECT_POLICY"

    def create_checkpoint(self, *, logical_time: int) -> TransparencyCheckpointOmega54:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute("SELECT event_hash FROM events ORDER BY sequence").fetchall()
            hashes = [str(row["event_hash"]) for row in rows]
            previous = connection.execute(
                "SELECT checkpoint_json FROM checkpoints ORDER BY created_at DESC, checkpoint_id DESC LIMIT 1"
            ).fetchone()
            previous_hash = ZERO_HASH if previous is None else json.loads(previous["checkpoint_json"])["checkpoint_hash"]
            checkpoint = sign_checkpoint54(
                self.node_signer,
                node_id=self.node_id,
                log_id=self.log_id,
                tree_size=len(hashes),
                merkle_root=merkle_root(hashes),
                head_hash=hashes[-1] if hashes else ZERO_HASH,
                previous_checkpoint_hash=previous_hash,
                issued_at=logical_time,
            )
            connection.execute(
                "INSERT INTO checkpoints(checkpoint_id,tree_size,checkpoint_json,covered_head_hash,created_at) VALUES (?,?,?,?,?)",
                (
                    checkpoint.checkpoint_id,
                    checkpoint.tree_size,
                    canonical_json(checkpoint),
                    checkpoint.head_hash,
                    int(logical_time),
                ),
            )
            self._append_event(connection, "CHECKPOINT_ISSUED", checkpoint, logical_time=logical_time)
            connection.commit()
            return checkpoint

    def event_hashes(self, *, prefix_size: int | None = None) -> list[str]:
        with self._connect() as connection:
            sql = "SELECT event_hash FROM events ORDER BY sequence"
            parameters: tuple[Any, ...] = ()
            if prefix_size is not None:
                sql += " LIMIT ?"
                parameters = (int(prefix_size),)
            return [str(row["event_hash"]) for row in connection.execute(sql, parameters).fetchall()]

    def status(self) -> dict[str, Any]:
        with self._connect() as connection:
            policy_row = connection.execute("SELECT policy_hash, epoch FROM policies WHERE active=1").fetchone()
            head = connection.execute("SELECT sequence,event_hash FROM events ORDER BY sequence DESC LIMIT 1").fetchone()
            event_hashes = [str(row["event_hash"]) for row in connection.execute("SELECT event_hash FROM events ORDER BY sequence")]
            leases = [dict(row) for row in connection.execute("SELECT lease_id,uses,max_uses,status,expires_at FROM leases ORDER BY lease_id")]
            body = {
                "framework_version": "DIKWP-MESH 5.4 Ω",
                "node_id": self.node_id,
                "database": str(self.path),
                "active_policy_hash": policy_row["policy_hash"] if policy_row else "",
                "active_policy_epoch": int(policy_row["epoch"]) if policy_row else 0,
                "event_count": len(event_hashes),
                "head_hash": head["event_hash"] if head else ZERO_HASH,
                "merkle_root": merkle_root(event_hashes),
                "committed_nonce_count": int(connection.execute("SELECT COUNT(*) AS n FROM nonces").fetchone()["n"]),
                "receipt_count": int(connection.execute("SELECT COUNT(*) AS n FROM receipts").fetchone()["n"]),
                "validator_count": int(connection.execute("SELECT COUNT(*) AS n FROM validators WHERE active=1").fetchone()["n"]),
                "revocation_count": int(connection.execute("SELECT COUNT(*) AS n FROM revocations").fetchone()["n"]),
                "leases": leases,
            }
            return {**body, "status_hash": sha256_obj(body)}

    def receipt(self, receipt_id: str) -> CommitReceipt54:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM receipts WHERE receipt_id=?", (str(receipt_id),)).fetchone()
            if row is None:
                raise KeyError(receipt_id)
            return self._row_to_receipt(row)

    def verify(self, *, checked_at: int = 0) -> StoreVerificationReport54:
        failures: list[str] = []
        with self._connect() as connection:
            integrity_row = connection.execute("PRAGMA integrity_check").fetchone()
            database_integrity = str(integrity_row[0]) if integrity_row else "unknown"
            if database_integrity.lower() != "ok":
                failures.append(f"sqlite integrity_check: {database_integrity}")

            rows = connection.execute("SELECT * FROM events ORDER BY sequence").fetchall()
            previous_hash = ZERO_HASH
            expected_sequence = 1
            event_hashes: list[str] = []
            for row in rows:
                if int(row["sequence"]) != expected_sequence:
                    failures.append(f"event sequence discontinuity at {expected_sequence}")
                try:
                    payload = json.loads(row["payload_json"])
                    payload_hash = sha256_obj(payload)
                except Exception as exc:
                    failures.append(f"event payload parse failure at {row['sequence']}: {type(exc).__name__}")
                    payload_hash = ""
                if row["payload_hash"] != payload_hash:
                    failures.append(f"event payload hash mismatch at {row['sequence']}")
                if row["previous_hash"] != previous_hash:
                    failures.append(f"event previous hash mismatch at {row['sequence']}")
                expected_hash = sha256_obj(
                    {
                        "sequence": int(row["sequence"]),
                        "event_type": row["event_type"],
                        "payload_hash": row["payload_hash"],
                        "previous_hash": row["previous_hash"],
                        "logical_time": int(row["logical_time"]),
                    }
                )
                if row["event_hash"] != expected_hash:
                    failures.append(f"event hash mismatch at {row['sequence']}")
                previous_hash = str(row["event_hash"])
                event_hashes.append(previous_hash)
                expected_sequence += 1

            meta = {row["key"]: row["value"] for row in connection.execute("SELECT key,value FROM meta")}
            node_public_key = meta.get("node_public_key", "")
            if meta.get("schema_version") != _SCHEMA_VERSION or meta.get("node_id") != self.node_id:
                failures.append("store metadata invariant failed")

            policy_rows = connection.execute("SELECT * FROM policies ORDER BY epoch").fetchall()
            active_count = sum(int(row["active"]) for row in policy_rows)
            if policy_rows and active_count != 1:
                failures.append("exactly one policy must be active")
            for row in policy_rows:
                try:
                    policy = self._row_to_policy(row)
                    if not verify_admission_policy54(policy) or policy.policy_hash != row["policy_hash"] or policy.epoch != int(row["epoch"]):
                        failures.append(f"policy payload invariant failed: {row['policy_hash']}")
                except Exception as exc:
                    failures.append(f"policy parse failure {row['policy_hash']}: {type(exc).__name__}")

            identity_rows_all = connection.execute("SELECT * FROM validators ORDER BY validator_id").fetchall()
            identity_map = {}
            for row in identity_rows_all:
                try:
                    identity = self._row_to_identity(row)
                    identity_map[identity.validator_id] = identity
                    if not verify_validator_identity54(identity) or identity.identity_hash != row["identity_hash"]:
                        failures.append(f"validator identity invariant failed: {row['validator_id']}")
                except Exception as exc:
                    failures.append(f"validator parse failure {row['validator_id']}: {type(exc).__name__}")

            attestation_rows = connection.execute("SELECT * FROM attestations ORDER BY attestation_id").fetchall()
            for row in attestation_rows:
                try:
                    item = PreflightAttestation54(**json.loads(row["attestation_json"]))
                    identity = identity_map.get(item.validator_id)
                    if identity is None or not verify_preflight_attestation54(item, identity):
                        failures.append(f"attestation signature/hash invalid: {row['attestation_id']}")
                    if item.claim_hash != row["claim_hash"] or item.validator_id != row["validator_id"]:
                        failures.append(f"attestation columns disagree with payload: {row['attestation_id']}")
                except Exception as exc:
                    failures.append(f"attestation parse failure {row['attestation_id']}: {type(exc).__name__}")

            receipt_rows = connection.execute("SELECT * FROM receipts ORDER BY event_sequence,receipt_id").fetchall()
            for row in receipt_rows:
                try:
                    receipt = self._row_to_receipt(row)
                    if not verify_commit_receipt54(receipt, node_public_key):
                        failures.append(f"receipt signature/hash invalid: {receipt.receipt_id}")
                    event = connection.execute(
                        "SELECT event_hash FROM events WHERE sequence=?", (receipt.event_sequence,)
                    ).fetchone()
                    if event is None or event["event_hash"] != receipt.event_hash:
                        failures.append(f"receipt event binding invalid: {receipt.receipt_id}")
                    assessment = self._row_to_assessment(row)
                    if assessment.assessment_hash != sha256_obj(independence_assessment_body(assessment)):
                        failures.append(f"receipt assessment hash invalid: {receipt.receipt_id}")
                    event_payload_row = connection.execute(
                        "SELECT payload_json,event_type FROM events WHERE sequence=?", (receipt.event_sequence,)
                    ).fetchone()
                    if event_payload_row is not None:
                        payload = json.loads(event_payload_row["payload_json"])
                        expected_state_root = self._state_root(
                            event_hash=receipt.event_hash,
                            policy_hash=payload.get("policy_hash", ""),
                            decision=payload.get("decision", ""),
                            lease_id=payload.get("claim", {}).get("lease_id", ""),
                            lease_uses_after=int(payload.get("lease_uses_after", -1)),
                            committed_nonce_count_after=int(payload.get("committed_nonce_count_after", -1)),
                        )
                        if receipt.state_root != expected_state_root:
                            failures.append(f"receipt state root invalid: {receipt.receipt_id}")
                        expected_event_type = "ADMISSION_COMMITTED" if receipt.decision == "ACCEPTED" else "ADMISSION_REJECTED"
                        if event_payload_row["event_type"] != expected_event_type:
                            failures.append(f"receipt decision/event mismatch: {receipt.receipt_id}")
                except Exception as exc:
                    failures.append(f"receipt parse failure {row['receipt_id']}: {type(exc).__name__}")

            claim_rows = connection.execute("SELECT * FROM claims ORDER BY claim_hash").fetchall()
            for row in claim_rows:
                try:
                    claim = AdmissionClaim54(**json.loads(row["claim_json"]))
                    if not verify_admission_claim54(claim):
                        failures.append(f"claim hash invalid: {row['claim_hash']}")
                    if claim.claim_hash != row["claim_hash"] or claim.envelope_id != row["envelope_id"] or claim.nonce != row["nonce"]:
                        failures.append(f"claim columns disagree with payload: {row['claim_hash']}")
                    receipt = connection.execute(
                        "SELECT decision,claim_hash FROM receipts WHERE receipt_id=?", (row["accepted_receipt_id"],)
                    ).fetchone()
                    if receipt is None or receipt["decision"] != "ACCEPTED" or receipt["claim_hash"] != row["claim_hash"]:
                        failures.append(f"accepted claim receipt invariant failed: {row['claim_hash']}")
                except Exception as exc:
                    failures.append(f"claim parse failure {row['claim_hash']}: {type(exc).__name__}")

            nonce_rows = connection.execute("SELECT * FROM nonces ORDER BY nonce").fetchall()
            for row in nonce_rows:
                claim = connection.execute("SELECT claim_hash FROM claims WHERE claim_hash=?", (row["claim_hash"],)).fetchone()
                receipt = connection.execute("SELECT receipt_id FROM receipts WHERE receipt_id=?", (row["receipt_id"],)).fetchone()
                if claim is None or receipt is None:
                    failures.append(f"nonce referential invariant failed: {row['nonce']}")

            lease_rows = connection.execute("SELECT lease_id,uses,lease_json FROM leases ORDER BY lease_id").fetchall()
            for row in lease_rows:
                lease = DurableLease54(**json.loads(row["lease_json"]))
                if not verify_durable_lease54(lease):
                    failures.append(f"lease hash invalid: {row['lease_id']}")
                count = int(
                    connection.execute("SELECT COUNT(*) AS n FROM claims WHERE lease_id=?", (row["lease_id"],)).fetchone()["n"]
                )
                if int(row["uses"]) != count:
                    failures.append(f"lease use counter mismatch: {row['lease_id']}")

            checkpoint_rows = connection.execute("SELECT checkpoint_json FROM checkpoints ORDER BY created_at,checkpoint_id").fetchall()
            previous_checkpoint_hash = ZERO_HASH
            for row in checkpoint_rows:
                try:
                    checkpoint = TransparencyCheckpointOmega54(**json.loads(row["checkpoint_json"]))
                    if checkpoint.previous_checkpoint_hash != previous_checkpoint_hash:
                        failures.append(f"checkpoint chain mismatch: {checkpoint.checkpoint_id}")
                    if not verify_checkpoint54(checkpoint, node_public_key):
                        failures.append(f"checkpoint signature/hash invalid: {checkpoint.checkpoint_id}")
                    prefix = event_hashes[: checkpoint.tree_size]
                    if merkle_root(prefix) != checkpoint.merkle_root:
                        failures.append(f"checkpoint Merkle root mismatch: {checkpoint.checkpoint_id}")
                    expected_head = prefix[-1] if prefix else ZERO_HASH
                    if checkpoint.head_hash != expected_head:
                        failures.append(f"checkpoint head mismatch: {checkpoint.checkpoint_id}")
                    previous_checkpoint_hash = checkpoint.checkpoint_hash
                except Exception as exc:
                    failures.append(f"checkpoint parse failure: {type(exc).__name__}")

            policy_row = connection.execute("SELECT policy_hash FROM policies WHERE active=1").fetchone()
            active_policy_hash = str(policy_row["policy_hash"]) if policy_row else ""
            report_body = {
                "status": "PASS" if not failures else "FAIL",
                "database_integrity": database_integrity,
                "event_count": len(rows),
                "receipt_count": len(receipt_rows),
                "committed_nonce_count": len(nonce_rows),
                "active_policy_hash": active_policy_hash,
                "head_hash": event_hashes[-1] if event_hashes else ZERO_HASH,
                "merkle_root": merkle_root(event_hashes),
                "invariant_failures": failures,
                "checked_at": int(checked_at),
            }
            return StoreVerificationReport54(**report_body, report_hash=sha256_obj(report_body))

    def export_snapshot(self, directory: str | Path, *, checked_at: int = 0) -> dict[str, Any]:
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=True)
        database_copy = target / self.path.name
        with self._connect() as source, sqlite3.connect(str(database_copy)) as destination:
            source.backup(destination)
        with self._connect() as connection:
            events = [dict(row) for row in connection.execute("SELECT * FROM events ORDER BY sequence")]
            receipts = [json.loads(row["receipt_json"]) for row in connection.execute("SELECT receipt_json FROM receipts ORDER BY event_sequence")]
            checkpoints = [json.loads(row["checkpoint_json"]) for row in connection.execute("SELECT checkpoint_json FROM checkpoints ORDER BY created_at")]
        event_path = target / "events.jsonl"
        event_path.write_text("".join(canonical_json(item) + "\n" for item in events), encoding="utf-8")
        write_json(target / "receipts.json", receipts)
        write_json(target / "checkpoints.json", checkpoints)
        report = self.verify(checked_at=checked_at)
        write_json(target / "store_verification.json", report)
        status = self.status()
        write_json(target / "store_status.json", status)
        summary = {
            "database": database_copy.name,
            "events": len(events),
            "receipts": len(receipts),
            "checkpoints": len(checkpoints),
            "verification_status": report.status,
            "head_hash": report.head_hash,
            "merkle_root": report.merkle_root,
        }
        summary["snapshot_hash"] = sha256_obj(summary)
        write_json(target / "snapshot_summary.json", summary)
        return summary
