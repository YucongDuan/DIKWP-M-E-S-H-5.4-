from __future__ import annotations

from pathlib import Path
from typing import Sequence

from .models import (
    AdmissionClaim54,
    AdmissionPolicy54,
    AdmissionResult54,
    DurableLease54,
    PreflightAttestation54,
    TransparencyCheckpointOmega54,
    ValidatorIdentity54,
)
from .signing import Ed25519IdentityOmega54
from .store import ConstitutionalStore54


class ConstitutionalCommitKernel54:
    """High-level façade for the MESH 5.4 Omega constitutional commit node."""

    def __init__(
        self,
        database: str | Path,
        *,
        node_id: str,
        node_signer: Ed25519IdentityOmega54,
        log_id: str = "DIKWP-MESH54-OMEGA-COMMIT-LOG",
    ) -> None:
        self.store = ConstitutionalStore54(
            database,
            node_id=node_id,
            node_signer=node_signer,
            log_id=log_id,
        )

    def register_validator(self, identity: ValidatorIdentity54, *, logical_time: int = 0) -> None:
        self.store.register_validator(identity, logical_time=logical_time)

    def activate_policy(self, policy: AdmissionPolicy54, *, logical_time: int = 0) -> None:
        self.store.activate_policy(policy, logical_time=logical_time)

    def register_lease(self, lease: DurableLease54, *, logical_time: int = 0) -> None:
        self.store.register_lease(lease, logical_time=logical_time)

    def admit(
        self,
        claim: AdmissionClaim54,
        attestations: Sequence[PreflightAttestation54],
        *,
        logical_time: int,
        fault_stage: str | None = None,
    ) -> AdmissionResult54:
        return self.store.admit(
            claim,
            attestations,
            logical_time=logical_time,
            fault_stage=fault_stage,
        )

    def revoke(
        self,
        object_type: str,
        object_id: str,
        *,
        reason: str,
        policy_epoch: int,
        effective_at: int,
    ) -> str:
        return self.store.revoke(
            object_type,
            object_id,
            reason=reason,
            policy_epoch=policy_epoch,
            effective_at=effective_at,
        )

    def checkpoint(self, *, logical_time: int) -> TransparencyCheckpointOmega54:
        return self.store.create_checkpoint(logical_time=logical_time)

    def verify_store(self, *, checked_at: int = 0):
        return self.store.verify(checked_at=checked_at)

    def status(self):
        return self.store.status()
