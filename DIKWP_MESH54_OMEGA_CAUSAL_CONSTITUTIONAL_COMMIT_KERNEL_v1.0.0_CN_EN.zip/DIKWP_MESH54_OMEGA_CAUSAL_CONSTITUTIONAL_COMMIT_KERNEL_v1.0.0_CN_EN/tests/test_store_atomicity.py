from __future__ import annotations

import json
import sqlite3

import pytest

from dikwp_mesh54_omega.kernel import ConstitutionalCommitKernel54
from dikwp_mesh54_omega.models import (
    attest_claim54,
    build_admission_claim54,
    build_admission_policy54,
    build_durable_lease54,
    verify_commit_receipt54,
)
from dikwp_mesh54_omega.store import InjectedCrash


def clone_claim(original, *, envelope_id=None, envelope_hash=None, nonce=None, lease_id=None, policy_epoch=None, residual_used=None, logical_time=None):
    return build_admission_claim54(
        envelope_id=envelope_id or original.envelope_id,
        envelope_hash=envelope_hash or original.envelope_hash,
        mesh54_envelope_hash=original.mesh54_envelope_hash,
        nonce=nonce or original.nonce,
        lease_id=lease_id or original.lease_id,
        channel_id=original.channel_id,
        chart_id=original.chart_id,
        relation_ids=original.relation_ids,
        intent_covenant_hash=original.intent_covenant_hash,
        atlas_hash=original.atlas_hash,
        closure_hash=original.closure_hash,
        gossip_checkpoint_hash=original.gossip_checkpoint_hash,
        residual_used=original.residual_used if residual_used is None else residual_used,
        logical_time=original.logical_time if logical_time is None else logical_time,
        policy_epoch=original.policy_epoch if policy_epoch is None else policy_epoch,
        upstream_evidence_hashes=original.upstream_evidence_hashes,
    )


def attest_for(setup, claim, *, checked_at=103, expires_at=200, verdict="APPROVE"):
    return [
        attest_claim54(
            signer,
            identity,
            claim,
            verdict,
            evidence_hashes=[claim.envelope_hash],
            checked_at=checked_at,
            expires_at=expires_at,
        )
        for signer, identity in zip(setup["signers"], setup["identities"])
    ]


def test_accept_is_atomic_and_signed(setup_kernel):
    result = setup_kernel["kernel"].admit(
        setup_kernel["claim"], setup_kernel["attest"](), logical_time=103
    )
    assert result.receipt.decision == "ACCEPTED"
    assert not result.idempotent
    assert verify_commit_receipt54(result.receipt, setup_kernel["node_signer"].public_key_hex)
    status = setup_kernel["kernel"].status()
    assert status["committed_nonce_count"] == 1
    assert status["leases"][0]["uses"] == 1
    assert setup_kernel["kernel"].verify_store(checked_at=104).status == "PASS"


def test_exact_duplicate_is_idempotent_and_does_not_mutate_state(setup_kernel):
    first = setup_kernel["kernel"].admit(
        setup_kernel["claim"], setup_kernel["attest"](), logical_time=103
    )
    before = setup_kernel["kernel"].status()
    second = setup_kernel["kernel"].admit(
        setup_kernel["claim"], setup_kernel["attest"](), logical_time=104
    )
    after = setup_kernel["kernel"].status()
    assert second.idempotent
    assert second.receipt.receipt_id == first.receipt.receipt_id
    assert before["event_count"] == after["event_count"]
    assert before["committed_nonce_count"] == after["committed_nonce_count"] == 1
    assert before["leases"][0]["uses"] == after["leases"][0]["uses"] == 1


def test_nonce_conflict_rejected_without_extra_use(setup_kernel):
    setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    conflict = clone_claim(
        setup_kernel["claim"],
        envelope_id="GPE54-CONFLICT",
        envelope_hash="a" * 64,
        nonce=setup_kernel["claim"].nonce,
        logical_time=104,
    )
    result = setup_kernel["kernel"].admit(conflict, attest_for(setup_kernel, conflict, checked_at=104), logical_time=104)
    assert result.receipt.decision == "REJECTED"
    assert result.receipt.code == "REJECT_NONCE_CONFLICT"
    status = setup_kernel["kernel"].status()
    assert status["committed_nonce_count"] == 1
    assert status["leases"][0]["uses"] == 1


def test_envelope_conflict_rejected(setup_kernel):
    setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    conflict = clone_claim(
        setup_kernel["claim"],
        envelope_id=setup_kernel["claim"].envelope_id,
        envelope_hash="b" * 64,
        nonce="different-nonce-envelope-conflict",
        logical_time=104,
    )
    result = setup_kernel["kernel"].admit(conflict, attest_for(setup_kernel, conflict, checked_at=104), logical_time=104)
    assert result.receipt.decision == "REJECTED"
    assert any("envelope id" in reason for reason in result.receipt.reasons)
    assert setup_kernel["kernel"].status()["committed_nonce_count"] == 1


@pytest.mark.parametrize("stage", ["after_event", "after_nonce", "before_commit"])
def test_injected_crash_rolls_back_every_state_mutation(setup_kernel, stage):
    claim = clone_claim(
        setup_kernel["claim"],
        envelope_id=f"GPE54-CRASH-{stage}",
        envelope_hash=(stage[0] * 64),
        nonce=f"crash-nonce-{stage}",
        logical_time=110,
    )
    before = setup_kernel["kernel"].status()
    with pytest.raises(InjectedCrash):
        setup_kernel["kernel"].admit(
            claim,
            attest_for(setup_kernel, claim, checked_at=110),
            logical_time=110,
            fault_stage=stage,
        )
    after = setup_kernel["kernel"].status()
    assert before["event_count"] == after["event_count"]
    assert before["committed_nonce_count"] == after["committed_nonce_count"]
    assert before["leases"][0]["uses"] == after["leases"][0]["uses"]
    accepted = setup_kernel["kernel"].admit(
        claim, attest_for(setup_kernel, claim, checked_at=110), logical_time=110
    )
    assert accepted.receipt.decision == "ACCEPTED"


def test_restart_preserves_exactly_once_state(setup_kernel):
    first = setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    restarted = ConstitutionalCommitKernel54(
        setup_kernel["database"],
        node_id="omega-test-node",
        node_signer=setup_kernel["node_signer"],
    )
    second = restarted.admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=104)
    assert second.idempotent
    assert second.receipt.receipt_id == first.receipt.receipt_id
    assert restarted.status()["committed_nonce_count"] == 1


def test_residual_budget_rejection_does_not_burn_nonce(setup_kernel):
    over = clone_claim(
        setup_kernel["claim"],
        envelope_id="GPE54-RESIDUAL",
        envelope_hash="c" * 64,
        nonce="residual-nonce",
        residual_used=0.5,
        logical_time=105,
    )
    rejected = setup_kernel["kernel"].admit(over, attest_for(setup_kernel, over, checked_at=105), logical_time=105)
    assert rejected.receipt.code == "REJECT_RESIDUAL"
    assert setup_kernel["kernel"].status()["committed_nonce_count"] == 0
    valid = clone_claim(
        over,
        envelope_id="GPE54-RESIDUAL-VALID",
        envelope_hash="d" * 64,
        residual_used=0.01,
    )
    accepted = setup_kernel["kernel"].admit(valid, attest_for(setup_kernel, valid, checked_at=105), logical_time=105)
    assert accepted.receipt.decision == "ACCEPTED"


def test_lease_quota_is_durable_and_non_compensatory(setup_kernel):
    original = setup_kernel["durable_lease"]
    low = build_durable_lease54(
        upstream_lease_id="UPSTREAM-LOW",
        upstream_lease_hash="e" * 64,
        subject_envelope_hash=original.subject_envelope_hash,
        channel_id=original.channel_id,
        allowed_chart_ids=original.allowed_chart_ids,
        allowed_relation_ids=original.allowed_relation_ids,
        max_residual_budget=0.03,
        max_uses=1,
        issued_at=100,
        expires_at=600,
        policy_epoch=1,
    )
    setup_kernel["kernel"].register_lease(low, logical_time=20)
    first_claim = clone_claim(
        setup_kernel["claim"],
        envelope_id="GPE54-LOW-1",
        envelope_hash="1" * 64,
        nonce="low-nonce-1",
        lease_id=low.lease_id,
        logical_time=120,
    )
    second_claim = clone_claim(
        setup_kernel["claim"],
        envelope_id="GPE54-LOW-2",
        envelope_hash="2" * 64,
        nonce="low-nonce-2",
        lease_id=low.lease_id,
        logical_time=121,
    )
    assert setup_kernel["kernel"].admit(first_claim, attest_for(setup_kernel, first_claim, checked_at=120), logical_time=120).receipt.decision == "ACCEPTED"
    rejected = setup_kernel["kernel"].admit(second_claim, attest_for(setup_kernel, second_claim, checked_at=121), logical_time=121)
    assert rejected.receipt.code == "REJECT_LEASE_QUOTA"
    low_status = next(item for item in setup_kernel["kernel"].status()["leases"] if item["lease_id"] == low.lease_id)
    assert low_status["uses"] == 1


def test_revoked_lease_rejects_new_claim_without_nonce_use(setup_kernel):
    setup_kernel["kernel"].revoke(
        "LEASE",
        setup_kernel["durable_lease"].lease_id,
        reason="red-team emergency stop",
        policy_epoch=1,
        effective_at=100,
    )
    claim = clone_claim(
        setup_kernel["claim"],
        envelope_id="GPE54-REVOKED",
        envelope_hash="f" * 64,
        nonce="revoked-nonce",
        logical_time=103,
    )
    result = setup_kernel["kernel"].admit(claim, attest_for(setup_kernel, claim), logical_time=103)
    assert result.receipt.code == "REJECT_REVOKED"
    assert setup_kernel["kernel"].status()["committed_nonce_count"] == 0


def test_policy_epoch_fences_stale_claims(setup_kernel):
    policy2 = build_admission_policy54(epoch=2, issued_at=100, expires_at=10_000)
    setup_kernel["kernel"].activate_policy(policy2, logical_time=100)
    stale = clone_claim(
        setup_kernel["claim"],
        envelope_id="GPE54-STALE",
        envelope_hash="9" * 64,
        nonce="stale-epoch-nonce",
        logical_time=103,
        policy_epoch=1,
    )
    result = setup_kernel["kernel"].admit(stale, attest_for(setup_kernel, stale), logical_time=103)
    assert result.receipt.decision == "REJECTED"
    assert result.receipt.code in {"REJECT_STALE_EPOCH", "REJECT_QUORUM"}
    assert any("epoch" in reason for reason in result.receipt.reasons)


def test_store_verifier_detects_lease_counter_tamper(setup_kernel):
    setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    with sqlite3.connect(setup_kernel["database"]) as connection:
        connection.execute("UPDATE leases SET uses=77")
        connection.commit()
    report = setup_kernel["kernel"].verify_store(checked_at=104)
    assert report.status == "FAIL"
    assert any("lease use counter mismatch" in item for item in report.invariant_failures)


def test_store_verifier_detects_event_payload_tamper(setup_kernel):
    setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    with sqlite3.connect(setup_kernel["database"]) as connection:
        row = connection.execute("SELECT sequence,payload_json FROM events ORDER BY sequence LIMIT 1").fetchone()
        payload = json.loads(row[1])
        payload["tampered"] = True
        connection.execute("UPDATE events SET payload_json=? WHERE sequence=?", (json.dumps(payload), row[0]))
        connection.commit()
    report = setup_kernel["kernel"].verify_store(checked_at=104)
    assert report.status == "FAIL"
    assert any("event payload hash mismatch" in item for item in report.invariant_failures)
