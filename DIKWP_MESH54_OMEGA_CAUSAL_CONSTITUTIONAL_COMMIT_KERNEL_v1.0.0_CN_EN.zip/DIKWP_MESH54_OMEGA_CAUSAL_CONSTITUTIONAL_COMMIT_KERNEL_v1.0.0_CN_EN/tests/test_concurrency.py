from __future__ import annotations

import multiprocessing as mp
from dataclasses import asdict

from dikwp_mesh54_omega.kernel import ConstitutionalCommitKernel54
from dikwp_mesh54_omega.models import AdmissionClaim54, PreflightAttestation54, attest_claim54, build_admission_claim54
from dikwp_mesh54_omega.signing import Ed25519IdentityOmega54


def _worker(database: str, claim_raw: dict, attestations_raw: list[dict], queue) -> None:
    node_signer = Ed25519IdentityOmega54.from_seed("OMEGA-TEST-NODE", "omega-test-node-seed")
    kernel = ConstitutionalCommitKernel54(database, node_id="omega-test-node", node_signer=node_signer)
    claim = AdmissionClaim54(**claim_raw)
    attestations = [PreflightAttestation54(**item) for item in attestations_raw]
    result = kernel.admit(claim, attestations, logical_time=130)
    queue.put((result.receipt.decision, result.receipt.code, result.idempotent))


def _conflict_claim(original, *, envelope_id: str, envelope_hash: str):
    return build_admission_claim54(
        envelope_id=envelope_id,
        envelope_hash=envelope_hash,
        mesh54_envelope_hash=original.mesh54_envelope_hash,
        nonce="shared-cross-process-nonce",
        lease_id=original.lease_id,
        channel_id=original.channel_id,
        chart_id=original.chart_id,
        relation_ids=original.relation_ids,
        intent_covenant_hash=original.intent_covenant_hash,
        atlas_hash=original.atlas_hash,
        closure_hash=original.closure_hash,
        gossip_checkpoint_hash=original.gossip_checkpoint_hash,
        residual_used=0.0,
        logical_time=130,
        policy_epoch=1,
        upstream_evidence_hashes=original.upstream_evidence_hashes,
    )


def _attest(setup, claim):
    return [
        attest_claim54(
            signer,
            identity,
            claim,
            "APPROVE",
            checked_at=130,
            expires_at=180,
        )
        for signer, identity in zip(setup["signers"], setup["identities"])
    ]


def test_two_processes_cannot_commit_the_same_nonce_to_different_claims(setup_kernel):
    left = _conflict_claim(setup_kernel["claim"], envelope_id="GPE54-PROC-L", envelope_hash="a" * 64)
    right = _conflict_claim(setup_kernel["claim"], envelope_id="GPE54-PROC-R", envelope_hash="b" * 64)
    context = mp.get_context("spawn")
    queue = context.Queue()
    processes = [
        context.Process(
            target=_worker,
            args=(str(setup_kernel["database"]), asdict(claim), [asdict(item) for item in _attest(setup_kernel, claim)], queue),
        )
        for claim in (left, right)
    ]
    for process in processes:
        process.start()
    for process in processes:
        process.join(30)
        assert process.exitcode == 0
    results = [queue.get(timeout=5) for _ in processes]
    assert sum(decision == "ACCEPTED" for decision, _, _ in results) == 1
    assert sum(code == "REJECT_NONCE_CONFLICT" for _, code, _ in results) == 1
    status = setup_kernel["kernel"].status()
    assert status["committed_nonce_count"] == 1
    assert status["leases"][0]["uses"] == 1
    assert setup_kernel["kernel"].verify_store(checked_at=131).status == "PASS"
