from __future__ import annotations

import copy

from dikwp_mesh54_omega.mesh54_adapter import (
    attest_structural_preflight54,
    claim_from_governed_packet54,
    durable_lease_from_mesh54,
    structural_preflight54,
)


SECRET = b"mesh54-reference-packet-integrity-key"


def test_reference_mesh54_packet_passes_structural_preflight(upstream_examples):
    result = structural_preflight54(
        upstream_examples["packet"],
        upstream_examples["lease"],
        integrity_secret=SECRET,
        logical_time=103,
        residual_used=0.0,
    )
    assert result["accepted"], result["reasons"]
    assert len(result["evidence_hashes"]) == 4


def test_wrong_secret_fails_all_nested_integrity_layers(upstream_examples):
    result = structural_preflight54(
        upstream_examples["packet"],
        upstream_examples["lease"],
        integrity_secret=b"wrong-reference-secret-value",
        logical_time=103,
    )
    assert not result["accepted"]
    assert sum("HMAC" in reason for reason in result["reasons"]) == 3


def test_tampered_outer_scope_is_detected(upstream_examples):
    tampered = copy.deepcopy(upstream_examples["packet"])
    tampered["relation_ids"] = ["REL-RESIDUAL-HONESTY"]
    result = structural_preflight54(
        tampered,
        upstream_examples["lease"],
        integrity_secret=SECRET,
        logical_time=103,
    )
    assert not result["accepted"]
    assert any("body hash" in reason or "HMAC" in reason for reason in result["reasons"])
    assert any("relations" in reason for reason in result["reasons"])


def test_claim_and_durable_lease_preserve_mesh54_scope(upstream_examples):
    lease = durable_lease_from_mesh54(
        upstream_examples["lease"],
        upstream_examples["packet"],
        policy_epoch=7,
        max_residual_budget=0.03,
    )
    claim = claim_from_governed_packet54(
        upstream_examples["packet"],
        durable_lease_id=lease.lease_id,
        policy_epoch=7,
        logical_time=103,
    )
    assert claim.mesh54_envelope_hash == lease.subject_envelope_hash
    assert claim.channel_id == lease.channel_id
    assert claim.chart_id in lease.allowed_chart_ids
    assert set(claim.relation_ids).issubset(set(lease.allowed_relation_ids))


def test_tampered_packet_rejection_does_not_burn_valid_nonce(setup_kernel):
    tampered = copy.deepcopy(setup_kernel["packet"])
    tampered["relation_ids"] = ["REL-RESIDUAL-HONESTY"]
    tampered_claim = claim_from_governed_packet54(
        tampered,
        durable_lease_id=setup_kernel["durable_lease"].lease_id,
        policy_epoch=1,
        logical_time=103,
    )
    deny_attestations = [
        attest_structural_preflight54(
            signer,
            identity,
            tampered_claim,
            tampered,
            setup_kernel["upstream_lease"],
            integrity_secret=SECRET,
            checked_at=103,
            expires_at=120,
        )
        for signer, identity in zip(setup_kernel["signers"], setup_kernel["identities"])
    ]
    rejected = setup_kernel["kernel"].admit(tampered_claim, deny_attestations, logical_time=103)
    assert rejected.receipt.decision == "REJECTED"
    assert setup_kernel["kernel"].status()["committed_nonce_count"] == 0

    valid_attestations = [
        attest_structural_preflight54(
            signer,
            identity,
            setup_kernel["claim"],
            setup_kernel["packet"],
            setup_kernel["upstream_lease"],
            integrity_secret=SECRET,
            checked_at=104,
            expires_at=120,
        )
        for signer, identity in zip(setup_kernel["signers"], setup_kernel["identities"])
    ]
    accepted = setup_kernel["kernel"].admit(setup_kernel["claim"], valid_attestations, logical_time=104)
    assert accepted.receipt.decision == "ACCEPTED"
    assert setup_kernel["kernel"].status()["committed_nonce_count"] == 1
