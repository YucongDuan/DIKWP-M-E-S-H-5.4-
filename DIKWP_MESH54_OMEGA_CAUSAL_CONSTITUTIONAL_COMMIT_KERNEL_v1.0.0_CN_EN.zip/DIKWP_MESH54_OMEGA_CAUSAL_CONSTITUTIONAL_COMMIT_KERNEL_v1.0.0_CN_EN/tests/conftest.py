from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

import pytest

from dikwp_mesh54_omega.kernel import ConstitutionalCommitKernel54
from dikwp_mesh54_omega.mesh54_adapter import claim_from_governed_packet54, durable_lease_from_mesh54
from dikwp_mesh54_omega.models import (
    attest_claim54,
    build_admission_policy54,
    build_validator_identity54,
)
from dikwp_mesh54_omega.signing import Ed25519IdentityOmega54


@pytest.fixture
def upstream_examples():
    root = Path(__file__).resolve().parents[1] / "examples" / "upstream_mesh54"
    return {
        "packet": json.loads((root / "governed_packet54.json").read_text(encoding="utf-8")),
        "lease": json.loads((root / "capability_lease54.json").read_text(encoding="utf-8")),
    }


@pytest.fixture
def setup_kernel(tmp_path, upstream_examples):
    node_signer = Ed25519IdentityOmega54.from_seed("OMEGA-TEST-NODE", "omega-test-node-seed")
    database = tmp_path / "omega.sqlite"
    kernel = ConstitutionalCommitKernel54(
        database,
        node_id="omega-test-node",
        node_signer=node_signer,
    )
    policy = build_admission_policy54(epoch=1, issued_at=0, expires_at=10_000)
    kernel.activate_policy(policy, logical_time=0)
    roles = ["replicator", "red-team", "governance", "affected-party"]
    signers = []
    identities = []
    for index, role in enumerate(roles):
        signer = Ed25519IdentityOmega54.from_seed(f"V54O-{index}", f"validator-seed-{index}")
        identity = build_validator_identity54(
            signer,
            role=role,
            organization_id=f"ORG-{index}",
            funding_domain=f"FUND-{index}",
            software_lineage=f"SW-{index}",
            data_lineage=f"DATA-{index}",
            jurisdiction=f"JUR-{index}",
        )
        kernel.register_validator(identity, logical_time=index + 1)
        signers.append(signer)
        identities.append(identity)
    lease = durable_lease_from_mesh54(
        upstream_examples["lease"],
        upstream_examples["packet"],
        policy_epoch=1,
        max_residual_budget=0.03,
    )
    kernel.register_lease(lease, logical_time=10)
    claim = claim_from_governed_packet54(
        upstream_examples["packet"],
        durable_lease_id=lease.lease_id,
        policy_epoch=1,
        logical_time=103,
        residual_used=0.0,
    )

    def attest(target_claim=claim, verdict="APPROVE", checked_at=103, expires_at=150):
        return [
            attest_claim54(
                signer,
                identity,
                target_claim,
                verdict,
                evidence_hashes=[target_claim.envelope_hash],
                checked_at=checked_at,
                expires_at=expires_at,
            )
            for signer, identity in zip(signers, identities)
        ]

    return {
        "kernel": kernel,
        "database": database,
        "node_signer": node_signer,
        "policy": policy,
        "signers": signers,
        "identities": identities,
        "durable_lease": lease,
        "upstream_lease": upstream_examples["lease"],
        "packet": upstream_examples["packet"],
        "claim": claim,
        "attest": attest,
    }

@pytest.fixture
def project_root() -> Path:
    return Path(__file__).resolve().parents[1]
