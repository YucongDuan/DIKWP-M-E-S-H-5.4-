from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from dikwp_mesh54_omega.cli import main
from dikwp_mesh54_omega.conformance import run_conformance
from dikwp_mesh54_omega.kernel import ConstitutionalCommitKernel54
from dikwp_mesh54_omega.service import make_handler
from dikwp_mesh54_omega.signing import Ed25519IdentityOmega54


def test_conformance_lifecycle_passes(tmp_path):
    report = run_conformance(output_dir=tmp_path / "run")
    assert report["status"] == "PASS"
    assert report["checks_total"] == 28
    assert report["checks_passed"] == 28


def test_cli_version(capsys):
    try:
        main(["--version"])
    except SystemExit as exc:
        assert exc.code == 0
    assert "1.0.0" in capsys.readouterr().out


def test_cli_artifact_validation(tmp_path, project_root, capsys):
    report_path = tmp_path / "artifacts.json"
    code = main(["artifacts-validate", "--root", str(project_root), "--output", str(report_path)])
    assert code == 0
    assert json.loads(report_path.read_text(encoding="utf-8"))["status"] == "PASS"
    assert '"schemas_checked": 10' in capsys.readouterr().out


def test_cli_conformance_report(tmp_path, capsys):
    report_path = tmp_path / "conformance.json"
    code = main(["conformance", "--out", str(tmp_path / "run"), "--report", str(report_path)])
    assert code == 0
    assert json.loads(report_path.read_text(encoding="utf-8"))["checks_passed"] == 28
    assert '"status": "PASS"' in capsys.readouterr().out


def test_http_health_and_authorization(tmp_path):
    signer = Ed25519IdentityOmega54.from_seed("NODE", "service-test-node")
    kernel = ConstitutionalCommitKernel54(tmp_path / "node.sqlite", node_id="NODE", node_signer=signer)
    token = "a-very-long-local-reference-token"
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(kernel, token))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_port}"
    try:
        with urllib.request.urlopen(base + "/health", timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
            assert response.status == 200
            assert payload["framework"] == "DIKWP-MESH 5.4 Ω"
        try:
            urllib.request.urlopen(base + "/v1/status", timeout=5)
        except urllib.error.HTTPError as exc:
            assert exc.code == 401
        request = urllib.request.Request(base + "/v1/status", headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(request, timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
            assert payload["node_id"] == "NODE"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
