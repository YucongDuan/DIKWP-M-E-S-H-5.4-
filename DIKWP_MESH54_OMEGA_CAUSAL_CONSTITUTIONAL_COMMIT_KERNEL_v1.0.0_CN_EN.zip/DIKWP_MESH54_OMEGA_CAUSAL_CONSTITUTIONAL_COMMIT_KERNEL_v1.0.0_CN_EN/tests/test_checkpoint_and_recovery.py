from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from dikwp_mesh54_omega.checkpoint import compare_checkpoints54
from dikwp_mesh54_omega.kernel import ConstitutionalCommitKernel54
from dikwp_mesh54_omega.models import verify_checkpoint54


def test_checkpoint_is_signed_and_store_remains_valid(setup_kernel):
    setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    checkpoint = setup_kernel["kernel"].checkpoint(logical_time=104)
    assert verify_checkpoint54(checkpoint, setup_kernel["node_signer"].public_key_hex)
    assert checkpoint.tree_size >= 1
    assert setup_kernel["kernel"].verify_store(checked_at=105).status == "PASS"


def test_later_checkpoint_proves_prefix_consistency(setup_kernel):
    first = setup_kernel["kernel"].checkpoint(logical_time=100)
    first_hashes = setup_kernel["kernel"].store.event_hashes(prefix_size=first.tree_size)
    setup_kernel["kernel"].revoke(
        "ENVELOPE",
        "future-envelope",
        reason="fixture event",
        policy_epoch=1,
        effective_at=101,
    )
    second = setup_kernel["kernel"].checkpoint(logical_time=102)
    second_hashes = setup_kernel["kernel"].store.event_hashes(prefix_size=second.tree_size)
    comparison = compare_checkpoints54(
        first,
        second,
        left_public_key=setup_kernel["node_signer"].public_key_hex,
        right_public_key=setup_kernel["node_signer"].public_key_hex,
        left_event_hashes=first_hashes,
        right_event_hashes=second_hashes,
    )
    assert comparison.relation == "PREFIX"
    assert not comparison.split_view_detected
    assert comparison.common_prefix_size == first.tree_size


def test_equal_size_divergent_forks_are_split_view(setup_kernel, tmp_path):
    setup_kernel["kernel"].checkpoint(logical_time=50)
    snapshot = setup_kernel["kernel"].store.export_snapshot(tmp_path / "snapshot", checked_at=51)
    source_db = tmp_path / "snapshot" / setup_kernel["database"].name
    left_db = tmp_path / "left.sqlite"
    right_db = tmp_path / "right.sqlite"
    with sqlite3.connect(source_db) as source, sqlite3.connect(left_db) as left:
        source.backup(left)
    with sqlite3.connect(source_db) as source, sqlite3.connect(right_db) as right:
        source.backup(right)

    left = ConstitutionalCommitKernel54(
        left_db,
        node_id="omega-test-node",
        node_signer=setup_kernel["node_signer"],
    )
    right = ConstitutionalCommitKernel54(
        right_db,
        node_id="omega-test-node",
        node_signer=setup_kernel["node_signer"],
    )
    left.revoke("ENVELOPE", "left-branch", reason="left", policy_epoch=1, effective_at=60)
    right.revoke("ENVELOPE", "right-branch", reason="right", policy_epoch=1, effective_at=60)
    left_cp = left.checkpoint(logical_time=61)
    right_cp = right.checkpoint(logical_time=61)
    assert left_cp.tree_size == right_cp.tree_size
    comparison = compare_checkpoints54(
        left_cp,
        right_cp,
        left_public_key=setup_kernel["node_signer"].public_key_hex,
        right_public_key=setup_kernel["node_signer"].public_key_hex,
        left_event_hashes=left.store.event_hashes(prefix_size=left_cp.tree_size),
        right_event_hashes=right.store.event_hashes(prefix_size=right_cp.tree_size),
    )
    assert comparison.split_view_detected
    assert comparison.relation == "EQUAL_SIZE_CONFLICT"


def test_export_snapshot_contains_forensic_artifacts(setup_kernel, tmp_path):
    setup_kernel["kernel"].admit(setup_kernel["claim"], setup_kernel["attest"](), logical_time=103)
    setup_kernel["kernel"].checkpoint(logical_time=104)
    summary = setup_kernel["kernel"].store.export_snapshot(tmp_path / "forensic", checked_at=105)
    assert summary["verification_status"] == "PASS"
    for name in [
        setup_kernel["database"].name,
        "events.jsonl",
        "receipts.json",
        "checkpoints.json",
        "store_verification.json",
        "store_status.json",
        "snapshot_summary.json",
    ]:
        assert (tmp_path / "forensic" / name).is_file()
    events = (tmp_path / "forensic" / "events.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(events) == summary["events"]
    assert all(json.loads(line)["event_hash"] for line in events)


def test_checkpoint_tamper_is_detected(setup_kernel):
    from dataclasses import replace

    checkpoint = setup_kernel["kernel"].checkpoint(logical_time=100)
    tampered = replace(checkpoint, merkle_root="0" * 64)
    assert not verify_checkpoint54(tampered, setup_kernel["node_signer"].public_key_hex)
