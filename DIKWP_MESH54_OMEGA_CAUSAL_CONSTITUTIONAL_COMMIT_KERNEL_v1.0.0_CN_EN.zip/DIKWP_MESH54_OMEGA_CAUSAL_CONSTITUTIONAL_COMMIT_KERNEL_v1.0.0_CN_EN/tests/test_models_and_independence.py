from __future__ import annotations

from dataclasses import replace

from dikwp_mesh54_omega.independence import evaluate_independence54
from dikwp_mesh54_omega.models import (
    attest_claim54,
    build_admission_policy54,
    build_validator_identity54,
    verify_admission_claim54,
    verify_admission_policy54,
    verify_preflight_attestation54,
    verify_validator_identity54,
)
from dikwp_mesh54_omega.signing import Ed25519IdentityOmega54


def test_reference_policy_is_valid(setup_kernel):
    assert verify_admission_policy54(setup_kernel["policy"])


def test_claim_is_content_addressed(setup_kernel):
    claim = setup_kernel["claim"]
    assert verify_admission_claim54(claim)
    assert not verify_admission_claim54(replace(claim, chart_id="tampered"))


def test_validator_identity_is_content_addressed():
    signer = Ed25519IdentityOmega54.from_seed("V", "seed")
    identity = build_validator_identity54(
        signer,
        role="replicator",
        organization_id="O",
        funding_domain="F",
        software_lineage="S",
        data_lineage="D",
        jurisdiction="J",
    )
    assert verify_validator_identity54(identity)
    assert not verify_validator_identity54(replace(identity, organization_id="OTHER"))


def test_attestation_signature_detects_tamper(setup_kernel):
    item = setup_kernel["attest"]()[0]
    identity = setup_kernel["identities"][0]
    assert verify_preflight_attestation54(item, identity)
    assert not verify_preflight_attestation54(replace(item, verdict="DENY"), identity)


def test_independence_requires_roles_and_components(setup_kernel):
    assessment = evaluate_independence54(
        setup_kernel["claim"],
        setup_kernel["policy"],
        setup_kernel["attest"](),
        {item.validator_id: item for item in setup_kernel["identities"]},
        logical_time=103,
    )
    assert assessment.status == "MET"
    assert assessment.effective_independent_count == 4
    assert set(assessment.roles_present) == {"replicator", "red-team", "governance", "affected-party"}


def test_correlated_validators_collapse_into_one_component(setup_kernel):
    signers = setup_kernel["signers"]
    identities = []
    for index, (signer, original) in enumerate(zip(signers, setup_kernel["identities"])):
        identities.append(
            build_validator_identity54(
                signer,
                role=original.role,
                organization_id="ONE-ORG",
                funding_domain="ONE-FUND",
                software_lineage=f"SW-{index}",
                data_lineage=f"DATA-{index}",
                jurisdiction=f"J-{index}",
            )
        )
    attestations = [
        attest_claim54(
            signer,
            identity,
            setup_kernel["claim"],
            "APPROVE",
            checked_at=103,
            expires_at=150,
        )
        for signer, identity in zip(signers, identities)
    ]
    assessment = evaluate_independence54(
        setup_kernel["claim"],
        setup_kernel["policy"],
        attestations,
        {item.validator_id: item for item in identities},
        logical_time=103,
    )
    assert assessment.status == "NOT_MET"
    assert assessment.effective_independent_count == 1
    assert assessment.conflict_edges


def test_valid_deny_attestation_is_veto(setup_kernel):
    attestations = setup_kernel["attest"]()
    signer = setup_kernel["signers"][1]
    identity = setup_kernel["identities"][1]
    attestations.append(
        attest_claim54(
            signer,
            identity,
            setup_kernel["claim"],
            "DENY",
            reasons=["red-team veto"],
            checked_at=103,
            expires_at=150,
        )
    )
    assessment = evaluate_independence54(
        setup_kernel["claim"],
        setup_kernel["policy"],
        attestations,
        {item.validator_id: item for item in setup_kernel["identities"]},
        logical_time=103,
    )
    assert assessment.status == "NOT_MET"
    assert assessment.denying_validator_ids == [identity.validator_id]
    assert any("veto" in reason for reason in assessment.reasons)


def test_expired_attestations_do_not_count(setup_kernel):
    expired = setup_kernel["attest"](checked_at=1, expires_at=2)
    assessment = evaluate_independence54(
        setup_kernel["claim"],
        setup_kernel["policy"],
        expired,
        {item.validator_id: item for item in setup_kernel["identities"]},
        logical_time=103,
    )
    assert assessment.status == "NOT_MET"
    assert assessment.effective_independent_count == 0


def test_policy_hash_changes_with_epoch():
    one = build_admission_policy54(epoch=1)
    two = build_admission_policy54(epoch=2)
    assert one.policy_hash != two.policy_hash
