# Security Policy / 安全策略

## Supported line

`dikwp-mesh54-omega 1.0.x` is the active reference line.

## Reportable issues

请报告 nonce 重复接受、lease quota 双花、事务部分提交、精确重试产生不同回执、policy epoch 回退、revocation 绕过、validator 签名或 independence 绕过、receipt/event/checkpoint 哈希绕过、forensic verifier 漏检、API 未授权写入和 release manifest 绕过。

## Secret warning

测试与 demo 中的 seeds、HMAC secret 和 bearer token 都是公开确定性夹具，严禁用作部署密钥。生产节点应使用 HSM/KMS、mTLS/OIDC、独立 validator key custody 和外部 checkpoint anchoring。

## Disclosure

不要在公开报告中包含真实私钥、模型私有激活、个人数据或受限数据集。提交最小合成复现、受影响 object hashes、策略 epoch、SQLite/平台版本和预期/实际原子性结果。
