# DIKWP-MESH 5.4 Ω

## 因果宪约原子提交内核 / Causal Constitutional Atomic Commit Kernel

> **Evidence grade / 证据等级：E2 — author-side deterministic reference**  
> 这是一个可运行、可崩溃恢复、可跨进程竞争、可审计的 MESH 5.4 参考节点；它不是多节点共识、生产安全认证或独立机构复现。

DIKWP-MESH 5.4 已经定义了局部因果图册、Intent Field Covenant、UAX 残差、Ed25519 见证独立性、gossip checkpoint、能力租约与两阶段 nonce 验证。附件自身的威胁模型同时明确留下两个运行断层：nonce reservation 只在单进程锁内有效，跨进程部署需要持久化数据库与共识机制。

**Ω 内核补上其中可由单节点严格解决的部分：持久化、跨进程串行化、崩溃一致性与证据原子提交。** 它不修改 5.4 的科学语义，而把已经通过 5.4 验证的主张转换为可恢复、不可重复消费、带独立见证和签名回执的宪约事务。

## 核心不变量 / Atomic invariant

对于每个被接受的 MESH 5.4 admission：

```text
COMMIT(
    durable nonce
  + lease use
  + signed admission receipt
  + hash-chained evidence event
) OR COMMIT NOTHING
```

换言之，系统不允许出现以下中间态：nonce 已消耗但回执不存在、租约已扣减但证据链未追加、回执已返回但数据库事务尚未持久化。进程崩溃、线程中断和竞争请求只能得到完整提交或完整回滚。

## 为什么这是 5.4 的关键系统

5.4 的两阶段预览、保留和提交能够阻止篡改外层包烧毁合法 nonce，但原参考运行时把 nonce、lease uses 与状态表保存在 Python 进程内存中。这意味着重启后重放防御失忆，多个进程可能各自接受同一 nonce，能力租约配额也可能产生双花。

Ω 将 5.4 的操作边界提升为持久宪约节点：

| 5.4 原生对象 | Ω 的运行期强化 |
|---|---|
| GovernedPacketEnvelope54 | 结构预检后生成内容寻址 AdmissionClaim54 |
| CapabilityLease54 | 持久化 chart/relation/time/residual/quota scope |
| WitnessIdentity54 | 独立 Ed25519 validator identity 与披露关系 |
| Witness Independence Graph | 同组织、资金、软件、数据或辖区折叠为同一组件 |
| two-phase nonce | SQLite `BEGIN IMMEDIATE` 下的持久 nonce 唯一性 |
| gossip checkpoint | 签名 checkpoint、前序 checkpoint 链与 split-view 比较 |
| open obligations | 每份回执和发行报告保留证据等级与未完成义务 |

## 主要能力

### 原子 admission

一次事务同时验证活跃策略纪元、租约范围、残差预算、撤销状态、validator 签名、角色覆盖、独立组件数量和否决规则，然后原子写入 claim、attestations、nonce、lease use、receipt 与 event。

### 持久幂等与冲突拒绝

同一 claim 的精确重试返回原签名回执，不增加事件、不重复扣减配额。相同 nonce 配不同 claim 时返回 `REJECT_NONCE_CONFLICT`。该行为跨进程重启保持成立。

### 宪约见证门

默认策略要求四类角色：replicator、red-team、governance、affected-party。角色 ID 不等于独立性；若 validator 共享组织、资金、软件、数据或司法辖区，它们会被连接到同一冲突分量，只计一个独立组件。合法 `DENY` 可构成宪约否决。

### 纪元围栏、撤销和租约

策略 epoch 是 fencing token。较旧策略不能重新激活；validator、lease、channel、envelope 和 policy 均可被持久撤销。租约绑定 channel、envelope、chart、relations、时间、残差预算和最大使用次数。

### 证据日志与恢复

所有状态变更在同一事务中追加完整 canonical payload、payload hash、previous hash 和 event hash。节点可生成 Merkle root、签名 checkpoint 和 forensic snapshot；验证器会检查 SQLite 完整性、事件链、签名、claims、nonces、lease counters、receipts 和 checkpoint 链。

### 本地最小 API

可选 HTTP 服务只提供健康检查、状态、验证、回执读取、admission 与 checkpoint。除 `/health` 外要求 bearer token，并设置 no-store、CSP、nosniff 和 frame-deny 等响应头。它是本地参考接口，不替代 TLS 终止、密钥托管或生产级身份认证。

## 快速开始

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl

mesh54-omega --version
mesh54-omega conformance --out outputs/conformance --report outputs/conformance.json
mesh54-omega artifacts-validate --root . --output outputs/artifacts.json
mesh54-omega demo --out outputs/demo-new
```

源码态运行：

```bash
PYTHONPATH=src python -m dikwp_mesh54_omega.cli demo --out outputs/demo-new
PYTHONPATH=src python -m pytest -q
```

启动本地 API：

```bash
export MESH54_OMEGA_NODE_SEED='replace-with-protected-node-seed'
export MESH54_OMEGA_API_TOKEN='replace-with-at-least-24-random-characters'

mesh54-omega serve \
  --database state/omega.sqlite \
  --node-id OMEGA-NODE-01 \
  --host 127.0.0.1 \
  --port 8754
```

## 已验证结果

本发行版在 Python 3.13.5 参考环境完成：

- **39 / 39** 自建单元、集成、崩溃、并发、签名、API 与 CLI 测试；
- **28 / 28** 自包含 conformance checks；
- **10 / 10** JSON Schema 与示例配对验证；
- 三个事务崩溃注入点均完整回滚；
- 两个独立进程争抢同一 nonce，恰好一个接受、一个冲突；
- 精确重试在进程重开后返回同一签名回执；
- 篡改外层包被拒绝且不消耗合法 nonce；
- 数据库计数篡改与透明度 split view 均被检测；
- 参考 store verification 为 `PASS`。

参考生命周期的最终状态：3 个已提交 nonce、3 次租约使用、12 条证据事件。具体哈希以 `outputs/demo/summary54omega.json`、`RUN_PROOF54omega.json` 与最终 `VALIDATION_REPORT.json` 为准。

## 目录

```text
src/dikwp_mesh54_omega/  原子内核、存储、协议对象、适配器、API、CLI
schemas/                 10 个核心对象的 JSON Schema
examples/                Ω 示例及原始 MESH 5.4 输入对象
tests/                   崩溃、并发、篡改、策略、签名与接口测试
outputs/demo/            完整参考生命周期与 forensic snapshot
dashboard/index.html     单文件离线证据驾驶舱
docs/                    架构、威胁模型、集成、运维与证据边界
dist/                    wheel 与 source distribution
vendor/                  原 MESH 5.4 wheel（供应链输入，不自动信任）
```

## 证据边界

Ω 证明的是：在一个 SQLite 数据库协调域内，MESH 5.4 admission 的 nonce、租约配额、签名回执与证据事件可以被原子持久化，并在崩溃和跨进程竞争后保持可验证一致。

Ω 不证明：

- 跨多数据库或多地域节点的一致性；
- Byzantine fault tolerant consensus；
- validator 披露关系必然真实；
- 结构预检等同完整因果矩阵、rollback vector、atlas 和现实受影响者验证；
- 参考密钥、bearer token 或本地 HTTP 服务适合生产；
- 模拟角色等于独立机构复现；
- 5.4 或 Ω 已经完成全局语义闭合。

生产化下一门槛是把同一状态机复制到经过证明的共识日志，并引入硬件或托管密钥、mTLS/OIDC、外部 validator 注册与独立安全审计。

## License

Apache License 2.0。见 `LICENSE`。
