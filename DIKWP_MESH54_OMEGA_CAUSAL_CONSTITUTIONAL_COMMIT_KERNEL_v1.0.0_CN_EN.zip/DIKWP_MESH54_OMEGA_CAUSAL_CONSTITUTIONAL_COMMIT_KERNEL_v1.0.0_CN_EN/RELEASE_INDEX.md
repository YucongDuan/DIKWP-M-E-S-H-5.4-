# Release Index / 发行索引

## Start here

- `README.md` — system rationale, invariant, quickstart and evidence boundary
- `dashboard/index.html` — offline evidence cockpit
- `VALIDATION_REPORT.json` — machine-readable executed validation
- `docs/BASELINE_AUDIT_CN_EN.md` — audit of the attached MESH 5.4 delivery
- `docs/ARCHITECTURE_CN_EN.md` — architecture and transaction semantics
- `docs/THREAT_MODEL_CN_EN.md` — controls and residual risks
- `docs/MESH54_INTEGRATION_GUIDE_CN_EN.md` — upstream integration path
- `docs/OPERATIONS_RUNBOOK_CN_EN.md` — deployment experiment and recovery procedure
- `docs/SCIENTIFIC_BOUNDARY_CN_EN.md` — claims, non-claims and evidence grade

## Installable artifacts

- `dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl`
- `dist/dikwp_mesh54_omega-1.0.0.tar.gz`

## Supply-chain evidence

- `DIKWP_MESH54_OMEGA_SBOM.spdx.json`
- `DIKWP_MESH54_OMEGA_ATTESTATION.json`
- `MANIFEST.json`
- `SHA256SUMS.txt`

## Executed evidence

- `outputs/tests54omega.xml`
- `outputs/conformance_report54omega.json`
- `outputs/artifact_validation54omega.json`
- `outputs/cleanwheel_verification54omega.json`
- `outputs/demo/RUN_PROOF54omega.json`
- `outputs/demo/forensic_snapshot/`
