# Five-minute quickstart

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl
mesh54-omega conformance --out outputs/conformance --report outputs/conformance.json
mesh54-omega demo --out outputs/demo-new
```

Expected result: 28/28 conformance checks pass; the demo reports store verification PASS, one accepted and one conflicting cross-process contender, successful crash rollback, and restart-stable idempotency.

Open `dashboard/index.html` for the offline evidence cockpit. Read the threat model and operations runbook before any deployment experiment.
