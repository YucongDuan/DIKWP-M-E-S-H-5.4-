# 科学与证据边界 / Scientific and Evidence Boundary

## 当前可支持的主张

在确定性合成输入和单 SQLite 协调域内，Ω 参考实现展示并测试了：

- MESH 5.4 governed packet 的结构篡改可在 nonce 消耗前被拒绝；
- 同一 nonce 的跨进程竞争只有一个 claim 能提交；
- nonce、lease use、signed receipt 和 evidence event 能在同一事务中原子提交；
- 进程崩溃后的精确重试保持幂等；
- 同源 validator 可通过关系图被折扣；
- 持久状态和分叉日志的若干篡改可被验证器检测。

## 当前不能支持的主张

- 任意真实模型之间存在稳定因果等价；
- structural preflight 已验证全部 causal atlas 或 rollback 行为；
- 模拟 affected-party 代表现实受影响人群同意；
- Ed25519 签名等于组织独立性或证据真实性；
- SQLite 单节点等于分布式 consensus；
- 39 项测试或 28 项 conformance 等于生产认证；
- 哈希链在没有外部锚点时可以抵御整个数据库历史被替换；
- Ω 是意识、主体性、生命或全局语义闭合的证明。

## 证据等级

当前维持 **E2 author-side deterministic reference**。代码、测试、Schema、运行工件、签名和哈希增加可审计性，但不会自动产生独立性。升级到 E5 至少需要不同组织使用独立环境、独立密钥和预注册协议复现崩溃、并发、篡改和恢复结果，并公开失败记录。

## 决定性下一实验

把 Ω 状态机置于两个实现不同的共识后端上，例如受审计的 Raft 和独立数据库事务系统，使用相同预注册 trace 运行：

1. leader crash before/after commit；
2. network partition；
3. duplicated client retry；
4. stale policy epoch；
5. validator key revocation；
6. checkpoint gossip split view；
7. full state restore from externally anchored prefix。

若两个后端不能产生相同 decision、receipt hash 和 ordered state transition，必须拒绝“可移植宪约状态机”的主张并保留差异残差。
