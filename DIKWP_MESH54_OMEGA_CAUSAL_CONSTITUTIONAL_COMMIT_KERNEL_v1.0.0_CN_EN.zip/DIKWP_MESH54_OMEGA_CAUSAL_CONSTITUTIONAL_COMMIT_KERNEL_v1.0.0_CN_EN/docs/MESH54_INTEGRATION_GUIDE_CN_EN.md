# MESH 5.4 集成指南 / Integration Guide

## 1. 保留上游验证边界

先由 MESH 5.4 原生 runtime 或独立 verifier 完成 causal matrix、rollback、atlas、intent covenant、witness、transparency 和 closure 检查。Ω 的结构适配器只负责确认传入 envelope/lease 的 canonical hash、HMAC、绑定与 scope，没有资格把结构完整性升级为因果真实性。

## 2. 生成 DurableLease54

使用 `durable_lease_from_mesh54()` 将上游 lease 和 governed packet 投影为 Ω lease。生产调用者应根据风险缩小而不是扩大 max residual 和 max uses。

## 3. 激活策略与注册 validator

每个 validator 必须使用独立私钥并披露组织、资金、软件、数据和辖区关系。策略 epoch 必须单调递增。默认建议保留 replicator、red-team、governance、affected-party 四角色，并至少需要四个独立组件。

## 4. 构建 claim

使用 `claim_from_governed_packet54()`。claim 的 `upstream_evidence_hashes` 应包含完整 MESH 5.4 验证报告、atlas closure、rollback receipt、transparency inclusion 和其他独立证据的哈希；不要只放 envelope hash。

## 5. 生成 attestations

validator 在自己的隔离环境中验证证据后调用 `attest_claim54()`。生产系统不应让 admission 节点代替 validator 做全部验证，因为那会把多个角色退化为同一执行主体。

## 6. 原子提交

```python
from dikwp_mesh54_omega import ConstitutionalCommitKernel54, Ed25519IdentityOmega54

node = Ed25519IdentityOmega54.from_seed("OMEGA-NODE-01", protected_seed)
kernel = ConstitutionalCommitKernel54(
    "state/omega.sqlite",
    node_id="OMEGA-NODE-01",
    node_signer=node,
)
result = kernel.admit(claim, attestations, logical_time=trusted_sequence)
```

`ACCEPTED` 才消耗 nonce 与 lease quota。`REJECTED` 也返回可审计签名回执，但不消耗这两项资源。网络超时后可原样重试；不要生成新 nonce 来掩盖未知提交状态。

## 7. 发布 checkpoint

定期调用 `kernel.checkpoint()`，将签名 checkpoint 发布到独立存储、审计方或透明度 gossip 节点。仅保存在同一主机上的 checkpoint 无法抵御整库替换。

## 8. 恢复

恢复数据库后先执行 `verify`，再比较恢复 checkpoint 与外部锚点。若外部 checkpoint 更长或出现 split view，节点必须进入 quarantine，不得继续 admission。

## 9. 多节点演进

不要让多个 SQLite 节点共享业务 nonce 而依赖事后合并。正确路径是把 Ω 的 deterministic state transition 放到一个有明确线性化点的共识日志上，或为每个节点划分不可重叠的 nonce/lease authority domain。
