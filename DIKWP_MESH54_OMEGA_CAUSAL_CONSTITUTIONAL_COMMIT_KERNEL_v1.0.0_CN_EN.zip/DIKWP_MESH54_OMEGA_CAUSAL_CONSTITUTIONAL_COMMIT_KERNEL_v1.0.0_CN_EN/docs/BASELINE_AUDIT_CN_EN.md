# MESH 5.4 基线审计 / Baseline Audit

## 输入

- 附件：`DIKWP_MESH_5_4_Full_Delivery_2026-07-23(4).zip`
- SHA-256：`6285ff54abc9a0bc10cd54b8ca8673dfd49108c757f9530ebb4fc02e547a8b6e`
- 内含参考 wheel：`dikwp_mesh5_phi0-5.4.0-py3-none-any.whl`
- wheel SHA-256：`fa2206348dcfa570521c9fdef09c7481e54ed919cc4435a0eb5a5b490578bc96`

## 审计方法

逐层解压附件与嵌套源码发行包，审阅 README、5.4 架构、5.4 威胁模型、runtime54、透明度、见证、lease 和测试结构；运行 Ω 适配器直接读取附件生成的 `governed_packet54.json` 与 `capability_lease54.json`。未把附件中已有的验证报告当作独立证据。

## 已确认的 5.4 强项

1. 从全局映射转为局部 causal atlas、signed seam 与 loop holonomy。
2. 从单一 PurposeContract 转为复数 Intent Field Covenant 与 revision trigger。
3. 用 `S5.4-OPERABLE-OPEN` 替代全局闭合过度声明。
4. 引入匿名 UAX 残差、chart-genesis proposal 与开放义务。
5. 将见证完整性升级为 Ed25519，并另行计算 independence graph。
6. 通过 outer preflight、inner preview、nonce reserve 与 commit 修补 outer-envelope nonce burn。
7. 引入签名 gossip checkpoint 和 split-view 检测。

## 关键断层

5.4 威胁模型明确承认：参考 nonce reservation 只在单进程锁内有效，跨进程部署需要持久化数据库和共识机制。源码 `runtime54.py` 中 `_lease_uses`、`_reserved_nonces` 与 `_committed_nonces` 均为内存容器，并由 `RLock` 保护。

由此产生四类运行风险：

- **重启失忆**：进程重启后已经使用的 nonce 与 lease quota 不能从运行时内存恢复；
- **跨进程双花**：两个进程各自持有锁，可能同时接受同一 nonce；
- **部分提交**：若 nonce、quota、receipt 和 evidence 分步写入，崩溃可能留下不一致状态；
- **审计脱节**：日志证明某次接受，不一定证明对应的 quota 与 nonce 状态也已持久化。

## 设计选择

Ω 不尝试在一个补丁中虚构分布式共识。它选择最小而严格的可证明边界：

```text
one SQLite database = one constitutional serialization domain
```

在该边界内，通过 WAL、`synchronous=FULL`、`BEGIN IMMEDIATE`、唯一约束、外键和单事务证据追加，实现跨进程互斥、崩溃回滚和确定性恢复。跨数据库的一致性仍作为显式开放义务保留。

## 基线测试说明

附件测试收集到 111 个测试项目。受本次执行窗口限制，附件自身的完整测试套件未在本次交付中得到重新完成验证，因此本发行不声称“上游 111/111 通过”。Ω 自身的 39 项测试、28 项 conformance 与 10 个 Schema/示例验证均在本次交付中实际执行并通过。
