# Ω 威胁模型 / Threat Model

## 保护资产

- nonce 唯一性与不被恶意烧毁；
- capability lease 的 chart、relation、time、residual 与 quota 边界；
- validator 身份、角色与独立性计算；
- policy epoch、撤销和否决规则；
- admission receipt 的真实性和幂等性；
- evidence log 的顺序、payload 完整性与 Merkle 承诺；
- 崩溃后的数据库恢复语义；
- forensic export 与 checkpoint 的可验证性。

## 攻击者能力

参考威胁模型允许攻击者提交畸形 JSON、篡改 envelope、重放旧包、复用 nonce、并发启动多个进程、提供同源 validator、提交过期证明、超出 lease 范围、诱发进程崩溃，以及在事后修改数据库字段或构造分叉日志。

## 控制矩阵

| 攻击 | 控制 |
|---|---|
| tampered outer envelope nonce burn | 结构预检先于 admission；拒绝不写 nonce |
| same nonce across processes | SQLite writer serialization + unique nonce key |
| crash after partial state change | nonce、quota、receipt、event 同一事务 |
| exact retry after timeout | claim hash 与既有 receipt 双重验证后幂等返回 |
| nonce substitution | nonce 绑定 claim hash；不同 claim 返回冲突 |
| lease quota double spend | `BEGIN IMMEDIATE` 内检查并递增 uses |
| chart/relation/scope smuggling | durable lease hash 与 admission scope 门 |
| stale policy replay | 单调 epoch；旧 epoch 不能重新激活 |
| revoked authority | validator/lease/channel/envelope/policy 持久 revocation |
| correlated validator Sybil | 五类披露关系构成冲突图，连通分量折扣 |
| role laundering | required roles 与 independent component count 分开检查 |
| affected-party suppression | affected-party 为必需角色；有效 DENY 可否决 |
| forged attestation | validator 公钥、identity hash、Ed25519 signature |
| receipt forgery | 节点 Ed25519 签名、receipt hash 与 event/state binding |
| evidence event rewrite | payload hash + previous hash + event hash + Merkle root |
| database counter tamper | verify 对 nonce、receipt、claims、lease counters 做关系核对 |
| split-view transparency | signed checkpoints + prefix comparison |
| oversized API body | 2 MiB hard limit；非法 Content-Length fail closed |
| unauthenticated API mutation | bearer token；默认空 token 无法启动服务 |

## Fail-closed 行为

无法解析、签名无效、数据库不一致、缺少活跃策略、租约不存在、独立性不足和撤销状态都不能退化为接受。`fail_closed_on_store_error` 是策略对象的一部分；参考存储在检测到事件链损坏后拒绝继续追加。

## 剩余风险

1. **数据库宿主失陷**：拥有 OS/root 权限的攻击者可替换代码、密钥与整个数据库快照。哈希链只能检测不一致，不能抵御完整历史替换，除非 checkpoint 已发布到外部锚点。
2. **密钥托管**：参考 seed 是确定性测试材料；生产必须使用 HSM/KMS 或受控私钥文件。
3. **披露真实性**：independence graph 只能计算已披露关系，不能证明组织和资金声明真实。
4. **单数据库边界**：SQLite 不解决跨节点网络分区或 Byzantine consensus。
5. **预检完备性**：结构适配器不读取真实模型激活，也不替代完整 causal/rollback/atlas 验证。
6. **HTTP 身份**：bearer token 是最小本地门，不是细粒度授权、mTLS、OIDC 或抗流量攻击方案。
7. **时间来源**：logical time 由调用者提供；生产必须绑定可信时钟或共识序号。
8. **备份回滚**：恢复旧但内部一致的数据库可能重放历史状态；应将 checkpoint 发布到外部 append-only anchor 并执行单调恢复检查。

## 生产前门槛

- 外部安全审计与模糊测试；
- HSM/KMS 密钥轮换和吊销流程；
- mTLS/OIDC、细粒度 RBAC 与请求审计；
- 可信时间/序列服务；
- 远程 checkpoint gossip 与不可回滚外部锚定；
- 经验证的 Raft/BFT 或数据库共识层；
- 独立机构 validator 注册、利益关系核验和真实受影响者参与。
