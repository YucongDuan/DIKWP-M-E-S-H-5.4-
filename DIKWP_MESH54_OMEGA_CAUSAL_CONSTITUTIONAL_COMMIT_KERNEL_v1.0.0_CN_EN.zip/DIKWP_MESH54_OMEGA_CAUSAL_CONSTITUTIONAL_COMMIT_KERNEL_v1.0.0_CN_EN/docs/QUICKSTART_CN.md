# 五分钟启动

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl
mesh54-omega conformance --out outputs/conformance --report outputs/conformance.json
mesh54-omega demo --out outputs/demo-new
```

预期：conformance 显示 28/28 PASS；demo summary 显示 store verification PASS、跨进程竞争 1 接受/1 冲突、崩溃回滚 true、重启幂等 true。

打开 `dashboard/index.html` 查看离线证据驾驶舱。生产使用前必须阅读 `THREAT_MODEL_CN_EN.md` 和 `OPERATIONS_RUNBOOK_CN_EN.md`。
