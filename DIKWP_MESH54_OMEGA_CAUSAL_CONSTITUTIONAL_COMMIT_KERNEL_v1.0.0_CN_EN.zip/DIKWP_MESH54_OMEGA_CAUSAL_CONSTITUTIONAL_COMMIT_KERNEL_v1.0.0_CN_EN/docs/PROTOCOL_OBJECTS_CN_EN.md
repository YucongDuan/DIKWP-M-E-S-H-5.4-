# Ω 协议对象 / Protocol Objects

## ValidatorIdentity54

绑定 validator ID、角色、组织、资金域、软件谱系、数据谱系、司法辖区、公钥、指纹与证据等级。`identity_hash` 覆盖除自身外的全部字段。

## AdmissionPolicy54

定义策略 ID、MESH 版本、单调 epoch、必需角色、独立组件阈值、DENY veto、attestation 最大年龄、幂等策略、fail-closed 标志、签发和失效时间。旧 epoch 一旦退休不能重新成为 active。

## DurableLease54

把上游 `CapabilityLease54` 投影为持久执行租约，绑定上游 lease hash、subject envelope、channel、允许的 charts/relations、残差预算、最大使用次数、时间窗、policy epoch 和状态。

## AdmissionClaim54

对一次待提交 governed operation 做内容寻址。包含 envelope 与 Mesh54 envelope hash、nonce、lease、channel、chart、relations、intent/atlas/closure/checkpoint hashes、residual used、logical time、policy epoch 与上游证据 hashes。

## PreflightAttestation54

validator 针对一个 claim 的 `APPROVE` 或 `DENY`。签名覆盖 verdict、reasons、evidence hashes、policy epoch、checked/expires time。attestation 不能跨 claim 或跨 epoch 重用。

## IndependenceAssessment54

记录批准者、否决者、冲突边、独立连通分量、角色集合、有效独立数、阈值、状态、原因和证据 hashes。它是可重算派生对象，不把角色数量误作独立性。

## CommitReceipt54

节点对 admission 决策的签名回执。绑定 claim、nonce、lease、policy、attestations、independence assessment、对应 event sequence/hash、事务后的 state root、node ID 和 committed time。

## TransparencyCheckpointOmega54

对一个 event prefix 的 tree size、Merkle root、head hash 和 previous checkpoint hash 签名。checkpoint 链负责历史承诺，不赋予远程节点本地 authority。

## CheckpointComparison54

记录两个 checkpoint 的 equal/prefix/split relation、共同前缀长度、split-view 标志和原因。

## StoreVerificationReport54

汇总 SQLite integrity、event/receipt/nonce counts、active policy、head、Merkle root、全部 invariant failures 与 report hash。

## Canonicalization

所有对象在哈希和签名前转换为 UTF-8 JSON，键排序、紧凑分隔符、禁止 NaN/Infinity。集合被确定性排序，时间使用整数 logical time。签名算法标识固定在对象中，避免算法混淆。
