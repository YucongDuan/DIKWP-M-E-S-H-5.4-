# Ω 架构 / Architecture

## 定位

Ω 是 MESH 5.4 之下的操作提交层，而不是替代其 causal atlas、Intent Field、UAX、witness 或 mutation 语义的第六套协议。

```text
MESH 5.4 scientific and constitutional evidence
  ├─ causal atlas / seams / holonomy
  ├─ intent-field covenant / anti-intents
  ├─ observer reciprocity / UAX residuals
  ├─ witness identities / independence disclosure
  ├─ gossip checkpoints / rule mutation receipts
  └─ governed packet + capability lease
                      │
                      ▼
             Ω structural adapter
                      │
                      ▼
      AdmissionClaim54 + validator attestations
                      │
                      ▼
     Constitutional Atomic Commit Transaction
       ├─ policy epoch and revocations
       ├─ lease scope, quota, time, residual
       ├─ signatures, roles, independence, veto
       ├─ durable nonce uniqueness / idempotency
       ├─ signed receipt
       └─ append-only evidence event
                      │
                      ▼
       SQLite WAL + checkpoints + forensics
```

## 组件

### `mesh54_adapter.py`

把 MESH 5.4 `GovernedPacketEnvelope54` 与 `CapabilityLease54` 投影为 Ω 的 claim 和 durable lease。结构预检验证三层 canonical body hash / HMAC、ID 派生、lease 绑定、chart/relation/time/residual scope。它故意不宣称替代完整因果矩阵、rollback、witness quorum、transparency inclusion 或 atlas closure 验证。

### `models.py`

定义 10 个内容寻址公共对象：validator identity、policy、lease、claim、attestation、independence assessment、receipt、checkpoint、checkpoint comparison、store verification report。所有对象都有 canonical body 和 SHA-256 hash；receipt、attestation 和 checkpoint 使用 Ed25519。

### `independence.py`

构造 validator 冲突图。组织、资金、软件谱系、数据谱系或司法辖区任一重合即产生边；每个连通分量只贡献一个独立计数。角色覆盖与独立组件是两个不同条件，不能相互替代。

### `store.py`

提供 SQLite 状态机。所有 mutation 都在 `BEGIN IMMEDIATE` 事务内执行，并与完整证据事件一起提交。关键表包括 policies、validators、leases、revocations、attestations、claims、nonces、receipts、events 和 checkpoints。

### `kernel.py`

提供稳定 façade：register validator、activate policy、register lease、admit、revoke、checkpoint、verify 和 status。

### `checkpoint.py`

比较两个签名 checkpoint 及事件前缀，区分 equal、prefix 和 split view。远程 checkpoint 只提供证据，不能直接取得本地处置权。

### `service.py`

提供最小本地 JSON API。服务默认不接受无 token 的敏感请求；不包含动态代码加载、shell、文件上传或任意数据库查询接口。

## Admission 状态机

```text
RECEIVED
  │
  ├─ invalid claim / policy / lease / signature ──► REJECTED
  ├─ revoked / expired / out-of-scope ────────────► REJECTED
  ├─ DENY constitutional veto ────────────────────► REJECTED
  ├─ insufficient roles or independence ──────────► REJECTED
  │
  ├─ same nonce + same claim + valid receipt ─────► IDEMPOTENT RETURN
  ├─ same nonce + different claim ────────────────► REJECT_NONCE_CONFLICT
  │
  └─ all gates pass
        BEGIN IMMEDIATE
        write claim + attestations
        increment lease use
        insert durable nonce
        append evidence event
        sign and insert receipt
        COMMIT
                                                  ► ACCEPTED
```

拒绝路径也产生签名 receipt 与证据事件，但不会插入 nonce 或增加 lease use。精确幂等返回既有 receipt，不产生新事件。

## 崩溃一致性

测试注入三个故障点：事件追加之后、nonce 写入之后、commit 之前。SQLite 事务退出时统一 rollback。重开数据库后，event count、nonce count 和 lease use 必须与故障前相同，随后相同 claim 可正常重试。

## Checkpoint 语义

checkpoint 对“签发前的事件前缀”签名。签发 checkpoint 本身会追加下一条事件，因此：

```text
checkpoint.tree_size + 1 == state.event_count immediately after issuance
```

这避免 checkpoint 自指。后续事件不会使旧 checkpoint 无效；它仍是对应前缀的可验证历史承诺。

## 一致性边界

SQLite 为同一数据库文件上的并发 writer 提供串行化和崩溃恢复，但不提供：

- 多数据库原子提交；
- 网络分区下的一致性选择；
- Byzantine quorum；
- 跨节点 leader election；
- 远程日志的自动信任。

跨节点演进应把相同 deterministic admission state machine 放在 Raft/BFT 或受审计的数据库共识层之上，而不是在应用层拼接多个 SQLite 文件。
