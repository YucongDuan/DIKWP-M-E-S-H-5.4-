# 可复现性 / Reproducibility

## 参考环境

- Date: 2026-07-23
- Python: 3.13.5
- cryptography: 46.0.4
- jsonschema: 4.26.0
- pytest: 9.0.2
- SQLite: Python 标准库绑定版本见 `VALIDATION_REPORT.json`

## 复现命令

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl

mesh54-omega conformance --out reproduce/conformance --report reproduce/conformance.json
mesh54-omega demo --out reproduce/demo
mesh54-omega artifacts-validate --root . --output reproduce/artifacts.json
```

源码测试：

```bash
python -m pip install -e . --no-build-isolation
pytest -q
```

## 决定性与非决定性

参考 Ed25519 keys 由固定 seed 派生，仅用于可复现测试。logical time、输入对象和竞争 claims 固定。多进程调度顺序不固定，但期望不变量固定：一 ACCEPTED、一 `REJECT_NONCE_CONFLICT`。SQLite 文件的物理字节哈希可能因页布局或环境不同而变化，因此科学比较使用 receipt/event/checkpoint/summary hashes，而不要求数据库文件哈希跨环境一致。

## 校验层

1. `pytest`：实现行为；
2. `conformance`：完整生命周期和 28 个外部可观察不变量；
3. `artifacts-validate`：10 个 Schema/示例配对；
4. `verify`：持久数据库内部不变量；
5. `verify_release.py`：发行 Manifest 和 SHA-256；
6. clean-wheel：从 wheel 安装而非源码树导入后重跑 conformance。
