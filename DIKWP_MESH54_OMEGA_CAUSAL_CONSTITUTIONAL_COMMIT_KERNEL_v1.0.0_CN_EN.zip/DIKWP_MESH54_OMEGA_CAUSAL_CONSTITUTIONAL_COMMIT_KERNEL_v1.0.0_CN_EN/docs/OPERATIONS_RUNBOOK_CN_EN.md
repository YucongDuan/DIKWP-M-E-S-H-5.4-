# Ω 运维手册 / Operations Runbook

## 初始化

1. 在受限目录创建数据库；
2. 从 HSM/KMS 或受权限保护的 secret 注入 node seed；
3. 注册 validator identities；
4. 激活 policy epoch；
5. 注册 durable leases；
6. 执行 `status` 与 `verify`；
7. 发布初始 checkpoint。

数据库目录应仅允许服务账号读写。不要把 WAL、SHM 或数据库文件放在不支持 POSIX 锁语义的共享文件系统上，除非经过 SQLite 官方兼容性验证。

## 日常检查

```bash
mesh54-omega status --database state/omega.sqlite --node-id NODE --node-seed "$SEED"
mesh54-omega verify --database state/omega.sqlite --node-id NODE --node-seed "$SEED"
mesh54-omega checkpoint --database state/omega.sqlite --node-id NODE --node-seed "$SEED" --logical-time 1000
mesh54-omega export --database state/omega.sqlite --node-id NODE --node-seed "$SEED" --out snapshots/1000 --checked-at 1000
```

监控指标：event count 单调增长、checkpoint chain 连续、nonce count 与 accepted receipts 相符、lease uses 不超过 max uses、active epoch 单调、verification 保持 PASS。

## 网络超时

客户端必须用完全相同的 claim 和 attestations 重试。若首次事务已提交，节点返回相同 receipt；若事务回滚，则正常重新执行。改变 nonce 会失去幂等关联，并可能造成业务层重复动作。

## 崩溃恢复

1. 停止 writer；
2. 保存数据库、`-wal` 与 `-shm` 的取证副本；
3. 让 SQLite 完成恢复；
4. 执行 `verify`；
5. 与外部 checkpoint 比较；
6. 仅在两者均一致后恢复 admission。

## 发现篡改

verification 为 FAIL 时禁止继续写入。导出 forensic snapshot，记录首个 invariant failure、外部 checkpoint、二进制哈希和宿主日志。不要通过“修正计数器”继续运行；应从可信备份恢复并重放已外部锚定的共识记录。

## 策略升级

新策略使用更高 epoch。先在影子数据库重放近期 claims，比较接受/拒绝差异、受影响者 veto 与配额变化，再激活。旧 epoch 不允许重新激活；回滚必须发布一个新的更高 epoch，而不是降低 epoch。

## 密钥轮换

节点密钥轮换应发布最后一个旧密钥 checkpoint、记录新旧指纹的治理批准，并以新密钥签发后续 checkpoint。validator 轮换创建新 identity 或受审计的 key-rotation object；不要直接覆盖历史 public key。
