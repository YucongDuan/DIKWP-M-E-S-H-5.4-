# 下一项决定性实验 / Next Decisive Experiment

## 主张

“Ω admission state machine 可以在不同共识后端上保持 decision、ordered transition 与 signed receipt 的语义等价。”

## 三臂设计

- A：单 SQLite Ω，作为当前可复现基线；
- B：Raft replicated log 后端；
- C：实现独立的事务数据库/共识后端。

三臂接收完全相同的预注册 trace：合法请求、篡改请求、精确重试、同 nonce 冲突、leader crash、网络分区、旧 epoch、撤销、validator DENY、checkpoint gossip 和恢复。

## 主要判据

在允许的时间与后端元数据差异之外，下列序列必须一致：

```text
decision code
claim hash
nonce ownership
lease use transition
policy epoch
independence assessment hash
receipt semantic body
ordered event payloads
checkpoint prefix relation
```

## Kill tests

出现任一结果即拒绝可移植性主张：

1. 两个后端接受了同一 authority domain 内的不同 same-nonce claim；
2. leader crash 导致 receipt 已对外可见但状态未提交，或状态已提交但幂等查询找不到 receipt；
3. 旧 policy epoch 在任一后端重新取得 authority；
4. 同一预注册 trace 产生不同 constitutional veto；
5. 恢复后 checkpoint 不能证明为原历史的前缀扩展；
6. 为追求一致而删除 UAX、DENY 或开放义务。

## 证据升级条件

至少两个独立团队、两套实现、不同基础设施和公开失败记录完成预注册复现，才可从 E2 讨论向 E5 迁移。性能指标不能替代上述安全语义。
