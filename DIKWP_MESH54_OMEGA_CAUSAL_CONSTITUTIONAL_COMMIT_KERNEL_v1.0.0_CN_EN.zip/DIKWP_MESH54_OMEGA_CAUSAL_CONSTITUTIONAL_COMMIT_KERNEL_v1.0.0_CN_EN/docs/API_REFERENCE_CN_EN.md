# 本地 API 参考 / Local API Reference

## 启动

```bash
export MESH54_OMEGA_NODE_SEED='protected-seed'
export MESH54_OMEGA_API_TOKEN='at-least-24-random-characters'
mesh54-omega serve --database state/omega.sqlite --node-id NODE-01 --host 127.0.0.1 --port 8754
```

除健康检查外，请求头必须包含：

```text
Authorization: Bearer <token>
Content-Type: application/json
```

最大请求体 2 MiB。

## GET `/health`

无需认证。返回 framework 与服务模式，不暴露数据库、策略或密钥信息。

## GET `/v1/status`

返回 active policy、event/head/Merkle、nonce/receipt/validator/revocation counts 与 lease uses。该响应是观察值，不是签名 checkpoint。

## GET `/v1/verify`

执行完整持久状态验证，返回 `StoreVerificationReport54`。高成本部署应使用只读副本或受控频率调用。

## GET `/v1/receipts/{receipt_id}`

读取签名 admission receipt。不存在时返回 404。

## POST `/v1/admit`

```json
{
  "claim": {"...": "AdmissionClaim54"},
  "attestations": [{"...": "PreflightAttestation54"}],
  "logical_time": 104
}
```

HTTP 200 表示请求已被处理，不代表宪约接受；必须读取 `receipt.decision` 与 `receipt.code`。精确重试返回同一 receipt 并设置 `idempotent=true`。

## POST `/v1/checkpoints`

```json
{"logical_time": 140}
```

返回 201 与签名 checkpoint。checkpoint 覆盖签发前的事件前缀；签发动作本身追加下一条事件。

## 安全响应

- 400：对象格式、logical time 或字段错误；
- 401：缺少或错误 bearer token；
- 403：宪约拒绝或权限错误；
- 404：路径或 receipt 不存在；
- 405：PUT/PATCH/DELETE 禁止；
- 500：fail-closed，仅暴露异常类型而不返回堆栈或 secret。

生产系统应在反向代理上增加 TLS、mTLS/OIDC、请求速率、IP/网络策略、结构化审计和密钥轮换。
