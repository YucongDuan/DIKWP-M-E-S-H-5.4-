# DIKWP-MESH 5.4 Ω Release Notes

Release date: 2026-07-23  
Version: 1.0.0

## New critical system

- persistent constitutional admission state over SQLite WAL;
- atomic nonce, lease-use, receipt and evidence-event commit;
- cross-process same-nonce serialization;
- crash injection and deterministic recovery;
- exact replay idempotency across restart;
- monotonic policy epochs and persistent revocations;
- Ed25519 validator attestations and node receipts;
- relationship-aware validator independence graph;
- signed checkpoints, checkpoint chain and split-view comparison;
- forensic snapshot and full store invariant verification;
- structural adapter for the attached MESH 5.4 governed packet and lease;
- local authenticated JSON API, CLI, 10 schemas, 39 tests and 28-check conformance.

## Deliberate non-features

- no claim of multi-node consensus;
- no automatic remote authority from gossip checkpoints;
- no production key manager or TLS stack;
- no inflation beyond E2 evidence;
- no replacement of full MESH 5.4 causal, rollback, atlas or affected-party verification.
