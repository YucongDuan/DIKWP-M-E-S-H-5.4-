from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from dikwp_mesh54_omega.canonical import sha256_file


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--output", default="SBOM.spdx.json")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    output = root / args.output
    wheel = root / "dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl"
    sdist = root / "dist/dikwp_mesh54_omega-1.0.0.tar.gz"
    upstream = root / "vendor/dikwp_mesh5_phi0-5.4.0-py3-none-any.whl"
    created = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    packages = [
        {
            "name": "dikwp-mesh54-omega",
            "SPDXID": "SPDXRef-Package-Omega",
            "versionInfo": "1.0.0",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "Apache-2.0",
            "licenseDeclared": "Apache-2.0",
            "copyrightText": "NOASSERTION",
            "checksums": [{"algorithm": "SHA256", "checksumValue": sha256_file(wheel)}],
            "externalRefs": [{"referenceCategory": "PACKAGE-MANAGER", "referenceType": "purl", "referenceLocator": "pkg:pypi/dikwp-mesh54-omega@1.0.0"}],
        },
        {
            "name": "cryptography",
            "SPDXID": "SPDXRef-Package-Cryptography",
            "versionInfo": "46.0.4",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "NOASSERTION",
            "licenseDeclared": "NOASSERTION",
            "copyrightText": "NOASSERTION",
        },
        {
            "name": "jsonschema",
            "SPDXID": "SPDXRef-Package-Jsonschema",
            "versionInfo": "4.26.0",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "NOASSERTION",
            "licenseDeclared": "NOASSERTION",
            "copyrightText": "NOASSERTION",
        },
        {
            "name": "dikwp-mesh5-phi0-upstream-input",
            "SPDXID": "SPDXRef-Package-UpstreamMesh54",
            "versionInfo": "5.4.0",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "Apache-2.0",
            "licenseDeclared": "Apache-2.0",
            "copyrightText": "NOASSERTION",
            "checksums": [{"algorithm": "SHA256", "checksumValue": sha256_file(upstream)}],
            "comment": "Vendored reference input; not imported as a mandatory Omega runtime dependency.",
        },
    ]
    document = {
        "spdxVersion": "SPDX-2.3",
        "dataLicense": "CC0-1.0",
        "SPDXID": "SPDXRef-DOCUMENT",
        "name": "DIKWP-MESH54-Omega-1.0.0-SBOM",
        "documentNamespace": "https://dikwp.example.invalid/spdx/mesh54-omega/1.0.0",
        "creationInfo": {"created": created, "creators": ["Tool: mesh54-omega-build-sbom/1.0.0"]},
        "documentDescribes": ["SPDXRef-Package-Omega"],
        "packages": packages,
        "relationships": [
            {"spdxElementId": "SPDXRef-Package-Omega", "relationshipType": "DEPENDS_ON", "relatedSpdxElement": "SPDXRef-Package-Cryptography"},
            {"spdxElementId": "SPDXRef-Package-Omega", "relationshipType": "DEPENDS_ON", "relatedSpdxElement": "SPDXRef-Package-Jsonschema"},
            {"spdxElementId": "SPDXRef-Package-Omega", "relationshipType": "GENERATED_FROM", "relatedSpdxElement": "SPDXRef-Package-UpstreamMesh54"},
        ],
        "annotations": [{"annotationType": "OTHER", "annotator": "Tool: mesh54-omega-build-sbom/1.0.0", "annotationDate": created, "comment": f"sdist sha256={sha256_file(sdist)}"}],
    }
    output.write_text(json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
