from __future__ import annotations

import argparse
import json
from pathlib import Path

from dikwp_mesh54_omega.canonical import sha256_file, sha256_obj


def ignored(rel: Path) -> bool:
    return any(part in {".git", ".pytest_cache", "__pycache__", "build"} or part.endswith(".egg-info") for part in rel.parts)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".")
    parser.add_argument("--output", default="")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    failures: list[str] = []
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    body = dict(manifest)
    tree_hash = body.pop("tree_hash", "")
    if sha256_obj(body) != tree_hash:
        failures.append("manifest tree hash mismatch")
    expected = {item["path"]: item for item in manifest["files"]}
    actual = {
        path.relative_to(root).as_posix(): path
        for path in root.rglob("*")
        if path.is_file() and not path.is_symlink() and path.relative_to(root).as_posix() not in {"MANIFEST.json", "SHA256SUMS.txt"} and not ignored(path.relative_to(root))
    }
    for name, entry in expected.items():
        path = root / name
        if not path.is_file():
            failures.append(f"missing manifest file: {name}")
            continue
        if path.stat().st_size != entry["bytes"]:
            failures.append(f"size mismatch: {name}")
        if sha256_file(path) != entry["sha256"]:
            failures.append(f"hash mismatch: {name}")
    for name in sorted(set(actual) - set(expected)):
        failures.append(f"unmanifested file: {name}")
    checksum_lines = (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
    checked = 0
    for line in checksum_lines:
        digest, name = line.split("  ", 1)
        path = root / name
        if not path.is_file():
            failures.append(f"checksum target missing: {name}")
        elif sha256_file(path) != digest:
            failures.append(f"checksum mismatch: {name}")
        checked += 1
    report = {
        "status": "PASS" if not failures else "FAIL",
        "manifest_files": len(expected),
        "checksum_entries": checked,
        "tree_hash": tree_hash,
        "failures": failures,
    }
    if args.output:
        (root / args.output).write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
