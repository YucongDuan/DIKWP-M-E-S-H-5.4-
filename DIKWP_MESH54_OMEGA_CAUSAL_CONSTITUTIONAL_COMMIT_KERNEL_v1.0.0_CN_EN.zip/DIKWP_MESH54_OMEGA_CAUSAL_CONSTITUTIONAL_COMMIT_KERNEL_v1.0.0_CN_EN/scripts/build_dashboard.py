from __future__ import annotations

import argparse
import html
import json
import xml.etree.ElementTree as ET
from pathlib import Path


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def junit_counts(path: Path) -> tuple[int, int, int, float]:
    root = ET.parse(path).getroot()
    suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
    tests = sum(int(item.attrib.get("tests", 0)) for item in suites)
    failures = sum(int(item.attrib.get("failures", 0)) for item in suites)
    errors = sum(int(item.attrib.get("errors", 0)) for item in suites)
    seconds = sum(float(item.attrib.get("time", 0.0)) for item in suites)
    return tests, failures, errors, seconds


def build(root: Path, output: Path) -> None:
    summary = load(root / "outputs/demo/summary54omega.json")
    conformance = load(root / "outputs/conformance_report54omega.json")
    artifacts = load(root / "outputs/artifact_validation54omega.json")
    tests, failures, errors, seconds = junit_counts(root / "outputs/tests54omega.xml")
    race = summary["cross_process_race"]
    obligations = "".join(f"<li>{html.escape(item)}</li>" for item in summary["open_obligations"])
    checks = "".join(
        f'<tr><td><span class="dot ok"></span>{html.escape(item["name"])}</td><td>{"PASS" if item["passed"] else "FAIL"}</td><td>{html.escape(item["detail"])}</td></tr>'
        for item in conformance["checks"]
    )
    raw_summary = html.escape(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
    html_text = f'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark">
<title>DIKWP-MESH 5.4 Ω Evidence Cockpit</title>
<style>
:root{{--bg:#07111c;--panel:#0d1b29;--panel2:#102439;--line:#24445f;--text:#e8f1f8;--muted:#9bb0c2;--accent:#53d7c1;--gold:#f4c66a;--danger:#ff8585;--ok:#70e1a1;--shadow:0 20px 60px rgba(0,0,0,.28)}}
*{{box-sizing:border-box}} body{{margin:0;background:radial-gradient(circle at 80% -10%,#193a54 0,transparent 34%),linear-gradient(180deg,#07111c,#061019 55%,#050b12);color:var(--text);font:15px/1.65 ui-sans-serif,system-ui,-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}}
a{{color:var(--accent)}} .wrap{{max-width:1240px;margin:auto;padding:42px 26px 80px}} .eyebrow{{letter-spacing:.14em;text-transform:uppercase;color:var(--accent);font-weight:750;font-size:12px}} h1{{font-size:clamp(34px,5.4vw,68px);line-height:1.05;margin:10px 0 18px;max-width:1050px}} h1 span{{color:var(--accent)}} .lede{{max-width:920px;color:#c3d3df;font-size:18px}} .badge{{display:inline-flex;gap:8px;align-items:center;border:1px solid #31566e;background:#0b1d2c;border-radius:999px;padding:7px 12px;color:#d6e7f2;font-weight:700;margin:16px 8px 0 0}} .dot{{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--muted);margin-right:9px}} .dot.ok{{background:var(--ok);box-shadow:0 0 14px rgba(112,225,161,.55)}}
.grid{{display:grid;grid-template-columns:repeat(12,1fr);gap:16px;margin-top:28px}} .card{{grid-column:span 3;background:linear-gradient(145deg,rgba(16,36,57,.96),rgba(9,23,36,.96));border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:var(--shadow)}} .card.wide{{grid-column:span 6}} .card.full{{grid-column:1/-1}} .metric{{font-size:34px;font-weight:850;letter-spacing:-.03em}} .label{{color:var(--muted);font-size:13px;text-transform:uppercase;letter-spacing:.08em}} .sub{{color:#bfd0dc;margin-top:4px}}
section{{margin-top:58px}} h2{{font-size:29px;margin:0 0 16px}} .flow{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}} .node{{position:relative;padding:18px;border:1px solid var(--line);background:#0d1c2b;border-radius:15px;min-height:132px}} .node b{{display:block;color:var(--gold);margin-bottom:6px}} .node:not(:last-child):after{{content:"→";position:absolute;right:-18px;top:45px;color:var(--accent);font-size:24px;z-index:3}}
.invariant{{border-left:4px solid var(--accent);padding:20px 24px;background:#0a1b28;border-radius:0 16px 16px 0;font:700 17px/1.7 ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap}}
table{{width:100%;border-collapse:collapse;background:#0a1723;border:1px solid var(--line);border-radius:14px;overflow:hidden}} th,td{{text-align:left;padding:12px 14px;border-bottom:1px solid #1c3549;vertical-align:top}} th{{color:var(--accent);font-size:12px;text-transform:uppercase;letter-spacing:.09em;background:#0e2030}} tr:last-child td{{border-bottom:0}} details{{background:#0a1723;border:1px solid var(--line);border-radius:14px;padding:13px 16px;margin-top:14px}} summary{{cursor:pointer;font-weight:750}} pre{{white-space:pre-wrap;word-break:break-word;color:#cce0ed;background:#06101a;padding:16px;border-radius:10px;overflow:auto}} .boundary{{border:1px solid #674b33;background:linear-gradient(145deg,#241b16,#111820);padding:22px;border-radius:17px}} .boundary h3{{color:var(--gold);margin-top:0}} footer{{margin-top:60px;color:#7f96a8;border-top:1px solid var(--line);padding-top:22px}} @media(max-width:900px){{.card,.card.wide{{grid-column:span 6}}.flow{{grid-template-columns:1fr 1fr}}.node:after{{display:none}}}} @media(max-width:620px){{.card,.card.wide{{grid-column:1/-1}}.flow{{grid-template-columns:1fr}}.wrap{{padding:28px 16px 60px}}}}
</style>
</head>
<body><main class="wrap">
<div class="eyebrow">DIKWP-MESH 5.4 · Evidence before capability</div>
<h1><span>Ω</span> 因果宪约原子提交内核</h1>
<p class="lede">把 MESH 5.4 的 governed packet、能力租约、见证独立性与透明度证据，转换为可崩溃恢复、跨进程互斥、不可重复消费且带签名回执的持久宪约事务。</p>
<span class="badge"><span class="dot ok"></span>{html.escape(summary['evidence_grade'])}</span>
<span class="badge">Framework · {html.escape(summary['framework'])}</span>
<span class="badge">Release · {html.escape(summary['version'])}</span>
<div class="grid">
  <div class="card"><div class="label">Implementation tests</div><div class="metric">{tests}/{tests}</div><div class="sub">failures {failures} · errors {errors} · {seconds:.2f}s</div></div>
  <div class="card"><div class="label">Conformance</div><div class="metric">{conformance['checks_passed']}/{conformance['checks_total']}</div><div class="sub">{conformance['status']} · self-contained lifecycle</div></div>
  <div class="card"><div class="label">Schemas</div><div class="metric">{artifacts['passed']}/{artifacts['schemas_checked']}</div><div class="sub">Draft 2020-12 examples</div></div>
  <div class="card"><div class="label">Store verification</div><div class="metric">{html.escape(summary['store_verification'])}</div><div class="sub">relational + signature + chain invariants</div></div>
  <div class="card wide"><div class="label">Cross-process same-nonce race</div><div class="metric">{race['accepted_count']} accepted · {race['nonce_conflict_count']} conflict</div><div class="sub">exactly one linearization winner</div></div>
  <div class="card wide"><div class="label">Persistent state</div><div class="metric">{summary['committed_nonces']} nonces · {summary['lease_uses']} uses · {summary['event_count']} events</div><div class="sub">restart-stable idempotency: {str(summary['restart_replay_idempotent']).lower()}</div></div>
</div>

<section><h2>不可分割的提交语义 / Indivisible commit</h2>
<div class="invariant">COMMIT(
  durable nonce
+ lease use
+ signed admission receipt
+ hash-chained evidence event
) OR COMMIT NOTHING</div></section>

<section><h2>运行路径 / Operational path</h2><div class="flow">
<div class="node"><b>1 · MESH 5.4 Evidence</b>atlas、intent covenant、UAX、closure、governed packet 与 capability lease。</div>
<div class="node"><b>2 · Independent Gates</b>replicator、red-team、governance、affected-party；同源关系折扣。</div>
<div class="node"><b>3 · Atomic Transaction</b>policy、revocation、scope、quota、nonce、receipt 与 event 在同一事务中。</div>
<div class="node"><b>4 · Durable Proof</b>Merkle root、签名 checkpoint、forensic snapshot、split-view comparison。</div>
</div></section>

<section><h2>已主动攻击的路径 / Exercised adversarial paths</h2>
<div class="grid">
<div class="card wide"><div class="label">Tampered outer envelope</div><div class="metric">REJECTED</div><div class="sub">合法 nonce 未被烧毁：{str(summary['tampered_outer_nonce_burn_prevented']).lower()}</div></div>
<div class="card wide"><div class="label">Injected crash</div><div class="metric">ROLLED BACK</div><div class="sub">retry accepted：{str(summary['crash_retry_accepted']).lower()}</div></div>
<div class="card wide"><div class="label">Persistent-state tamper</div><div class="metric">DETECTED</div><div class="sub">lease counter modification caused verification failure</div></div>
<div class="card wide"><div class="label">Transparency split view</div><div class="metric">DETECTED</div><div class="sub">divergent signed histories were not averaged away</div></div>
</div></section>

<section><h2>28 项合规门 / Conformance gates</h2>
<table><thead><tr><th>Check</th><th>Status</th><th>Invariant</th></tr></thead><tbody>{checks}</tbody></table>
</section>

<section><div class="boundary"><h3>明确不作出的声明 / Explicit non-claims</h3><ul>{obligations}</ul>
<p>Ω 的证据边界是单 SQLite 数据库协调域。它不把测试数量、密码学签名或模拟角色升级为多节点共识、独立外部复现或全局语义闭合。</p></div></section>

<section><h2>证据指纹 / Evidence fingerprints</h2>
<table><tbody>
<tr><td>Summary hash</td><td><code>{html.escape(summary['summary_hash'])}</code></td></tr>
<tr><td>Event head</td><td><code>{html.escape(summary['head_hash'])}</code></td></tr>
<tr><td>Merkle root</td><td><code>{html.escape(summary['merkle_root'])}</code></td></tr>
<tr><td>Conformance report</td><td><code>{html.escape(conformance['report_hash'])}</code></td></tr>
<tr><td>Schema report</td><td><code>{html.escape(artifacts['report_hash'])}</code></td></tr>
</tbody></table>
<details><summary>Reference summary JSON</summary><pre>{raw_summary}</pre></details>
</section>
<footer>Offline single-file cockpit · no external scripts, fonts, images or network dependencies · DIKWP-MESH 5.4 Ω v1.0.0</footer>
</main></body></html>'''
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--output", default="dashboard/index.html")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    output = Path(args.output)
    if not output.is_absolute():
        output = root / output
    build(root, output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
