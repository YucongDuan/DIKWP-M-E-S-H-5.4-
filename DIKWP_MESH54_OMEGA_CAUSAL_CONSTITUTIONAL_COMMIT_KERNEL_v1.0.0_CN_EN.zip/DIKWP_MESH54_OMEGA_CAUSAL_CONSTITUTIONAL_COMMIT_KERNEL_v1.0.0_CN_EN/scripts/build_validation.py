from __future__ import annotations

import argparse
import json
import platform
import sqlite3
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

from dikwp_mesh54_omega.canonical import sha256_file, sha256_obj, write_json
from dikwp_mesh54_omega.signing import Ed25519IdentityOmega54


def build(root: Path, input_zip: Path) -> dict:
    load = lambda path: json.loads((root / path).read_text(encoding="utf-8"))
    suite = ET.parse(root / "outputs/tests54omega.xml").getroot().find("testsuite")
    if suite is None:
        raise ValueError("JUnit testsuite is missing")
    tests = {key: int(suite.attrib.get(key, 0)) for key in ("tests", "failures", "errors", "skipped")}
    tests["seconds"] = float(suite.attrib.get("time", 0.0))
    conformance = load("outputs/conformance_report54omega.json")
    artifacts = load("outputs/artifact_validation54omega.json")
    clean = load("outputs/cleanwheel_verification54omega.json")
    summary = load("outputs/demo/summary54omega.json")
    proof = load("outputs/demo/RUN_PROOF54omega.json")
    import_proof = load("outputs/cleanwheel_import54omega.json")
    wheel = root / "dist/dikwp_mesh54_omega-1.0.0-py3-none-any.whl"
    sdist = root / "dist/dikwp_mesh54_omega-1.0.0.tar.gz"
    dashboard = root / "dashboard/index.html"
    upstream_wheel = root / "vendor/dikwp_mesh5_phi0-5.4.0-py3-none-any.whl"
    dashboard_text = dashboard.read_text(encoding="utf-8").lower()
    environment = {
        "python": sys.version.split()[0],
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "sqlite": sqlite3.sqlite_version,
        "cryptography": metadata.version("cryptography"),
        "jsonschema": metadata.version("jsonschema"),
        "pytest": metadata.version("pytest"),
        "setuptools": metadata.version("setuptools"),
        "wheel": "0.46.3",
    }
    checks = {
        "implementation_tests": {
            "status": "PASS" if tests["failures"] == tests["errors"] == 0 and tests["tests"] == 39 else "FAIL",
            **tests,
            "junit_sha256": sha256_file(root / "outputs/tests54omega.xml"),
        },
        "conformance": {
            "status": conformance["status"],
            "passed": conformance["checks_passed"],
            "total": conformance["checks_total"],
            "report_hash": conformance["report_hash"],
        },
        "schemas_and_examples": {
            "status": artifacts["status"],
            "passed": artifacts["passed"],
            "total": artifacts["schemas_checked"],
            "report_hash": artifacts["report_hash"],
        },
        "clean_wheel": {
            **clean,
            "module_file": import_proof["module_file"],
            "wheel_sha256": sha256_file(wheel),
        },
        "reference_lifecycle": {
            "status": summary["store_verification"],
            "summary_hash": summary["summary_hash"],
            "run_proof_hash": proof["run_proof_hash"],
            "committed_nonces": summary["committed_nonces"],
            "lease_uses": summary["lease_uses"],
            "event_count": summary["event_count"],
            "cross_process_race": summary["cross_process_race"],
            "crash_rollback_verified": summary["crash_rollback_verified"],
            "restart_replay_idempotent": summary["restart_replay_idempotent"],
            "split_view_detected": summary["split_view_detected"],
            "tampered_store_detected": summary["tampered_store_detected"],
        },
        "offline_dashboard": {
            "status": "PASS" if "<script src=" not in dashboard_text and "<link " not in dashboard_text else "FAIL",
            "bytes": dashboard.stat().st_size,
            "external_scripts": dashboard_text.count("<script src="),
            "external_stylesheets": dashboard_text.count("<link "),
            "sha256": sha256_file(dashboard),
        },
        "distributions": {
            "status": "PASS",
            "wheel": {"bytes": wheel.stat().st_size, "sha256": sha256_file(wheel)},
            "sdist": {"bytes": sdist.stat().st_size, "sha256": sha256_file(sdist)},
        },
    }
    status = "PASS" if all(item.get("status") == "PASS" for item in checks.values()) else "FAIL"
    body = {
        "status": status,
        "system": "DIKWP-MESH 5.4 Ω / Causal Constitutional Atomic Commit Kernel",
        "version": "1.0.0",
        "release_date": "2026-07-23",
        "evidence_grade": "E2 author-side deterministic reference",
        "critical_invariant": "durable nonce + lease use + signed receipt + evidence event commit atomically, or none commit",
        "baseline_materials": {
            "attachment": {"name": input_zip.name, "sha256": sha256_file(input_zip), "bytes": input_zip.stat().st_size},
            "upstream_wheel": {"name": upstream_wheel.name, "sha256": sha256_file(upstream_wheel), "bytes": upstream_wheel.stat().st_size},
        },
        "checks": checks,
        "environment": environment,
        "upstream_test_boundary": {
            "collected_tests": 111,
            "status": "NOT_CLAIMED",
            "reason": "The upstream full suite exceeded the available execution window; no completed upstream pass result is asserted by this delivery.",
        },
        "open_obligations": summary["open_obligations"] + [
            "validator relationship disclosures require external verification",
            "logical time requires a trusted production source",
            "checkpoint replacement resistance requires an external append-only anchor",
            "production deployment requires HSM/KMS, mTLS/OIDC, consensus and independent security review",
        ],
    }
    report = {**body, "report_hash": sha256_obj(body)}
    write_json(root / "VALIDATION_REPORT.json", report)
    write_json(root / "outputs/final_validation_report54omega.json", report)

    statement = {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": [
            {"name": wheel.name, "digest": {"sha256": sha256_file(wheel)}},
            {"name": sdist.name, "digest": {"sha256": sha256_file(sdist)}},
            {"name": dashboard.relative_to(root).as_posix(), "digest": {"sha256": sha256_file(dashboard)}},
        ],
        "predicateType": "https://slsa.dev/provenance/v1",
        "predicate": {
            "buildDefinition": {
                "buildType": "https://dikwp.example.invalid/buildtypes/mesh54-omega-reference/v1",
                "externalParameters": {"version": "1.0.0", "framework": "DIKWP-MESH 5.4"},
                "internalParameters": {"evidence_grade": "E2 author-side deterministic reference"},
                "resolvedDependencies": [
                    {"uri": f"file:{input_zip.name}", "digest": {"sha256": sha256_file(input_zip)}},
                    {"uri": f"file:vendor/{upstream_wheel.name}", "digest": {"sha256": sha256_file(upstream_wheel)}},
                ],
            },
            "runDetails": {
                "builder": {"id": "DIKWP-MESH54-Omega-reference-builder/1.0.0"},
                "metadata": {
                    "invocationId": report["report_hash"],
                    "startedOn": "2026-07-23T00:00:00Z",
                    "finishedOn": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                },
                "byproducts": [
                    {"name": "implementation-tests", "digest": {"sha256": sha256_file(root / "outputs/tests54omega.xml")}},
                    {"name": "conformance-report", "digest": {"sha256": sha256_file(root / "outputs/conformance_report54omega.json")}},
                    {"name": "validation-report", "digest": {"sha256": sha256_file(root / "VALIDATION_REPORT.json")}},
                ],
            },
            "evidenceBoundary": {
                "grade": "E2",
                "notClaims": ["multi-node consensus", "production certification", "independent external replication", "global semantic closure"],
            },
        },
    }
    signer = Ed25519IdentityOmega54.from_seed(
        "MESH54-OMEGA-PUBLIC-REFERENCE-ATTESTER",
        "mesh54-omega-public-reference-attestation-key",
    )
    envelope_body = {
        "statement": statement,
        "signature_algorithm": "Ed25519/public-deterministic-reference-fixture",
        "signer_id": signer.identity_id,
        "signer_public_key": signer.public_key_hex,
        "signer_fingerprint": signer.key_fingerprint,
        "trust_warning": "This public deterministic fixture detects accidental modification; it is not an external identity or production trust anchor.",
    }
    attestation = {
        **envelope_body,
        "signature": signer.sign(statement),
        "attestation_hash": sha256_obj(envelope_body),
    }
    write_json(root / "DIKWP_MESH54_OMEGA_ATTESTATION.json", attestation)
    return {"validation": report["status"], "report_hash": report["report_hash"], "attestation_hash": attestation["attestation_hash"]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--input-zip", required=True)
    args = parser.parse_args()
    result = build(Path(args.root).resolve(), Path(args.input_zip).resolve())
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["validation"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
