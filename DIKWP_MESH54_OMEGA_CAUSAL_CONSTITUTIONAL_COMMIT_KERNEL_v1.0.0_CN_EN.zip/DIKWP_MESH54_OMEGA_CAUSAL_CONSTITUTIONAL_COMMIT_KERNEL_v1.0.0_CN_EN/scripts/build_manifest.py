from __future__ import annotations

import argparse
import json
from pathlib import Path

from dikwp_mesh54_omega.canonical import sha256_file, sha256_obj

SPECIAL = {"MANIFEST.json", "SHA256SUMS.txt"}


def ignored(relative: Path) -> bool:
    return any(
        part in {".git", ".pytest_cache", "__pycache__", "build"} or part.endswith(".egg-info")
        for part in relative.parts
    )


def release_files(root: Path) -> list[Path]:
    return [
        path
        for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix())
        if path.is_file()
        and not path.is_symlink()
        and path.relative_to(root).as_posix() not in SPECIAL
        and not ignored(path.relative_to(root))
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    files = release_files(root)
    entries = [
        {"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)}
        for path in files
    ]
    body = {
        "format": "DIKWP-MESH54-OMEGA-MANIFEST-1",
        "system": "DIKWP-MESH 5.4 Ω / Causal Constitutional Atomic Commit Kernel",
        "version": "1.0.0",
        "evidence_grade": "E2 author-side deterministic reference",
        "file_count": len(entries),
        "files": entries,
    }
    manifest = {**body, "tree_hash": sha256_obj(body)}
    manifest_path = root / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    checksum_paths = files + [manifest_path]
    lines = [
        f"{sha256_file(path)}  {path.relative_to(root).as_posix()}"
        for path in sorted(checksum_paths, key=lambda item: item.relative_to(root).as_posix())
    ]
    (root / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"file_count": len(entries), "tree_hash": manifest["tree_hash"], "checksum_entries": len(lines)}, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
