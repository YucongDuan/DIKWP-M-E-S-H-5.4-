from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "schemas"
SCHEMAS.mkdir(parents=True, exist_ok=True)

STR = {"type": "string"}
INT = {"type": "integer"}
NUM = {"type": "number"}
BOOL = {"type": "boolean"}
STRINGS = {"type": "array", "items": STR}
STRING_GROUPS = {"type": "array", "items": {"type": "array", "items": STR}}


def schema(name, title, properties):
    payload = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": f"https://dikwp.example/schemas/mesh54-omega/{name}",
        "title": title,
        "type": "object",
        "additionalProperties": False,
        "required": list(properties),
        "properties": properties,
    }
    (SCHEMAS / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


schema("validator_identity54omega.schema.json", "ValidatorIdentity54", {
    "validator_id": STR, "role": STR, "organization_id": STR, "funding_domain": STR,
    "software_lineage": STR, "data_lineage": STR, "jurisdiction": STR,
    "public_key": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
    "key_fingerprint": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
    "evidence_grade": STR, "identity_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("admission_policy54omega.schema.json", "AdmissionPolicy54", {
    "policy_id": STR, "framework_version": STR, "epoch": {"type": "integer", "minimum": 1},
    "required_roles": STRINGS, "required_independent_approvals": {"type": "integer", "minimum": 1},
    "deny_veto": BOOL, "max_attestation_age": {"type": "integer", "minimum": 1},
    "allow_idempotent_replay": BOOL, "fail_closed_on_store_error": BOOL,
    "issued_at": INT, "expires_at": INT, "evidence_grade": STR,
    "policy_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("durable_lease54omega.schema.json", "DurableLease54", {
    "lease_id": STR, "upstream_lease_id": STR, "upstream_lease_hash": STR,
    "subject_envelope_hash": STR, "channel_id": STR, "allowed_chart_ids": STRINGS,
    "allowed_relation_ids": STRINGS, "max_residual_budget": {"type": "number", "minimum": 0, "maximum": 1},
    "max_uses": {"type": "integer", "minimum": 1}, "issued_at": INT, "expires_at": INT,
    "policy_epoch": {"type": "integer", "minimum": 1}, "status": STR,
    "lease_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("admission_claim54omega.schema.json", "AdmissionClaim54", {
    "claim_id": STR, "envelope_id": STR, "envelope_hash": STR, "mesh54_envelope_hash": STR,
    "nonce": STR, "lease_id": STR, "channel_id": STR, "chart_id": STR,
    "relation_ids": STRINGS, "intent_covenant_hash": STR, "atlas_hash": STR,
    "closure_hash": STR, "gossip_checkpoint_hash": STR, "residual_used": {"type": "number", "minimum": 0},
    "logical_time": INT, "policy_epoch": {"type": "integer", "minimum": 1},
    "upstream_evidence_hashes": STRINGS, "claim_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("preflight_attestation54omega.schema.json", "PreflightAttestation54", {
    "attestation_id": STR, "validator_id": STR, "role": STR, "claim_hash": STR,
    "verdict": {"enum": ["APPROVE", "DENY"]}, "reasons": STRINGS, "evidence_hashes": STRINGS,
    "policy_epoch": {"type": "integer", "minimum": 1}, "checked_at": INT, "expires_at": INT,
    "signature_algorithm": STR, "signature": STR,
    "attestation_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("independence_assessment54omega.schema.json", "IndependenceAssessment54", {
    "assessment_id": STR, "claim_hash": STR, "approving_validator_ids": STRINGS,
    "denying_validator_ids": STRINGS, "conflict_edges": STRING_GROUPS,
    "independent_components": STRING_GROUPS, "roles_present": STRINGS,
    "effective_independent_count": {"type": "integer", "minimum": 0},
    "required_independent_count": {"type": "integer", "minimum": 1},
    "status": {"enum": ["MET", "NOT_MET"]}, "reasons": STRINGS,
    "evidence_hashes": STRINGS, "assessment_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("commit_receipt54omega.schema.json", "CommitReceipt54", {
    "receipt_id": STR, "decision": {"enum": ["ACCEPTED", "REJECTED"]}, "code": STR,
    "reasons": STRINGS, "claim_hash": STR, "envelope_id": STR, "nonce": STR, "lease_id": STR,
    "policy_hash": STR, "policy_epoch": {"type": "integer", "minimum": 1},
    "attestation_ids": STRINGS, "independence_hash": STR, "independent_components": STRING_GROUPS,
    "event_sequence": {"type": "integer", "minimum": 1}, "event_hash": STR, "state_root": STR,
    "node_id": STR, "committed_at": INT, "signer_fingerprint": STR,
    "signature_algorithm": STR, "signature": STR, "receipt_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("checkpoint54omega.schema.json", "TransparencyCheckpointOmega54", {
    "checkpoint_id": STR, "node_id": STR, "log_id": STR, "tree_size": {"type": "integer", "minimum": 0},
    "merkle_root": STR, "head_hash": STR, "previous_checkpoint_hash": STR,
    "issued_at": INT, "signer_fingerprint": STR, "signature_algorithm": STR,
    "signature": STR, "checkpoint_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("checkpoint_comparison54omega.schema.json", "CheckpointComparison54", {
    "comparison_id": STR, "left_checkpoint_hash": STR, "right_checkpoint_hash": STR,
    "relation": STR, "common_prefix_size": {"type": "integer", "minimum": 0},
    "split_view_detected": BOOL, "reasons": STRINGS,
    "comparison_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
schema("store_verification54omega.schema.json", "StoreVerificationReport54", {
    "status": {"enum": ["PASS", "FAIL"]}, "database_integrity": STR,
    "event_count": {"type": "integer", "minimum": 0}, "receipt_count": {"type": "integer", "minimum": 0},
    "committed_nonce_count": {"type": "integer", "minimum": 0}, "active_policy_hash": STR,
    "head_hash": STR, "merkle_root": STR, "invariant_failures": STRINGS,
    "checked_at": INT, "report_hash": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
})
print(f"generated {len(list(SCHEMAS.glob('*.schema.json')))} schemas")
